#include "headerfile.h"

volatile int16_t right_speed = 0;
volatile int16_t left_speed  = 0;
volatile uint32_t g_b0_press_count = 0U;
volatile uint32_t g_b1_press_count = 0U;
volatile uint8_t g_b0_gpio_level = 1U;
volatile uint8_t g_b1_gpio_level = 1U;
volatile uint32_t g_task_three_press_count = 0U;
volatile uint8_t g_task_three_gpio_level = 1U;
volatile uint32_t g_task_four_press_count = 0U;
volatile uint8_t g_task_four_gpio_level = 1U;
volatile uint32_t g_stepper_up_press_count = 0U;
volatile uint32_t g_stepper_down_press_count = 0U;
volatile uint8_t g_stepper_up_gpio_level = 1U;
volatile uint8_t g_stepper_down_gpio_level = 1U;

/* ---- SysTick-based delay ---- */
static volatile uint32_t tick_ms = 0;
volatile uint32_t g_control_20ms_tick_count = 0U;
static uint8_t g_control_20ms_divider = 0U;

void SysTick_Handler(void)
{
    tick_ms++;
    g_control_20ms_divider++;
    if (g_control_20ms_divider >= 20U) {
        g_control_20ms_divider = 0U;
        g_control_20ms_tick_count++;
    }
}

void delay_ms(uint32_t ms)
{
    uint32_t start = tick_ms;
    while ((tick_ms - start) < ms);
}

uint32_t millis(void)
{
    return tick_ms;
}

void delay_cycles(uint32_t cycles)
{
    for (uint32_t i = 0; i < cycles; i++) {
        __asm("nop");
    }
}

/* ---- motherboard keys (PB1/PB0, active low) ---- */
typedef struct {
    uint8_t initialized;
    uint8_t raw_pressed;
    uint8_t stable_pressed;
    uint32_t raw_change_ms;
} KeyState;

static uint8_t key_pressed(GPIO_Regs *port, uint32_t pin, KeyState *state)
{
    uint8_t raw_pressed =
        ((DL_GPIO_readPins(port, pin) & pin) == 0U) ? 1U : 0U;
    uint32_t now = millis();

    if (!state->initialized) {
        state->initialized = 1U;
        state->raw_pressed = raw_pressed;
        state->stable_pressed = 0U;
        state->raw_change_ms = now;
    }

    if (raw_pressed != state->raw_pressed) {
        state->raw_pressed = raw_pressed;
        state->raw_change_ms = now;
    }

    if ((state->stable_pressed != state->raw_pressed) &&
        ((now - state->raw_change_ms) >= 20U)) {
        state->stable_pressed = state->raw_pressed;
        if (state->stable_pressed) {
            return 1U;
        }
    }

    return 0U;
}

uint8_t lap_select_key_scan(void)
{
    static KeyState b0_state;
    /* B0/PB0 selects the lap count. */
    g_b0_gpio_level =
        ((DL_GPIO_readPins(GPIO_key_PORT, GPIO_key_PIN_START_PIN) &
            GPIO_key_PIN_START_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_key_PORT,
        GPIO_key_PIN_START_PIN, &b0_state);
    if (pressed) {
        g_b0_press_count++;
    }
    return pressed;
}

uint8_t start_key_scan(void)
{
    static KeyState b1_state;
    /* B1/PB1 confirms the selection and starts the car. */
    g_b1_gpio_level =
        ((DL_GPIO_readPins(GPIO_key_PORT,
            GPIO_key_PIN_LAP_SELECT_PIN) &
            GPIO_key_PIN_LAP_SELECT_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_key_PORT,
        GPIO_key_PIN_LAP_SELECT_PIN, &b1_state);
    if (pressed) {
        g_b1_press_count++;
    }
    return pressed;
}

uint8_t task_three_key_scan(void)
{
    static KeyState task_three_state;
    g_task_three_gpio_level =
        ((DL_GPIO_readPins(GPIO_TASK_THREE_KEY_PORT,
            GPIO_TASK_THREE_KEY_PIN_TASK_THREE_START_PIN) &
            GPIO_TASK_THREE_KEY_PIN_TASK_THREE_START_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_TASK_THREE_KEY_PORT,
        GPIO_TASK_THREE_KEY_PIN_TASK_THREE_START_PIN, &task_three_state);
    if (pressed) {
        g_task_three_press_count++;
    }
    return pressed;
}

uint8_t task_four_key_scan(void)
{
    static KeyState task_four_state;
    g_task_four_gpio_level =
        ((DL_GPIO_readPins(GPIO_TASK_THREE_KEY_PORT,
            GPIO_TASK_THREE_KEY_PIN_TASK_FOUR_START_PIN) &
            GPIO_TASK_THREE_KEY_PIN_TASK_FOUR_START_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_TASK_THREE_KEY_PORT,
        GPIO_TASK_THREE_KEY_PIN_TASK_FOUR_START_PIN, &task_four_state);
    if (pressed) {
        g_task_four_press_count++;
    }
    return pressed;
}

#if 0 /* Old stepper buttons are disabled; PA30/PA31 now start tasks 4/3. */
uint8_t stepper_up_key_scan(void)
{
    static KeyState up_state;
    g_stepper_up_gpio_level =
        ((DL_GPIO_readPins(GPIO_STEPPER_KEYS_PORT,
            GPIO_STEPPER_KEYS_PIN_UP_PIN) &
            GPIO_STEPPER_KEYS_PIN_UP_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_STEPPER_KEYS_PORT,
        GPIO_STEPPER_KEYS_PIN_UP_PIN, &up_state);
    if (pressed) {
        g_stepper_up_press_count++;
    }
    return pressed;
}

uint8_t stepper_down_key_scan(void)
{
    static KeyState down_state;
    g_stepper_down_gpio_level =
        ((DL_GPIO_readPins(GPIO_STEPPER_KEYS_PORT,
            GPIO_STEPPER_KEYS_PIN_DOWN_PIN) &
            GPIO_STEPPER_KEYS_PIN_DOWN_PIN) != 0U) ? 1U : 0U;
    uint8_t pressed = key_pressed(GPIO_STEPPER_KEYS_PORT,
        GPIO_STEPPER_KEYS_PIN_DOWN_PIN, &down_state);
    if (pressed) {
        g_stepper_down_press_count++;
    }
    return pressed;
}
#endif

/* ---- DRV8870 dual-input PWM ---- */
static void set_left_inputs(uint16_t in1, uint16_t in2)
{
    DL_TimerA_setCaptureCompareValue(
        PWM_MOTOR_INST, in1, DL_TIMER_CC_0_INDEX);
    DL_TimerA_setCaptureCompareValue(
        PWM_MOTOR_INST, in2, DL_TIMER_CC_1_INDEX);
}

static void set_right_inputs(uint16_t in1, uint16_t in2)
{
    DL_TimerA_setCaptureCompareValue(
        PWM_MOTOR_INST, in1, DL_TIMER_CC_2_INDEX);
    DL_TimerA_setCaptureCompareValue(
        PWM_MOTOR_INST, in2, DL_TIMER_CC_3_INDEX);
}

static uint16_t command_magnitude(int32_t speed, int32_t dead_zone)
{
    int32_t magnitude = (speed > 0) ? speed : -speed;
    magnitude += dead_zone;
    if (magnitude > MOTOR_PWM_MAX) {
        magnitude = MOTOR_PWM_MAX;
    }
    return (uint16_t)magnitude;
}

void set_Lspeed(int32_t speed)
{
    if (speed == 0) {
        set_left_inputs(0, 0);
        return;
    }

    /* 统一修正电机安装方向，上层仍使用正数表示前进。 */
    speed *= MOTOR_DIRECTION_L;
    uint16_t magnitude = command_magnitude(speed, MOTOR_DEAD_ZONE_L);
    if (speed > 0) {
        /* Drive: 10. PWM off-time: 11 (active brake). */
        set_left_inputs(MOTOR_PWM_MAX, MOTOR_PWM_MAX - magnitude);
    } else {
        /* Drive: 01. PWM off-time: 11 (active brake). */
        set_left_inputs(MOTOR_PWM_MAX - magnitude, MOTOR_PWM_MAX);
    }
}

void set_Rspeed(int32_t speed)
{
    if (speed == 0) {
        set_right_inputs(0, 0);
        return;
    }

    /* 统一修正电机安装方向，上层仍使用正数表示前进。 */
    speed *= MOTOR_DIRECTION_R;
    uint16_t magnitude = command_magnitude(speed, MOTOR_DEAD_ZONE_R);
    if (speed > 0) {
        set_right_inputs(MOTOR_PWM_MAX, MOTOR_PWM_MAX - magnitude);
    } else {
        set_right_inputs(MOTOR_PWM_MAX - magnitude, MOTOR_PWM_MAX);
    }
}

void motor_active_brake(void)
{
    set_left_inputs(MOTOR_PWM_MAX, MOTOR_PWM_MAX);
    set_right_inputs(MOTOR_PWM_MAX, MOTOR_PWM_MAX);
}
