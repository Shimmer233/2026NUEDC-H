#ifndef HEADERFILE_H
#define HEADERFILE_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

extern volatile int16_t right_speed;
extern volatile int16_t left_speed;
extern volatile uint8_t sensor_d1;
extern volatile uint8_t sensor_d2;
extern volatile uint8_t sensor_d3;
extern volatile uint8_t sensor_d4;
extern volatile uint8_t sensor_d5;
extern volatile uint8_t sensor_d6;
extern volatile uint8_t sensor_d7;
extern volatile uint8_t sensor_d8;
extern volatile uint32_t completed_lap_count;
extern volatile uint32_t g_b0_press_count;
extern volatile uint32_t g_b1_press_count;
extern volatile uint8_t g_b0_gpio_level;
extern volatile uint8_t g_b1_gpio_level;
extern volatile uint32_t g_task_three_press_count;
extern volatile uint8_t g_task_three_gpio_level;
extern volatile uint32_t g_task_four_press_count;
extern volatile uint8_t g_task_four_gpio_level;
extern volatile uint32_t g_stepper_up_press_count;
extern volatile uint32_t g_stepper_down_press_count;
extern volatile uint8_t g_stepper_up_gpio_level;
extern volatile uint8_t g_stepper_down_gpio_level;
extern volatile float g_g356_absolute_yaw_degrees;
extern volatile uint8_t g_parking_line_detected;
extern volatile uint8_t g_lap_finish_armed;
extern volatile float g_task_one_speed_scale;
extern volatile float g_task_two_speed_scale;
extern volatile float g_task_one_left_smoothed_target;
extern volatile float g_task_one_right_smoothed_target;
extern volatile uint8_t g_task_one_stability_active;

#define SENSOR_LINE_LEVEL 1

/* ---- line following params ---- */
#define TRACK_BASE_SPEED       20
#define TRACK_SEARCH_SPEED     14
#define TRACK_SEARCH_ADJUST     3
#define TRACK_KP                3.5f
#define TRACK_MAX_ADJUST       15.0f

/* ---- encoder speed measurement ---- */
/* 左轮：电机 PB8/PB9，编码器 PA26/PA27。 */
/* 右轮：电机 PB12/PB13，编码器 PB10/PB11。 */
#define ENCODER_DIRECTION_L           1
#define ENCODER_DIRECTION_R           1
#define MOTOR_SPEED_TEST_TARGET_L  20.0f  /* counts per 20 ms */
#define MOTOR_SPEED_TEST_TARGET_R  20.0f  /* counts per 20 ms */
#define MOTOR_SPEED_TEST_PWM_L        400
#define MOTOR_SPEED_TEST_PWM_R        400

/* ---- left wheel speed PID: PA26/PA27 feedback -> PB8/PB9 motor ---- */
#define LEFT_PID_KP                 15.0f
#define LEFT_PID_KI                 10.0f
#define LEFT_PID_KD                  0.0f
#define LEFT_PID_PERIOD_MS           20U
#define PID_INTEGRAL_ERROR_LIMIT     5.0f

/* ---- right wheel speed PID: PB10/PB11 feedback -> PB12/PB13 motor ---- */
#define RIGHT_PID_KP                15.0f
#define RIGHT_PID_KI                10.0f
#define RIGHT_PID_KD                 0.0f
#define RIGHT_PID_PERIOD_MS          20U

/* ---- lap control ---- */
#define PARKING_LINE_CLEAR_CYCLES  3U
#define PARKING_LINE_CONFIRM_CYCLES 1U
#define TASK_TWO_DURATION_MS     6000U
#define TASK_ONE_SOFT_START_DURATION_MS 5000U
#define TASK_ONE_STEERING_SCALE          0.75f
#define TASK_ONE_TARGET_ACCEL_RATE      20.0f
#define TASK_ONE_TARGET_DECEL_RATE      30.0f
#define TASK_ONE_STABILITY_YAW_DEG      190.0f
#define TASK_ONE_STABLE_STEERING_SCALE   0.65f
#define TASK_ONE_STABLE_TARGET_RATE       8.0f
#define TASK_ONE_DECEL_STEERING_FRACTION  0.60f
#define TASK_TWO_DECEL_DURATION_MS 1200U
#define TASK_TWO_CRAWL_SPEED       0.0f
#define TASK_ONE_DECEL_DURATION_MS 4000U

/* ---- motor ---- */
#define MOTOR_PWM_MAX        2000
#define MOTOR_DEAD_ZONE_L       0
#define MOTOR_DEAD_ZONE_R       0
#define MOTOR_DIRECTION_L      (-1)  /* 左轮正速度对应当前车体的前进方向 */
#define MOTOR_DIRECTION_R      (-1)  /* 右轮正速度对应当前车体的前进方向 */
#define TASK_TWO_SOFT_START_DURATION_MS 1200U
#define TASK_TWO_SOFT_START_MAX_PWM      800

/* ---- task four: 24Y-Hti-style one-lap line following ---- */
#define TASK_FOUR_CRUISE_SPEED             20.0f
#define TASK_FOUR_STOP_DECEL_DURATION_MS 4000U
#define TASK_FOUR_CENTER_KP                 1.3f
#define TASK_FOUR_EDGE_KP                   3.2f
#define TASK_FOUR_MAX_ADJUST                8.0f
#define TASK_FOUR_ADJUST_SLEW_PER_SECOND   32.0f
#define TASK_FOUR_WHEEL_SLEW_PER_SECOND   200.0f
#define TASK_FOUR_LINE_LOST_GRACE_MS      150U
#define TASK_FOUR_STOPPED_SPEED             1.5f
#define TASK_FOUR_STOPPED_STABLE_SAMPLES    5U

/* ---- function declarations ---- */
void  delay_ms(uint32_t ms);
void  delay_cycles(uint32_t cycles);
uint32_t millis(void);
extern volatile uint32_t g_control_20ms_tick_count;

uint8_t lap_select_key_scan(void);
uint8_t start_key_scan(void);
uint8_t task_three_key_scan(void);
uint8_t task_four_key_scan(void);
#if 0 /* Old stepper buttons are disabled; PA30/PA31 now start tasks 4/3. */
uint8_t stepper_up_key_scan(void);
uint8_t stepper_down_key_scan(void);
#endif

void  set_Lspeed(int32_t speed);
void  set_Rspeed(int32_t speed);
void  motor_active_brake(void);

void    update_sensors(void);
void    track(void);
void    track_reset(void);
uint8_t check_cross_right(void);
uint8_t check_cross_left(void);
uint8_t check_parking_line(void);

#endif
