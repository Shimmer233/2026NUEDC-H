# Car 2 motor, encoder, and VOFA wiring

Only channels A and B of the four-channel board are used.

## SeekFree MSPM0G3507 MotherBoard V1.0

The current firmware is configured for the MotherBoard pushbuttons and avoids
the board's fixed PA22 battery-voltage divider.

### Temporary line-following-only mode

`ENABLE_GYRO_TURN_TASK` is currently `0`. The firmware does not initialize or
read the gyroscope, detect intersections, execute in-place turns, count laps,
or stop automatically by lap count. The LSM6DS3 may remain disconnected.
Press B0 once per lap, then press B1 to start line following. The car stops
when the absolute accumulated G356 yaw reaches the selected laps times 360
degrees.

### On-board buttons

| MotherBoard button | MCU pin | Firmware action |
| --- | --- | --- |
| S5 / B1 | PB1 | Start when at least one lap is selected |
| S4 / B0 | PB0 | Add one lap per press |

The current multi-task firmware assigns the start inputs as follows:

| Input | MCU pin | Task |
| --- | --- | --- |
| S5 / B1 | PB1 | Task 1, existing one-lap control |
| S4 / B0 | PB0 | Task 2, six-second timed line following |
| External active-low key | PA31 | Task 3, basic line following |
| External active-low key | PA30 | Task 4, smooth 24Y-Hti-style one-lap control |

Connect each external key between its MCU pin and GND. PA30 and PA31 use
internal pull-ups and 20 ms software debounce. Task 4 waits for valid G356
data and for at least one of D2-D7 to see the line before it starts.

Both buttons are active low and already have pull-ups and hardware debounce
capacitors on the MotherBoard. No external button wiring is required.

### Motor and encoder headers

| MotherBoard header | MCU pin | External connection |
| --- | --- | --- |
| P16-2 | PB8 | Driver AIN1 |
| P16-6 | PB9 | Driver AIN2 |
| P16-1 | PB12 | Driver BIN1 |
| P16-5 | PB13 | Driver BIN2 |
| P16-3 or P16-4 | GND | Driver logic GND |
| P17-5 | PA26 | Left encoder A |
| P17-6 | PA27 | Left encoder B |
| P17-1 | PB10 | Right encoder A |
| P17-2 | PB11 | Right encoder B |
| P17-3 or P17-4 | GND | Encoder GND |

P17 does not provide encoder power. Supply the encoders from a separate 3.3 V
pin and keep every external digital output 3.3 V compatible.

### Eight digital line sensors

With the car facing forward, connect the sensors from left to right as D1
through D8. The firmware treats a high input as active.

| Sensor | MCU pin | MotherBoard access point |
| --- | --- | --- |
| D1, far left | PB17 | P19-6 |
| D2 | PB18 | P20-6 |
| D3 | PA12 | P9-2 |
| D4 | PA9 | P9-4 |
| D5 | PA7 | P9-6 |
| D6 | PA15 | P9-8 |
| D7 | PA8 | P9-10 |
| D8, far right | PA13 | P9-12 |

P6/P8/P10/P12 pins 1 or 2 provide the board's regulated 3.3 V camera rail,
and pins 5 or 6 are GND. Do not drive a GPIO with a 5 V sensor output.

PA8 and PA9 are now line-sensor inputs. The LoRa UART uses the MotherBoard
P15 connector: PB6/P15-1 goes to module RX and PB7/P15-3 goes to module TX.
LoRa AUX has moved from PB2/P15-4 to PB14 and requires a separate jumper;
PB2/P15-4 must remain disconnected from the module AUX pin.

### Reserved LSM6DS3 wiring (disabled in the current build)

| LSM6DS3 | MotherBoard connection |
| --- | --- |
| VCC | P18-1 (3.3 V) |
| GND | P18-2 (GND) |
| SCL | P13-3 (PA1) |
| SDA | P13-4 (PA0) |
| CS | 3.3 V, to select I2C mode |
| SDO/SA0 | GND, to select address 0x6A |

The P18 attitude-sensor connector is wired for SPI, while this firmware uses
I2C. Do not plug the sensor into P18 as a complete SPI module; use only its
3.3 V and GND pins and route SCL/SDA as shown above.

## MSPM0 to driver board

| MSPM0G3507 | DRV8870 board | Purpose |
| --- | --- | --- |
| PB8 (TIMA0 CCP0) | AIN1 | Left motor input 1 PWM |
| PB9 (TIMA0 CCP1) | AIN2 | Left motor input 2 PWM |
| PB12 (TIMA0 CCP2) | BIN1 | Right motor input 1 PWM |
| PB13 (TIMA0 CCP3) | BIN2 | Right motor input 2 PWM |
| GND | GND | Required common ground |

Connect the board's motor A output to the left motor and motor B output to the
right motor. Channels C and D are unused and their control pins may remain
unconnected.

The current chassis has both motors mounted with reversed electrical polarity,
so `MOTOR_DIRECTION_L` and `MOTOR_DIRECTION_R` are both set to `-1`. Positive
logical speed still means vehicle forward.

## Power

- Supply the driver board through its motor-power input with 7-35 V, selected
  for the connected motors.
- Do not connect the motor-power input to an MSPM0 GPIO or 3.3 V rail.
- The MSPM0 and driver board must share GND.
- Do not tie the board's 3.3 V or 5 V output to the LaunchPad supply unless the
entire power arrangement has been checked separately.

## Encoders and VOFA serial output

| MSPM0G3507 | External signal | Purpose |
| --- | --- | --- |
| PA26 | Left encoder A | GPIO interrupt input, internal pull-up enabled |
| PA27 | Left encoder B | GPIO input used to determine direction |
| PB10 | Right encoder A | GPIO interrupt input, internal pull-up enabled |
| PB11 | Right encoder B | GPIO input used to determine direction |
| PB15 (UART2 TX) | USB-TTL RXD | VOFA CSV output at 115200 8N1 |
| GND | Encoder and USB-TTL GND | Required common ground |

The encoder output voltage must be 3.3 V compatible. For VOFA, connect only
PB15 to the adapter RXD and connect GND; do not connect the adapter's 5 V pin.
PB14 is reserved for the LoRa AUX input.

### PD42S1 TTL stepper driver

| MSPM0G3507 | PD42S1 TTL signal | Purpose |
| --- | --- | --- |
| PB2 / UART3 TX | R/B/L (RXD on TTL version) | MCU command output |
| PB3 / UART3 RX | T/A/H (TXD on TTL version) | Driver response input |
| GND | GND | Required common ground |

The PD42S1 must be the TTL version for this direct UART connection. Power its
V+ input from a separate 12-32 V supply rated for at least 3 A, and share GND
with the MSPM0. Do not power the motor driver from an MCU GPIO. Configure the
driver for the custom protocol (MODBUS disabled), address 1, command echo
enabled, and 115200 8N1.

## Control behavior

The board exposes the DRV8870 IN1/IN2 pins directly; there is no separate DIR
input on the board. This project follows the vendor's two-PWM control method so
the PWM off-time uses active braking in both directions:

| Command | IN1 | IN2 | DRV8870 state |
| --- | --- | --- | --- |
| Positive speed | 1 | Inverted duty PWM | Forward / brake PWM |
| Negative speed | Inverted duty PWM | 1 | Reverse / brake PWM |
| Zero speed | 0 | 0 | Coast, then sleep |
| Active brake | 1 | 1 | Low-side brake |

During either direction's drive pulse the inputs are `10` or `01`. During every
PWM off-time both inputs are `11`, so both directions use active braking rather
than coasting. PWM frequency is 20 kHz. If a positive command turns a wheel
backward, swap that motor's two output wires.
