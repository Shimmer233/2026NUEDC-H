#include "ball_balance.h"

#include "encoder.h"
#include "headerfile.h"
#include "g356.h"
#include "vision.h"

volatile float g_ball_balance_offset_cm;
volatile float g_ball_balance_desired_angle_degrees;
volatile float g_ball_balance_slewed_angle_degrees;
volatile float g_ball_balance_target_angle_degrees;
volatile uint8_t g_ball_balance_center_valid;
volatile StepperStatus g_ball_balance_last_status;
volatile uint32_t g_ball_balance_command_count;
volatile uint32_t g_ball_balance_error_count;
volatile BallBalanceCalibrationState g_ball_balance_calibration_state;
volatile uint8_t g_ball_balance_active_task;
volatile float g_t3_kp = BALL_BALANCE_TASK3_KP_DEG_PER_CM;
volatile float g_t3_ki = BALL_BALANCE_TASK3_KI_DEG_PER_CM_S;
volatile float g_t3_kd = BALL_BALANCE_TASK3_KD_DEG_S_PER_CM;
volatile float g_t3_e;
volatile float g_t3_p;
volatile float g_t3_i;
volatile float g_t3_d;
volatile float g_t3_pid;
volatile float g_t3_out;
volatile float g_ball_balance_task1_velocity_cm_s;
volatile float g_ball_balance_task1_position_angle_degrees;
volatile float g_ball_balance_task1_speed_compensation_degrees;

volatile float g_ball_balance_task3_velocity_cm_s;
volatile float g_ball_balance_task3_position_angle_degrees;
volatile float g_ball_balance_task3_speed_compensation_degrees;
volatile float g_ball_balance_task3_filtered_position_cm;
volatile float g_ball_balance_task3_filtered_velocity_cm_s;
volatile float g_ball_balance_task3_error_delta_cm;
volatile float g_ball_balance_task3_accel_bias_g;
volatile float g_ball_balance_task3_filtered_accel_g;
volatile float g_ball_balance_task3_accel_compensation_degrees;
volatile float g_ball_balance_task3_accel_feedforward_gain;
volatile float g_ball_balance_task3_angle_tracking_error_degrees;
volatile uint8_t g_ball_balance_task3_accel_calibrated;
volatile uint8_t g_ball_balance_task4_active;
volatile BallBalanceTaskFourPhase g_ball_balance_task4_phase;
volatile float g_ball_balance_task4_setpoint_cm;
volatile uint8_t g_ball_balance_task4_stable_samples;
volatile uint8_t g_ball_balance_task4_key_gpio_level = 1U;
volatile uint32_t g_ball_balance_task4_start_count;
volatile float g_t4_kp = BALL_BALANCE_TASK4_KP_DEG_PER_CM;
volatile float g_t4_ki = BALL_BALANCE_TASK4_KI_DEG_PER_CM_S;
volatile float g_t4_kd = BALL_BALANCE_TASK4_KD_DEG_S_PER_CM;

volatile float g_ball_balance_task2_average_position_cm;
volatile float g_ball_balance_task2_filtered_position_cm;
volatile float g_ball_balance_task2_estimated_velocity_cm_s;
volatile float g_ball_balance_task2_filtered_velocity_cm_s;
volatile float g_ball_balance_task2_error_cm;
volatile float g_ball_balance_task2_p_degrees;
volatile float g_ball_balance_task2_i_degrees;
volatile float g_ball_balance_task2_d_degrees;
volatile float g_ball_balance_task2_overrange_compensation_deg_s;
volatile float g_ball_balance_task2_integral_cm_s;
volatile float g_ball_balance_task2_output_degrees;
volatile float g_ball_balance_task2_adjustment_rate_deg_s;
volatile float g_ball_balance_task2_increment_degrees;
volatile float g_ball_balance_task2_accumulated_target_degrees;
volatile float g_ball_balance_task2_output_gain;
volatile uint16_t g_ball_balance_task2_command_speed_rpm;

static uint32_t g_ball_balance_last_vision_update_count;
static uint32_t g_ball_balance_calibration_action_ms;
static uint32_t g_ball_balance_last_at_target_update_count;
static uint32_t g_ball_balance_last_zero_update_count;
static float g_ball_balance_last_command_angle_degrees;
static uint8_t g_ball_balance_command_angle_valid;
static uint8_t g_ball_balance_desired_angle_valid;
static uint32_t g_ball_balance_last_control_tick_count;
static uint8_t g_ball_balance_task2_filter_initialized;
static uint32_t g_ball_balance_task2_last_update_ms;
static uint8_t g_ball_balance_task2_average_position_valid;
static uint32_t g_ball_balance_task3_last_imu_frame_count;
static uint32_t g_ball_balance_task3_last_imu_ms;
static uint32_t g_ball_balance_task3_last_vision_ms;
static uint8_t g_ball_balance_task3_filter_initialized;
static uint16_t g_ball_balance_task3_accel_bias_count;
static float g_ball_balance_task3_last_raw_position_cm;
static float g_ball_balance_task3_previous_error_cm;
static uint8_t g_ball_balance_task3_previous_error_valid;
static uint8_t g_ball_balance_task4_key_initialized;
static uint8_t g_ball_balance_task4_key_raw_pressed;
static uint8_t g_ball_balance_task4_key_stable_pressed;
static uint32_t g_ball_balance_task4_key_change_ms;

static float abs_float(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float ball_balance_task3_accel_gain(void)
{
    EncoderLink_Data_t encoder_data;

    if (!EncoderLink_GetLatest(&encoder_data, NULL)) {
        return BALL_BALANCE_TASK3_ACCEL_GAIN_DEFAULT;
    }

    uint32_t count = encoder_data.average_count;
    if (count < BALL_BALANCE_TASK3_ENCODER_COUNT_THRESHOLD) {
        return BALL_BALANCE_TASK3_ACCEL_GAIN_BELOW_THRESHOLD;
    }

    if ((count >= BALL_BALANCE_TASK3_ENCODER_MIDDLE_RANGE_MIN) &&
        (count <= BALL_BALANCE_TASK3_ENCODER_MIDDLE_RANGE_MAX)) {
        return BALL_BALANCE_TASK3_ACCEL_GAIN_MIDDLE_RANGE;
    }

    if ((count >= BALL_BALANCE_TASK3_ENCODER_HIGH_RANGE_MIN) &&
        (count <= BALL_BALANCE_TASK3_ENCODER_HIGH_RANGE_MAX)) {
        return BALL_BALANCE_TASK3_ACCEL_GAIN_HIGH_RANGE;
    }

    return BALL_BALANCE_TASK3_ACCEL_GAIN_DEFAULT;
}

static void ball_balance_task4_set_setpoint(float setpoint_cm)
{
    g_ball_balance_task4_setpoint_cm = setpoint_cm;
    g_ball_balance_task4_stable_samples = 0U;
    g_t3_i = 0.0f;
    g_ball_balance_task3_previous_error_valid = 0U;
}

static void ball_balance_task4_start(void)
{
    if (g_ball_balance_task4_active) {
        return;
    }

    g_ball_balance_task4_active = 1U;
    g_ball_balance_task4_phase =
        BALL_BALANCE_TASK4_MOVE_TO_POSITIVE;
    g_ball_balance_active_task = BALL_BALANCE_TASK_THREE;
    g_ball_balance_task4_start_count++;
    ball_balance_task4_set_setpoint(
        BALL_BALANCE_TASK4_POSITIVE_SETPOINT_CM);
}

static void ball_balance_task4_process_key(uint32_t now_ms)
{
    uint32_t pin =
        GPIO_BALL_TASK_FOUR_KEY_PIN_BALL_TASK_FOUR_START_PIN;
    uint8_t raw_pressed =
        ((DL_GPIO_readPins(GPIO_BALL_TASK_FOUR_KEY_PORT, pin) & pin) == 0U) ?
            1U : 0U;

    g_ball_balance_task4_key_gpio_level = raw_pressed ? 0U : 1U;
    if (!g_ball_balance_task4_key_initialized) {
        g_ball_balance_task4_key_initialized = 1U;
        g_ball_balance_task4_key_raw_pressed = raw_pressed;
        g_ball_balance_task4_key_change_ms = now_ms;
    }
    if (raw_pressed != g_ball_balance_task4_key_raw_pressed) {
        g_ball_balance_task4_key_raw_pressed = raw_pressed;
        g_ball_balance_task4_key_change_ms = now_ms;
    }
    if ((g_ball_balance_task4_key_stable_pressed !=
            g_ball_balance_task4_key_raw_pressed) &&
        ((uint32_t)(now_ms - g_ball_balance_task4_key_change_ms) >=
            BALL_BALANCE_TASK4_KEY_DEBOUNCE_MS)) {
        g_ball_balance_task4_key_stable_pressed =
            g_ball_balance_task4_key_raw_pressed;
        if (g_ball_balance_task4_key_stable_pressed) {
            ball_balance_task4_start();
        }
    }
}

static void ball_balance_task4_update(uint8_t vision_fresh)
{
    if (!g_ball_balance_task4_active || !vision_fresh ||
        (g_ball_balance_task4_phase ==
            BALL_BALANCE_TASK4_HOLD_NEGATIVE)) {
        return;
    }

    float detection_position_cm =
        (g_ball_balance_task4_phase ==
            BALL_BALANCE_TASK4_MOVE_TO_POSITIVE) ?
            BALL_BALANCE_TASK4_POSITIVE_DETECTION_CM :
            BALL_BALANCE_TASK4_NEGATIVE_DETECTION_CM;
    float error_cm = detection_position_cm -
        g_ball_balance_task3_filtered_position_cm;
    uint8_t required_samples =
        (g_ball_balance_task4_phase ==
            BALL_BALANCE_TASK4_MOVE_TO_POSITIVE) ?
            BALL_BALANCE_TASK4_POSITIVE_STABLE_SAMPLES :
            BALL_BALANCE_TASK4_NEGATIVE_STABLE_SAMPLES;
    if (abs_float(error_cm) <=
        BALL_BALANCE_TASK4_REACHED_TOLERANCE_CM) {
        if (g_ball_balance_task4_stable_samples <
            required_samples) {
            g_ball_balance_task4_stable_samples++;
        }
    } else {
        g_ball_balance_task4_stable_samples = 0U;
    }

    if (g_ball_balance_task4_stable_samples <
        required_samples) {
        return;
    }
    if (g_ball_balance_task4_phase ==
        BALL_BALANCE_TASK4_MOVE_TO_POSITIVE) {
        g_ball_balance_task4_phase =
            BALL_BALANCE_TASK4_MOVE_TO_NEGATIVE;
        ball_balance_task4_set_setpoint(
            BALL_BALANCE_TASK4_RETURN_SETPOINT_CM);
    } else if (g_ball_balance_task4_phase ==
        BALL_BALANCE_TASK4_MOVE_TO_NEGATIVE) {
        g_ball_balance_task4_phase =
            BALL_BALANCE_TASK4_HOLD_NEGATIVE;
        ball_balance_task4_set_setpoint(
            BALL_BALANCE_TASK4_FINAL_SETPOINT_CM);
    }
}

static float clamp_offset_cm(float offset_cm)
{
    if (offset_cm > BALL_BALANCE_MAX_OFFSET_CM) {
        return BALL_BALANCE_MAX_OFFSET_CM;
    }
    if (offset_cm < -BALL_BALANCE_MAX_OFFSET_CM) {
        return -BALL_BALANCE_MAX_OFFSET_CM;
    }
    return offset_cm;
}

static float clamp_angle_degrees(float angle_degrees)
{
    float limit = BALL_BALANCE_MAX_ANGLE_DEGREES;
    if (g_ball_balance_active_task == BALL_BALANCE_TASK_TWO) {
        limit = BALL_BALANCE_TASK2_MAX_ANGLE_DEG;
    } else if (g_ball_balance_active_task == BALL_BALANCE_TASK_THREE) {
        limit = BALL_BALANCE_TASK3_MAX_ANGLE_DEG;
    }

    if (angle_degrees > limit) {
        return limit;
    }
    if (angle_degrees < -limit) {
        return -limit;
    }
    return angle_degrees;
}

static float clamp_float(float value, float minimum, float maximum)
{
    if (value < minimum) {
        return minimum;
    }
    if (value > maximum) {
        return maximum;
    }
    return value;
}

static void ball_balance_task3_reset(uint32_t now_ms)
{
    g_t3_e = 0.0f;
    g_t3_p = 0.0f;
    g_t3_i = 0.0f;
    g_t3_d = 0.0f;
    g_t3_pid = 0.0f;
    g_t3_out = 0.0f;
    g_ball_balance_task3_velocity_cm_s = 0.0f;
    g_ball_balance_task3_position_angle_degrees = 0.0f;
    g_ball_balance_task3_speed_compensation_degrees = 0.0f;
    g_ball_balance_task3_filtered_position_cm = 0.0f;
    g_ball_balance_task3_filtered_velocity_cm_s = 0.0f;
    g_ball_balance_task3_error_delta_cm = 0.0f;
    g_ball_balance_task3_accel_bias_g = 0.0f;
    g_ball_balance_task3_filtered_accel_g = 0.0f;
    g_ball_balance_task3_accel_compensation_degrees = 0.0f;
    g_ball_balance_task3_accel_feedforward_gain =
        BALL_BALANCE_TASK3_ACCEL_GAIN_DEFAULT;
    g_ball_balance_task3_angle_tracking_error_degrees = 0.0f;
    g_ball_balance_task3_accel_calibrated = 0U;
    g_ball_balance_task3_last_imu_frame_count = 0U;
    g_ball_balance_task3_last_imu_ms = now_ms;
    g_ball_balance_task3_last_vision_ms = now_ms;
    g_ball_balance_task3_filter_initialized = 0U;
    g_ball_balance_task3_accel_bias_count = 0U;
    g_ball_balance_task3_last_raw_position_cm = 0.0f;
    g_ball_balance_task3_previous_error_cm = 0.0f;
    g_ball_balance_task3_previous_error_valid = 0U;
}

static float ball_balance_task3_axis_accel_g(const G356_Data_t *data)
{
#if BALL_BALANCE_TASK3_ACCEL_AXIS_Y
    return data->accel_y * BALL_BALANCE_TASK3_ACCEL_AXIS_SIGN;
#else
    return data->accel_x * BALL_BALANCE_TASK3_ACCEL_AXIS_SIGN;
#endif
}

static void ball_balance_task3_update_imu(uint32_t now_ms)
{
    G356_Data_t data;
    uint32_t frame_count;

    if (!G356_UART_GetLatest(&data, &frame_count) ||
        (frame_count == g_ball_balance_task3_last_imu_frame_count)) {
        return;
    }
    g_ball_balance_task3_last_imu_frame_count = frame_count;
    g_ball_balance_task3_last_imu_ms = now_ms;

    float sample_g = ball_balance_task3_axis_accel_g(&data);
    if (sample_g != sample_g) {
        return;
    }

    if (!g_ball_balance_task3_accel_calibrated) {
        g_ball_balance_task3_accel_bias_count++;
        g_ball_balance_task3_accel_bias_g +=
            (sample_g - g_ball_balance_task3_accel_bias_g) /
            (float)g_ball_balance_task3_accel_bias_count;
        if (g_ball_balance_task3_accel_bias_count >=
            BALL_BALANCE_TASK3_ACCEL_BIAS_SAMPLES) {
            g_ball_balance_task3_accel_calibrated = 1U;
        }
        return;
    }

    float unbiased_g = sample_g - g_ball_balance_task3_accel_bias_g;

    g_ball_balance_task3_filtered_accel_g =
        (abs_float(unbiased_g) >= BALL_BALANCE_TASK3_ACCEL_DEADBAND_G) ?
            unbiased_g : 0.0f;
}

static uint8_t ball_balance_task3_update_vision(uint32_t now_ms)
{
    uint32_t update_count = g_vision_ball_distance_update_count;
    if ((update_count == g_ball_balance_last_vision_update_count) ||
        !g_vision_ball_distance_valid) {
        return 0U;
    }
    g_ball_balance_last_vision_update_count = update_count;

    float position_cm = clamp_float(g_vision_ball_distance_cm,
        -BALL_BALANCE_TASK3_MAX_OFFSET_CM,
        BALL_BALANCE_TASK3_MAX_OFFSET_CM);
    float reported_velocity_cm_s = clamp_float(
        g_vision_ball_velocity_cm_s,
        -BALL_BALANCE_TASK3_MAX_VELOCITY_CM_S,
        BALL_BALANCE_TASK3_MAX_VELOCITY_CM_S);

    if (!g_ball_balance_task3_filter_initialized) {
        g_ball_balance_task3_filtered_position_cm = position_cm;
        g_ball_balance_task3_filtered_velocity_cm_s =
            reported_velocity_cm_s;
        g_ball_balance_task3_filter_initialized = 1U;
    } else {
        uint32_t elapsed_ms = now_ms - g_ball_balance_task3_last_vision_ms;
        if (elapsed_ms == 0U) {
            elapsed_ms = 1U;
        }
        float frame_dt_seconds = (float)elapsed_ms * 0.001f;
        float differentiated_velocity = clamp_float(
            (position_cm - g_ball_balance_task3_last_raw_position_cm) /
                frame_dt_seconds,
            -BALL_BALANCE_TASK3_MAX_VELOCITY_CM_S,
            BALL_BALANCE_TASK3_MAX_VELOCITY_CM_S);
        float fused_velocity =
            BALL_BALANCE_TASK3_VISION_VELOCITY_WEIGHT *
                reported_velocity_cm_s +
            (1.0f - BALL_BALANCE_TASK3_VISION_VELOCITY_WEIGHT) *
                differentiated_velocity;

        g_ball_balance_task3_filtered_position_cm +=
            BALL_BALANCE_TASK3_POSITION_FILTER_ALPHA *
            (position_cm - g_ball_balance_task3_filtered_position_cm);
        g_ball_balance_task3_filtered_velocity_cm_s +=
            BALL_BALANCE_TASK3_VELOCITY_FILTER_ALPHA *
            (fused_velocity -
                g_ball_balance_task3_filtered_velocity_cm_s);
    }

    g_ball_balance_task3_last_raw_position_cm = position_cm;
    g_ball_balance_task3_last_vision_ms = now_ms;
    g_ball_balance_offset_cm = position_cm;
    g_ball_balance_task3_velocity_cm_s =
        g_ball_balance_task3_filtered_velocity_cm_s;
    return 1U;
}

static void ball_balance_task3_update_control(uint32_t now_ms,
    float dt_seconds)
{
    uint8_t vision_updated = ball_balance_task3_update_vision(now_ms);

    uint8_t vision_fresh = g_ball_balance_task3_filter_initialized &&
        ((uint32_t)(now_ms - g_ball_balance_task3_last_vision_ms) <=
            BALL_BALANCE_TASK3_POSITION_FEEDBACK_FRESH_MS);
    ball_balance_task4_update(vision_fresh && vision_updated);
    float position_error_cm = vision_fresh ?
        (g_ball_balance_task4_setpoint_cm -
            g_ball_balance_task3_filtered_position_cm) : 0.0f;
    float error_delta_cm = 0.0f;
    if (vision_fresh && g_ball_balance_task3_previous_error_valid) {
        error_delta_cm = position_error_cm -
            g_ball_balance_task3_previous_error_cm;
    }
    if (vision_fresh) {
        g_ball_balance_task3_previous_error_cm = position_error_cm;
        g_ball_balance_task3_previous_error_valid = 1U;
    } else {
        g_ball_balance_task3_previous_error_valid = 0U;
    }
    g_ball_balance_task3_error_delta_cm = error_delta_cm;

    float active_kp = g_ball_balance_task4_active ? g_t4_kp : g_t3_kp;
    float active_ki = g_ball_balance_task4_active ? g_t4_ki : g_t3_ki;
    float active_kd = g_ball_balance_task4_active ? g_t4_kd : g_t3_kd;

    g_t3_e = position_error_cm;
    g_t3_p = active_kp * g_t3_e;
    if (vision_fresh) {
        g_t3_i = clamp_float(g_t3_i + active_ki * g_t3_e,
            -BALL_BALANCE_TASK3_I_LIMIT_DEG,
            BALL_BALANCE_TASK3_I_LIMIT_DEG);
    }
    g_t3_d = active_kd * error_delta_cm;
    g_t3_pid = g_t3_p + g_t3_i + g_t3_d;
    g_ball_balance_task3_position_angle_degrees = g_t3_p + g_t3_i;
    g_ball_balance_task3_speed_compensation_degrees = g_t3_d;

    uint8_t imu_fresh = g_ball_balance_task3_accel_calibrated &&
        ((uint32_t)(now_ms - g_ball_balance_task3_last_imu_ms) <=
            BALL_BALANCE_TASK3_IMU_TIMEOUT_MS);
    g_ball_balance_task3_accel_feedforward_gain =
        ball_balance_task3_accel_gain();
    if (imu_fresh) {
        /* Apply measured vehicle acceleration in the configured axis direction. */
        g_ball_balance_task3_accel_compensation_degrees =
            g_ball_balance_task3_filtered_accel_g * 57.29578f *
                g_ball_balance_task3_accel_feedforward_gain;
    } else {
        g_ball_balance_task3_accel_compensation_degrees = 0.0f;
    }

    float task4_zero_offset = g_ball_balance_task4_active ?
        BALL_BALANCE_TASK4_ZERO_OFFSET_DEG : 0.0f;
    g_t3_out = clamp_angle_degrees(g_t3_pid +
        g_ball_balance_task3_accel_compensation_degrees +
        task4_zero_offset);
    g_ball_balance_desired_angle_degrees = g_t3_out;
    g_ball_balance_desired_angle_valid = 1U;

    float maximum_step = BALL_BALANCE_TASK3_MAX_COMMAND_RATE_DEG_S *
        dt_seconds;
    float next_angle = clamp_float(g_ball_balance_desired_angle_degrees,
        g_ball_balance_slewed_angle_degrees - maximum_step,
        g_ball_balance_slewed_angle_degrees + maximum_step);

    uint8_t angle_feedback_fresh = g_stepper_realtime_position_valid &&
        ((uint32_t)(now_ms - g_stepper_position_last_ms) <=
            (2U * STEPPER_POSITION_POLL_INTERVAL_MS + 20U));
    if (angle_feedback_fresh) {
        next_angle = clamp_float(next_angle,
            g_stepper_realtime_angle_degrees -
                BALL_BALANCE_TASK3_TRACKING_WINDOW_DEG,
            g_stepper_realtime_angle_degrees +
                BALL_BALANCE_TASK3_TRACKING_WINDOW_DEG);
        g_ball_balance_task3_angle_tracking_error_degrees =
            g_ball_balance_desired_angle_degrees -
                g_stepper_realtime_angle_degrees;
    } else {
        g_ball_balance_task3_angle_tracking_error_degrees = 0.0f;
    }
    g_ball_balance_slewed_angle_degrees = clamp_angle_degrees(next_angle);
}

static uint16_t ball_balance_task2_speed_rpm(float position_cm)
{
    float distance_cm = abs_float(position_cm);

    if (distance_cm < BALL_BALANCE_TASK2_SPEED_LEVEL1_CM) {
        return BALL_BALANCE_TASK2_SPEED_LEVEL1_RPM;
    }
    if (distance_cm < BALL_BALANCE_TASK2_SPEED_LEVEL2_CM) {
        return BALL_BALANCE_TASK2_SPEED_LEVEL2_RPM;
    }
    if (distance_cm < BALL_BALANCE_TASK2_SPEED_LEVEL3_CM) {
        return BALL_BALANCE_TASK2_SPEED_LEVEL3_RPM;
    }
    if (distance_cm < BALL_BALANCE_TASK2_SPEED_LEVEL4_CM) {
        return BALL_BALANCE_TASK2_SPEED_LEVEL4_RPM;
    }
    return BALL_BALANCE_TASK2_SPEED_FAR_RPM;
}

static float ball_balance_task2_output_gain(float position_cm)
{
    float normalized_distance = clamp_float(
        abs_float(position_cm) /
            BALL_BALANCE_TASK2_OUTPUT_GAIN_RANGE_CM,
        0.0f, 1.0f);

    return BALL_BALANCE_TASK2_OUTPUT_GAIN_MAX -
        normalized_distance *
            (BALL_BALANCE_TASK2_OUTPUT_GAIN_MAX -
                BALL_BALANCE_TASK2_OUTPUT_GAIN_MIN);
}

static void ball_balance_task2_reset(uint32_t now_ms)
{
    g_ball_balance_task2_average_position_cm = 0.0f;
    g_ball_balance_task2_filtered_position_cm = 0.0f;
    g_ball_balance_task2_estimated_velocity_cm_s = 0.0f;
    g_ball_balance_task2_filtered_velocity_cm_s = 0.0f;
    g_ball_balance_task2_error_cm = 0.0f;
    g_ball_balance_task2_p_degrees = 0.0f;
    g_ball_balance_task2_i_degrees = 0.0f;
    g_ball_balance_task2_d_degrees = 0.0f;
    g_ball_balance_task2_overrange_compensation_deg_s = 0.0f;
    g_ball_balance_task2_integral_cm_s = 0.0f;
    g_ball_balance_task2_output_degrees = 0.0f;
    g_ball_balance_task2_adjustment_rate_deg_s = 0.0f;
    g_ball_balance_task2_increment_degrees = 0.0f;
    g_ball_balance_task2_accumulated_target_degrees = 0.0f;
    g_ball_balance_task2_output_gain =
        BALL_BALANCE_TASK2_OUTPUT_GAIN_MAX;
    g_ball_balance_task2_command_speed_rpm =
        BALL_BALANCE_TASK2_SPEED_LEVEL1_RPM;
    g_ball_balance_task2_filter_initialized = 0U;
    g_ball_balance_task2_last_update_ms = now_ms;
    g_ball_balance_task2_average_position_valid = 0U;
}

static void ball_balance_task2_update(
    float position_cm, float velocity_cm_s, uint32_t now_ms,
    float dt_seconds)
{
    g_ball_balance_task2_last_update_ms = now_ms;
    g_ball_balance_task2_average_position_cm = position_cm;
    g_ball_balance_task2_average_position_valid = 1U;
    g_ball_balance_task2_filtered_position_cm = position_cm;
    g_ball_balance_task2_estimated_velocity_cm_s = velocity_cm_s;
    g_ball_balance_task2_filtered_velocity_cm_s = velocity_cm_s;
    g_ball_balance_task2_filter_initialized = 1U;

    g_ball_balance_task2_error_cm =
        -g_ball_balance_task2_filtered_position_cm;
    float control_error = g_ball_balance_task2_error_cm;
    if (abs_float(control_error) <=
        BALL_BALANCE_TASK2_POSITION_DEADBAND_CM) {
        control_error = 0.0f;
    }

    float candidate_integral = g_ball_balance_task2_integral_cm_s;
    if ((dt_seconds > 0.0f) &&
        (abs_float(g_ball_balance_task2_error_cm) <=
            BALL_BALANCE_TASK2_INTEGRAL_ERROR_CM) &&
        (abs_float(g_ball_balance_task2_filtered_velocity_cm_s) <=
            BALL_BALANCE_TASK2_INTEGRAL_VELOCITY_CM_S)) {
        candidate_integral = clamp_float(
            candidate_integral + control_error * dt_seconds,
            -BALL_BALANCE_TASK2_INTEGRAL_LIMIT_CM_S,
            BALL_BALANCE_TASK2_INTEGRAL_LIMIT_CM_S);
    }

    g_ball_balance_task2_p_degrees = clamp_float(
        BALL_BALANCE_TASK2_KP_DEG_PER_CM * control_error,
        -BALL_BALANCE_TASK2_P_LIMIT_DEG,
        BALL_BALANCE_TASK2_P_LIMIT_DEG);
    g_ball_balance_task2_i_degrees =
        BALL_BALANCE_TASK2_KI_DEG_PER_CM_S * candidate_integral;
    g_ball_balance_task2_d_degrees = clamp_float(
        -BALL_BALANCE_TASK2_KD_DEG_S_PER_CM *
            g_ball_balance_task2_filtered_velocity_cm_s,
        -BALL_BALANCE_TASK2_D_LIMIT_DEG,
        BALL_BALANCE_TASK2_D_LIMIT_DEG);

    g_ball_balance_task2_output_gain =
        ball_balance_task2_output_gain(
            g_ball_balance_task2_filtered_position_cm);
    float raw_output = (g_ball_balance_task2_p_degrees +
        g_ball_balance_task2_i_degrees +
        g_ball_balance_task2_d_degrees) *
        g_ball_balance_task2_output_gain;
    float position_magnitude_cm =
        abs_float(g_ball_balance_task2_error_cm);
    if (position_magnitude_cm >
        BALL_BALANCE_TASK2_OVERRANGE_THRESHOLD_CM) {
        float compensation =
            (position_magnitude_cm -
                BALL_BALANCE_TASK2_OVERRANGE_THRESHOLD_CM) *
            BALL_BALANCE_TASK2_OVERRANGE_GAIN_DEG_S_CM;
        compensation = clamp_float(compensation, 0.0f,
            BALL_BALANCE_TASK2_OVERRANGE_MAX_DEG_S);
        g_ball_balance_task2_overrange_compensation_deg_s =
            (g_ball_balance_task2_error_cm < 0.0f) ?
                -compensation : compensation;
        raw_output += g_ball_balance_task2_overrange_compensation_deg_s;
    } else {
        g_ball_balance_task2_overrange_compensation_deg_s = 0.0f;
    }
    g_ball_balance_task2_output_degrees = raw_output;

    if (g_ball_balance_task2_output_degrees == raw_output) {
        g_ball_balance_task2_integral_cm_s = candidate_integral;
    } else {
        g_ball_balance_task2_i_degrees =
            BALL_BALANCE_TASK2_KI_DEG_PER_CM_S *
            g_ball_balance_task2_integral_cm_s;
    }

    g_ball_balance_task2_adjustment_rate_deg_s =
        g_ball_balance_task2_output_degrees;
    g_ball_balance_task2_increment_degrees =
        g_ball_balance_task2_adjustment_rate_deg_s * dt_seconds;
    g_ball_balance_task2_accumulated_target_degrees =
        clamp_angle_degrees(
            g_ball_balance_task2_accumulated_target_degrees +
            g_ball_balance_task2_increment_degrees);
    g_ball_balance_desired_angle_degrees =
        g_ball_balance_task2_accumulated_target_degrees;
    g_ball_balance_desired_angle_valid = 1U;
}

static StepperStatus ball_balance_move_to_angle(float angle_degrees,
    uint16_t speed_rpm, uint8_t acceleration)
{
    g_ball_balance_target_angle_degrees =
        clamp_angle_degrees(angle_degrees);
    return Stepper_MoveToAbsoluteDegreesWithProfile(
        g_ball_balance_target_angle_degrees, speed_rpm, acceleration);
}

float BallBalance_OffsetToAngle(float offset_cm)
{
    if (offset_cm != offset_cm) {
        return 0.0f;
    }
    return -clamp_offset_cm(offset_cm) * BALL_BALANCE_ANGLE_PER_CM;
}

StepperStatus BallBalance_SetCurrentPositionAsCenter(void)
{
    StepperStatus status = Stepper_SetCurrentPositionZero();
    if ((status != STEPPER_STATUS_OK) &&
        (status != STEPPER_STATUS_BUSY)) {
        g_ball_balance_center_valid = 0U;
    }
    return status;
}

StepperStatus BallBalance_MoveToOffset(float offset_cm,
    uint16_t speed_rpm, uint8_t acceleration)
{
    if ((offset_cm != offset_cm) || !g_ball_balance_center_valid) {
        return STEPPER_STATUS_INVALID_ARGUMENT;
    }

    float limited_offset_cm = clamp_offset_cm(offset_cm);
    float target_angle_degrees =
        -limited_offset_cm * BALL_BALANCE_ANGLE_PER_CM;
    g_ball_balance_offset_cm = limited_offset_cm;
    return ball_balance_move_to_angle(
        target_angle_degrees, speed_rpm, acceleration);
}

static void ball_balance_enter_ready(uint32_t now_ms)
{
    g_ball_balance_calibration_state = BALL_BALANCE_CALIBRATION_READY;
    g_ball_balance_last_vision_update_count =
        g_vision_ball_distance_update_count;
    g_ball_balance_command_angle_valid = 0U;
    g_ball_balance_desired_angle_valid = 0U;
    g_ball_balance_desired_angle_degrees = 0.0f;
    g_ball_balance_slewed_angle_degrees = 0.0f;
    g_ball_balance_last_control_tick_count = g_control_20ms_tick_count;
    ball_balance_task2_reset(now_ms);
}

static void ball_balance_try_set_zero(uint32_t now_ms)
{
    g_ball_balance_calibration_action_ms = now_ms;
    g_ball_balance_last_status = BallBalance_SetCurrentPositionAsCenter();
    if ((g_ball_balance_last_status != STEPPER_STATUS_OK) &&
        (g_ball_balance_last_status != STEPPER_STATUS_BUSY)) {
        g_ball_balance_error_count++;
    }
}

void BallBalance_Init(uint32_t now_ms)
{
    g_ball_balance_offset_cm = 0.0f;
    g_ball_balance_desired_angle_degrees = 0.0f;
    g_ball_balance_slewed_angle_degrees = 0.0f;
    g_ball_balance_target_angle_degrees = 0.0f;
    g_ball_balance_center_valid = 0U;
    g_ball_balance_last_status = STEPPER_STATUS_OK;
    g_ball_balance_command_count = 0U;
    g_ball_balance_error_count = 0U;
    g_ball_balance_task4_active = 0U;
    g_ball_balance_task4_phase = BALL_BALANCE_TASK4_INACTIVE;
    g_ball_balance_task4_setpoint_cm =
        BALL_BALANCE_TASK3_DEFAULT_SETPOINT_CM;
    g_ball_balance_task4_stable_samples = 0U;
    g_ball_balance_task4_key_gpio_level = 1U;
    g_ball_balance_task4_start_count = 0U;
    g_ball_balance_task4_key_initialized = 0U;
    g_ball_balance_task4_key_raw_pressed = 0U;
    g_ball_balance_task4_key_stable_pressed = 0U;
    g_ball_balance_task4_key_change_ms = now_ms;
    g_ball_balance_active_task = BALL_BALANCE_ACTIVE_TASK;
    g_ball_balance_task1_velocity_cm_s = 0.0f;
    g_ball_balance_task1_position_angle_degrees = 0.0f;
    g_ball_balance_task1_speed_compensation_degrees = 0.0f;
    ball_balance_task3_reset(now_ms);
    g_ball_balance_last_vision_update_count =
        g_vision_ball_distance_update_count;
    g_ball_balance_calibration_action_ms = now_ms;
    g_ball_balance_last_at_target_update_count =
        g_stepper_at_target_update_count;
    g_ball_balance_last_zero_update_count =
        g_stepper_zero_update_count;
    g_ball_balance_last_control_tick_count = g_control_20ms_tick_count;
    g_ball_balance_last_command_angle_degrees = 0.0f;
    g_ball_balance_command_angle_valid = 0U;
    g_ball_balance_desired_angle_valid = 0U;
    ball_balance_task2_reset(now_ms);

    g_ball_balance_calibration_state =
        BALL_BALANCE_CALIBRATION_WAIT_VISION;
}

void BallBalance_Process(uint32_t now_ms)
{
    ball_balance_task4_process_key(now_ms);

    if (g_ball_balance_active_task == BALL_BALANCE_TASK_THREE) {
        /* Collect stationary IMU bias during calibration/startup. */
        ball_balance_task3_update_imu(now_ms);
    }

    if (g_ball_balance_calibration_state ==
        BALL_BALANCE_CALIBRATION_WAIT_VISION) {
        uint32_t vision_update_count =
            g_vision_ball_distance_update_count;
        uint8_t fresh_vision_frame =
            g_vision_ball_distance_valid &&
            (vision_update_count !=
                g_ball_balance_last_vision_update_count) &&
            ((uint32_t)(now_ms - g_vision_ball_distance_last_ms) <=
                BALL_BALANCE_VISION_TIMEOUT_MS);
        if (!fresh_vision_frame) {
            return;
        }

        g_ball_balance_last_vision_update_count = vision_update_count;
        g_ball_balance_calibration_action_ms = now_ms;
        g_ball_balance_last_status = Stepper_RotateDegreesWithProfile(
            BALL_BALANCE_CALIBRATION_ROTATION_DEGREES,
            BALL_BALANCE_CONTROL_SPEED_RPM,
            BALL_BALANCE_CONTROL_ACCELERATION);
        if (g_ball_balance_last_status == STEPPER_STATUS_OK) {
            g_ball_balance_calibration_state =
                BALL_BALANCE_CALIBRATION_WAIT_ROTATION;
        } else {
            g_ball_balance_error_count++;
            g_ball_balance_calibration_state =
                BALL_BALANCE_CALIBRATION_FAULT;
        }
        return;
    }

    if (g_ball_balance_calibration_state ==
        BALL_BALANCE_CALIBRATION_WAIT_ROTATION) {
        if ((uint32_t)(now_ms - g_ball_balance_calibration_action_ms) >
            BALL_BALANCE_CALIBRATION_TIMEOUT_MS) {
            g_ball_balance_error_count++;
            g_ball_balance_calibration_state =
                BALL_BALANCE_CALIBRATION_FAULT;
            return;
        }
        if (!g_stepper_at_target_valid ||
            (g_stepper_at_target_update_count ==
                g_ball_balance_last_at_target_update_count)) {
            return;
        }

        g_ball_balance_last_at_target_update_count =
            g_stepper_at_target_update_count;
        if (!g_stepper_at_target) {
            return;
        }

        if (!BALL_BALANCE_VISION_CONTROL_ENABLED) {
            g_ball_balance_calibration_state =
                BALL_BALANCE_CALIBRATION_ROTATION_COMPLETE;
            return;
        }

        g_ball_balance_calibration_state =
            BALL_BALANCE_CALIBRATION_SET_ZERO;
        ball_balance_try_set_zero(now_ms);
        return;
    }

    if (g_ball_balance_calibration_state ==
        BALL_BALANCE_CALIBRATION_SET_ZERO) {
        if (g_stepper_zero_update_count !=
            g_ball_balance_last_zero_update_count) {
            g_ball_balance_last_zero_update_count =
                g_stepper_zero_update_count;
            if (g_stepper_zero_success) {
                g_ball_balance_offset_cm = 0.0f;
                g_ball_balance_target_angle_degrees = 0.0f;
                g_ball_balance_center_valid = 1U;
                ball_balance_enter_ready(now_ms);
                return;
            }
            g_ball_balance_error_count++;
        }
        if ((uint32_t)(now_ms - g_ball_balance_calibration_action_ms) >=
            BALL_BALANCE_ZERO_RETRY_MS) {
            ball_balance_try_set_zero(now_ms);
        }
        return;
    }

    if (g_ball_balance_calibration_state !=
        BALL_BALANCE_CALIBRATION_READY) {
        return;
    }

    uint32_t vision_update_count = g_vision_ball_distance_update_count;
    if (g_ball_balance_active_task == BALL_BALANCE_TASK_TWO) {
        /* Run task two on a fixed 20 ms period, using the newest raw frame. */
        uint32_t control_tick_count = g_control_20ms_tick_count;
        if (control_tick_count != g_ball_balance_last_control_tick_count) {
            const float dt_seconds =
                (float)BALL_BALANCE_TASK2_CONTROL_PERIOD_MS * 0.001f;
            g_ball_balance_last_control_tick_count = control_tick_count;

            if (g_vision_ball_distance_valid &&
                ((uint32_t)(now_ms - g_vision_ball_distance_last_ms) <=
                    BALL_BALANCE_VISION_TIMEOUT_MS)) {
                g_ball_balance_offset_cm = g_vision_ball_distance_cm;
                ball_balance_task2_update(
                    g_vision_ball_distance_cm,
                    g_vision_ball_velocity_cm_s,
                    now_ms, dt_seconds);
            }
        }
    } else if (g_ball_balance_active_task == BALL_BALANCE_TASK_THREE) {
        uint32_t control_tick_count = g_control_20ms_tick_count;
        uint8_t task3_start_frame_ready =
            g_vision_ball_distance_valid &&
            (vision_update_count != g_ball_balance_last_vision_update_count) &&
            ((uint32_t)(now_ms - g_vision_ball_distance_last_ms) <=
                BALL_BALANCE_VISION_TIMEOUT_MS);

        /* Do not start task-three control until a fresh vision frame arrives. */
        if (!g_ball_balance_task3_filter_initialized &&
            !task3_start_frame_ready) {
            g_ball_balance_last_control_tick_count = control_tick_count;
        } else if (control_tick_count !=
            g_ball_balance_last_control_tick_count) {
            uint32_t elapsed_ticks =
                control_tick_count - g_ball_balance_last_control_tick_count;
            if (elapsed_ticks > 3U) {
                elapsed_ticks = 3U;
            }
            g_ball_balance_last_control_tick_count = control_tick_count;
            ball_balance_task3_update_control(now_ms,
                (float)(elapsed_ticks *
                    BALL_BALANCE_TASK3_CONTROL_PERIOD_MS) * 0.001f);
        }
    } else if (vision_update_count != g_ball_balance_last_vision_update_count) {
        g_ball_balance_last_vision_update_count = vision_update_count;
        if (g_vision_ball_distance_valid &&
            ((uint32_t)(now_ms - g_vision_ball_distance_last_ms) <=
                BALL_BALANCE_VISION_TIMEOUT_MS)) {
            g_ball_balance_offset_cm =
                clamp_offset_cm(g_vision_ball_distance_cm);
            g_ball_balance_task1_velocity_cm_s =
                g_vision_ball_velocity_cm_s;
            g_ball_balance_task1_position_angle_degrees =
                BallBalance_OffsetToAngle(g_ball_balance_offset_cm);
            g_ball_balance_task1_speed_compensation_degrees =
                -BALL_BALANCE_TASK1_KD_DEG_S_PER_CM *
                    g_ball_balance_task1_velocity_cm_s;
            g_ball_balance_desired_angle_degrees = clamp_angle_degrees(
                g_ball_balance_task1_position_angle_degrees +
                g_ball_balance_task1_speed_compensation_degrees);
            g_ball_balance_desired_angle_valid = 1U;
        }
    }

    uint8_t vision_stale =
        ((uint32_t)(now_ms - g_vision_ball_distance_last_ms) >
            BALL_BALANCE_VISION_TIMEOUT_MS) ? 1U : 0U;
    if (vision_stale &&
        (g_ball_balance_active_task == BALL_BALANCE_TASK_TWO)) {
        g_ball_balance_desired_angle_degrees = 0.0f;
        g_ball_balance_desired_angle_valid = 1U;
        g_ball_balance_task2_accumulated_target_degrees = 0.0f;
        g_ball_balance_task2_increment_degrees = 0.0f;
        g_ball_balance_task2_adjustment_rate_deg_s = 0.0f;
        g_ball_balance_task2_integral_cm_s = 0.0f;
        g_ball_balance_task2_i_degrees = 0.0f;
    }

    if (!g_ball_balance_desired_angle_valid ||
        (vision_stale &&
            (g_ball_balance_active_task == BALL_BALANCE_TASK_ONE))) {
        return;
    }

    if (g_ball_balance_active_task != BALL_BALANCE_TASK_THREE) {
        g_ball_balance_slewed_angle_degrees =
            g_ball_balance_desired_angle_degrees;
    }

    float command_delta_degrees =
        g_ball_balance_slewed_angle_degrees -
        g_ball_balance_last_command_angle_degrees;
    uint8_t absolute_task_must_cross_zero = 0U;
    if ((g_ball_balance_active_task == BALL_BALANCE_TASK_ONE) ||
        (g_ball_balance_active_task == BALL_BALANCE_TASK_THREE)) {
        absolute_task_must_cross_zero =
            ((g_ball_balance_slewed_angle_degrees > 0.0f) &&
                (g_ball_balance_last_command_angle_degrees <= 0.0f)) ||
            ((g_ball_balance_slewed_angle_degrees < 0.0f) &&
                (g_ball_balance_last_command_angle_degrees >= 0.0f)) ||
            ((g_ball_balance_slewed_angle_degrees == 0.0f) &&
                (g_ball_balance_last_command_angle_degrees != 0.0f));
    }
    if (g_ball_balance_command_angle_valid &&
        (abs_float(command_delta_degrees) <
            BALL_BALANCE_COMMAND_DEADBAND_DEGREES) &&
            !absolute_task_must_cross_zero) {
        return;
    }

    if (g_ball_balance_active_task == BALL_BALANCE_TASK_TWO) {
        /* Task two's accumulated target is sent as an F3 relative move. */
        g_ball_balance_task2_command_speed_rpm =
            ball_balance_task2_speed_rpm(g_ball_balance_offset_cm);
        g_ball_balance_last_status = Stepper_RotateDegreesWithProfile(
            command_delta_degrees,
            g_ball_balance_task2_command_speed_rpm,
            BALL_BALANCE_CONTROL_ACCELERATION);
    } else if (g_ball_balance_active_task == BALL_BALANCE_TASK_THREE) {
        g_ball_balance_last_status = ball_balance_move_to_angle(
            g_ball_balance_slewed_angle_degrees,
            BALL_BALANCE_TASK3_SPEED_RPM,
            BALL_BALANCE_CONTROL_ACCELERATION);
    } else {
        g_ball_balance_last_status = ball_balance_move_to_angle(
            g_ball_balance_slewed_angle_degrees,
            BALL_BALANCE_TASK1_SPEED_RPM,
            BALL_BALANCE_CONTROL_ACCELERATION);
    }
    if (g_ball_balance_last_status == STEPPER_STATUS_OK) {
        g_ball_balance_last_command_angle_degrees =
            g_ball_balance_slewed_angle_degrees;
        g_ball_balance_target_angle_degrees =
            g_ball_balance_slewed_angle_degrees;
        g_ball_balance_command_angle_valid = 1U;
        g_ball_balance_command_count++;
    } else if (g_ball_balance_last_status != STEPPER_STATUS_BUSY) {
        g_ball_balance_error_count++;
    }
}
