#include "steppper.h"

#include <stddef.h>

#include "headerfile.h"

#define STEPPER_FRAME_HEADER             0xC5U
#define STEPPER_FRAME_TAIL               0x5CU
#define STEPPER_COMMAND_ABSOLUTE_MOVE    0xF2U
#define STEPPER_COMMAND_RELATIVE_MOVE    0xF3U
#define STEPPER_COMMAND_ZERO_POSITION    0xF8U
#define STEPPER_COMMAND_ENABLE           0xFAU
#define STEPPER_COMMAND_READ_POSITION    0x2AU
#define STEPPER_COMMAND_READ_AT_TARGET   0x30U
#define STEPPER_DEVICE_SUCCESS           0x01U
#define STEPPER_DIRECTION_FORWARD        0U
#define STEPPER_DIRECTION_REVERSE        1U
#define STEPPER_MOVE_PAYLOAD_SIZE        8U
#define STEPPER_MAX_FRAME_SIZE           13U
#define STEPPER_MOVE_RESPONSE_SIZE       6U
#define STEPPER_ENABLE_RESPONSE_SIZE     7U
#define STEPPER_POSITION_RESPONSE_SIZE   10U
#define STEPPER_MAX_RESPONSE_SIZE        STEPPER_POSITION_RESPONSE_SIZE
#define STEPPER_MAX_DEGREES              30198988.0f

#define STEPPER_UART_RX_INTERRUPT_MASK                              \
    (DL_UART_MAIN_INTERRUPT_RX |                                    \
     DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR |                      \
     DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |                         \
     DL_UART_MAIN_INTERRUPT_BREAK_ERROR |                           \
     DL_UART_MAIN_INTERRUPT_PARITY_ERROR |                          \
     DL_UART_MAIN_INTERRUPT_FRAMING_ERROR)

typedef enum {
    STEPPER_TRANSACTION_ENABLE = 0,
    STEPPER_TRANSACTION_ZERO,
    STEPPER_TRANSACTION_ABSOLUTE_MOVE,
    STEPPER_TRANSACTION_RELATIVE_MOVE,
    STEPPER_TRANSACTION_READ_POSITION,
    STEPPER_TRANSACTION_READ_AT_TARGET
} StepperTransactionKind;

typedef struct {
    uint8_t frame[STEPPER_MAX_FRAME_SIZE];
    uint8_t frame_length;
    uint8_t response_size;
    uint8_t command;
    uint8_t timeout_ms;
    StepperTransactionKind kind;
} StepperTransaction;

volatile StepperStatus g_stepper_last_status;
volatile uint8_t g_stepper_last_device_code;
volatile uint32_t g_stepper_command_count;
volatile uint32_t g_stepper_timeout_count;
volatile uint32_t g_stepper_last_position_counts;
volatile float g_stepper_last_degrees;
volatile int32_t g_stepper_realtime_position_counts;
volatile float g_stepper_realtime_angle_degrees;
volatile uint8_t g_stepper_realtime_position_valid;
volatile uint32_t g_stepper_position_update_count;
volatile uint32_t g_stepper_position_last_ms;
volatile uint8_t g_stepper_at_target;
volatile uint8_t g_stepper_at_target_valid;
volatile uint32_t g_stepper_at_target_update_count;
volatile uint8_t g_stepper_transaction_active;
volatile uint8_t g_stepper_queue_depth;
volatile uint32_t g_stepper_queue_overflow_count;
volatile uint32_t g_stepper_uart_error_count;
volatile uint8_t g_stepper_zero_success;
volatile uint32_t g_stepper_zero_update_count;

static StepperTransaction g_stepper_queue[STEPPER_TRANSACTION_QUEUE_SIZE];
static uint8_t g_stepper_queue_head;
static uint8_t g_stepper_queue_tail;
static uint8_t g_stepper_queue_count;
static volatile StepperTransaction g_stepper_active_transaction;
static volatile uint8_t g_stepper_tx_index;
static volatile uint8_t g_stepper_rx_index;
static volatile uint8_t g_stepper_response_complete;
static volatile uint8_t g_stepper_response[STEPPER_MAX_RESPONSE_SIZE];
static uint32_t g_stepper_transaction_start_ms;
static uint32_t g_stepper_last_poll_ms;
static uint8_t g_stepper_poll_started;
static uint8_t g_stepper_enabled;

static uint8_t stepper_checksum(const uint8_t *data, uint8_t length)
{
    uint8_t checksum = 0U;

    for (uint8_t i = 0U; i < length; i++) {
        checksum = (uint8_t)(checksum + data[i]);
    }
    return checksum;
}

static void stepper_flush_rx(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_STEPPER_INST)) {
        (void)UART_STEPPER_INST->RXDATA;
    }
}

static void stepper_build_transaction(StepperTransaction *transaction,
    StepperTransactionKind kind, uint8_t command, const uint8_t *payload,
    uint8_t payload_length, uint8_t response_size, uint8_t timeout_ms)
{
    transaction->frame[0] = STEPPER_FRAME_HEADER;
    transaction->frame[1] = STEPPER_DEVICE_ADDRESS;
    transaction->frame[2] = command;
    for (uint8_t i = 0U; i < payload_length; i++) {
        transaction->frame[3U + i] = payload[i];
    }
    transaction->frame[3U + payload_length] =
        stepper_checksum(transaction->frame,
            (uint8_t)(3U + payload_length));
    transaction->frame[4U + payload_length] = STEPPER_FRAME_TAIL;
    transaction->frame_length = (uint8_t)(5U + payload_length);
    transaction->response_size = response_size;
    transaction->command = command;
    transaction->timeout_ms = timeout_ms;
    transaction->kind = kind;
}

static StepperStatus stepper_enqueue(const StepperTransaction *transaction)
{
    if (transaction->kind == STEPPER_TRANSACTION_ABSOLUTE_MOVE) {
        uint8_t index = g_stepper_queue_head;
        for (uint8_t i = 0U; i < g_stepper_queue_count; i++) {
            if (g_stepper_queue[index].kind ==
                STEPPER_TRANSACTION_ABSOLUTE_MOVE) {
                g_stepper_queue[index] = *transaction;
                g_stepper_last_status = STEPPER_STATUS_OK;
                return STEPPER_STATUS_OK;
            }
            index++;
            if (index >= STEPPER_TRANSACTION_QUEUE_SIZE) {
                index = 0U;
            }
        }
    }

    if (g_stepper_queue_count >= STEPPER_TRANSACTION_QUEUE_SIZE) {
        g_stepper_queue_overflow_count++;
        g_stepper_last_status = STEPPER_STATUS_BUSY;
        return STEPPER_STATUS_BUSY;
    }

    g_stepper_queue[g_stepper_queue_tail] = *transaction;
    g_stepper_queue_tail++;
    if (g_stepper_queue_tail >= STEPPER_TRANSACTION_QUEUE_SIZE) {
        g_stepper_queue_tail = 0U;
    }
    g_stepper_queue_count++;
    g_stepper_queue_depth = g_stepper_queue_count;
    g_stepper_last_status = STEPPER_STATUS_OK;
    return STEPPER_STATUS_OK;
}

static StepperStatus stepper_enqueue_command(StepperTransactionKind kind,
    uint8_t command, const uint8_t *payload, uint8_t payload_length,
    uint8_t response_size, uint8_t timeout_ms)
{
    StepperTransaction transaction;

    if ((payload_length > STEPPER_MOVE_PAYLOAD_SIZE) ||
        ((payload == NULL) && (payload_length != 0U))) {
        g_stepper_last_status = STEPPER_STATUS_INVALID_ARGUMENT;
        return STEPPER_STATUS_INVALID_ARGUMENT;
    }

    stepper_build_transaction(&transaction, kind, command, payload,
        payload_length, response_size, timeout_ms);
    return stepper_enqueue(&transaction);
}

static uint8_t stepper_transaction_requires_enable(
    StepperTransactionKind kind)
{
    return ((kind == STEPPER_TRANSACTION_ABSOLUTE_MOVE) ||
            (kind == STEPPER_TRANSACTION_RELATIVE_MOVE)) ? 1U : 0U;
}

static void stepper_copy_to_active(const StepperTransaction *transaction)
{
    for (uint8_t i = 0U; i < transaction->frame_length; i++) {
        g_stepper_active_transaction.frame[i] = transaction->frame[i];
    }
    g_stepper_active_transaction.frame_length = transaction->frame_length;
    g_stepper_active_transaction.response_size = transaction->response_size;
    g_stepper_active_transaction.command = transaction->command;
    g_stepper_active_transaction.timeout_ms = transaction->timeout_ms;
    g_stepper_active_transaction.kind = transaction->kind;
}

static void stepper_fill_tx_fifo(void)
{
    while ((g_stepper_tx_index <
            g_stepper_active_transaction.frame_length) &&
           !DL_UART_Main_isTXFIFOFull(UART_STEPPER_INST)) {
        DL_UART_Main_transmitData(UART_STEPPER_INST,
            g_stepper_active_transaction.frame[g_stepper_tx_index]);
        g_stepper_tx_index++;
    }

    if (g_stepper_tx_index >=
        g_stepper_active_transaction.frame_length) {
        DL_UART_Main_disableInterrupt(UART_STEPPER_INST,
            DL_UART_MAIN_INTERRUPT_TX);
    }
}

static void stepper_begin_transaction(const StepperTransaction *transaction,
    uint32_t now_ms)
{
    stepper_copy_to_active(transaction);
    g_stepper_tx_index = 0U;
    g_stepper_rx_index = 0U;
    g_stepper_response_complete = 0U;
    g_stepper_transaction_start_ms = now_ms;
    g_stepper_last_device_code = 0U;
    g_stepper_transaction_active = 1U;

    stepper_flush_rx();
    stepper_fill_tx_fifo();
    if (g_stepper_tx_index <
        g_stepper_active_transaction.frame_length) {
        DL_UART_Main_enableInterrupt(UART_STEPPER_INST,
            DL_UART_MAIN_INTERRUPT_TX);
    }
    g_stepper_command_count++;
}

static void stepper_start_next(uint32_t now_ms)
{
    StepperTransaction transaction;

    if (g_stepper_transaction_active || (g_stepper_queue_count == 0U)) {
        return;
    }

    transaction = g_stepper_queue[g_stepper_queue_head];
    if (stepper_transaction_requires_enable(transaction.kind) &&
        !g_stepper_enabled) {
        const uint8_t enable_payload = 0U;
        StepperTransaction enable_transaction;
        stepper_build_transaction(&enable_transaction,
            STEPPER_TRANSACTION_ENABLE, STEPPER_COMMAND_ENABLE,
            &enable_payload, 1U, STEPPER_ENABLE_RESPONSE_SIZE,
            STEPPER_RESPONSE_TIMEOUT_MS);
        stepper_begin_transaction(&enable_transaction, now_ms);
        return;
    }

    g_stepper_queue_head++;
    if (g_stepper_queue_head >= STEPPER_TRANSACTION_QUEUE_SIZE) {
        g_stepper_queue_head = 0U;
    }
    g_stepper_queue_count--;
    g_stepper_queue_depth = g_stepper_queue_count;
    stepper_begin_transaction(&transaction, now_ms);
}

static StepperStatus stepper_validate_response(uint8_t *response)
{
    uint8_t size = g_stepper_active_transaction.response_size;

    if ((size < STEPPER_MOVE_RESPONSE_SIZE) ||
        (size > STEPPER_MAX_RESPONSE_SIZE) ||
        (response[0] != STEPPER_FRAME_HEADER) ||
        (response[1] != STEPPER_DEVICE_ADDRESS) ||
        (response[2] != g_stepper_active_transaction.command) ||
        (response[size - 1U] != STEPPER_FRAME_TAIL) ||
        (response[size - 2U] !=
            stepper_checksum(response, (uint8_t)(size - 2U)))) {
        return STEPPER_STATUS_BAD_RESPONSE;
    }

    g_stepper_last_device_code = response[3];
    return (response[3] == STEPPER_DEVICE_SUCCESS) ?
        STEPPER_STATUS_OK : STEPPER_STATUS_DEVICE_ERROR;
}

static void stepper_record_failure(StepperTransactionKind kind)
{
    if (kind == STEPPER_TRANSACTION_READ_POSITION) {
        g_stepper_realtime_position_valid = 0U;
    } else if (kind == STEPPER_TRANSACTION_READ_AT_TARGET) {
        g_stepper_at_target_valid = 0U;
    } else if (kind == STEPPER_TRANSACTION_ENABLE) {
        g_stepper_enabled = 0U;
    } else if (kind == STEPPER_TRANSACTION_ZERO) {
        g_stepper_zero_success = 0U;
        g_stepper_zero_update_count++;
    }
}

static StepperStatus stepper_apply_success(StepperTransactionKind kind,
    const uint8_t *response)
{
    if (kind == STEPPER_TRANSACTION_ENABLE) {
        g_stepper_enabled = 1U;
    } else if (kind == STEPPER_TRANSACTION_ZERO) {
        g_stepper_realtime_position_counts = 0;
        g_stepper_realtime_angle_degrees = 0.0f;
        g_stepper_realtime_position_valid = 1U;
        g_stepper_position_last_ms = millis();
        g_stepper_zero_success = 1U;
        g_stepper_zero_update_count++;
    } else if ((kind == STEPPER_TRANSACTION_ABSOLUTE_MOVE) ||
               (kind == STEPPER_TRANSACTION_RELATIVE_MOVE)) {
        g_stepper_at_target_valid = 0U;
    } else if (kind == STEPPER_TRANSACTION_READ_POSITION) {
        uint32_t raw_position = ((uint32_t)response[4] << 24U) |
                                ((uint32_t)response[5] << 16U) |
                                ((uint32_t)response[6] << 8U) |
                                (uint32_t)response[7];
        int32_t position_counts = (int32_t)raw_position;
        g_stepper_realtime_position_counts = position_counts;
        g_stepper_realtime_angle_degrees =
            (float)position_counts * 360.0f /
            (float)STEPPER_COUNTS_PER_REVOLUTION;
        g_stepper_realtime_position_valid = 1U;
        g_stepper_position_update_count++;
        g_stepper_position_last_ms = millis();
    } else if (kind == STEPPER_TRANSACTION_READ_AT_TARGET) {
        if (response[4] <= 1U) {
            g_stepper_at_target = response[4];
            g_stepper_at_target_valid = 1U;
            g_stepper_at_target_update_count++;
        } else {
            g_stepper_at_target_valid = 0U;
            return STEPPER_STATUS_BAD_RESPONSE;
        }
    }
    return STEPPER_STATUS_OK;
}

static void stepper_finish_active(StepperStatus status)
{
    uint8_t response[STEPPER_MAX_RESPONSE_SIZE];
    StepperTransactionKind kind = g_stepper_active_transaction.kind;

    DL_UART_Main_disableInterrupt(UART_STEPPER_INST,
        DL_UART_MAIN_INTERRUPT_TX);

    if (status == STEPPER_STATUS_OK) {
        uint8_t size = g_stepper_active_transaction.response_size;
        for (uint8_t i = 0U; i < size; i++) {
            response[i] = g_stepper_response[i];
        }
        status = stepper_validate_response(response);
        if (status == STEPPER_STATUS_OK) {
            status = stepper_apply_success(kind, response);
        }
    }

    if (status != STEPPER_STATUS_OK) {
        stepper_record_failure(kind);
    }
    if (status == STEPPER_STATUS_TIMEOUT) {
        g_stepper_timeout_count++;
    }
    g_stepper_last_status = status;
    g_stepper_response_complete = 0U;
    g_stepper_transaction_active = 0U;
}

static void stepper_queue_poll_commands(void)
{
    (void)stepper_enqueue_command(STEPPER_TRANSACTION_READ_POSITION,
        STEPPER_COMMAND_READ_POSITION, NULL, 0U,
        STEPPER_POSITION_RESPONSE_SIZE, STEPPER_POSITION_TIMEOUT_MS);
    (void)stepper_enqueue_command(STEPPER_TRANSACTION_READ_AT_TARGET,
        STEPPER_COMMAND_READ_AT_TARGET, NULL, 0U,
        STEPPER_ENABLE_RESPONSE_SIZE, STEPPER_POSITION_TIMEOUT_MS);
}

void Stepper_Init(void)
{
    g_stepper_queue_head = 0U;
    g_stepper_queue_tail = 0U;
    g_stepper_queue_count = 0U;
    g_stepper_queue_depth = 0U;
    g_stepper_transaction_active = 0U;
    g_stepper_response_complete = 0U;
    g_stepper_tx_index = 0U;
    g_stepper_rx_index = 0U;
    g_stepper_poll_started = 0U;
    g_stepper_enabled = 0U;
    g_stepper_position_last_ms = 0U;
    g_stepper_last_status = STEPPER_STATUS_OK;

    DL_UART_Main_disableInterrupt(UART_STEPPER_INST, 0xFFFFFFFFU);
    DL_UART_Main_clearInterruptStatus(UART_STEPPER_INST, 0xFFFFFFFFU);
    stepper_flush_rx();
    DL_UART_Main_setRXFIFOThreshold(
        UART_STEPPER_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setRXInterruptTimeout(UART_STEPPER_INST, 1U);
    DL_UART_Main_enableInterrupt(UART_STEPPER_INST,
        STEPPER_UART_RX_INTERRUPT_MASK);
    NVIC_SetPriority(UART_STEPPER_INST_INT_IRQN, 3U);
    NVIC_ClearPendingIRQ(UART_STEPPER_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_STEPPER_INST_INT_IRQN);
}

StepperStatus Stepper_SetCurrentPositionZero(void)
{
    return stepper_enqueue_command(STEPPER_TRANSACTION_ZERO,
        STEPPER_COMMAND_ZERO_POSITION, NULL, 0U,
        STEPPER_MOVE_RESPONSE_SIZE, STEPPER_RESPONSE_TIMEOUT_MS);
}

static StepperStatus stepper_enqueue_move(float degrees,
    uint16_t speed_rpm, uint8_t acceleration, uint8_t absolute)
{
    uint8_t payload[STEPPER_MOVE_PAYLOAD_SIZE];
    float magnitude;
    float count_value;
    uint32_t position_counts;
    StepperStatus status;

    if ((degrees != degrees) || (speed_rpm == 0U) ||
        (speed_rpm > 6000U) || (acceleration > 200U)) {
        g_stepper_last_status = STEPPER_STATUS_INVALID_ARGUMENT;
        return STEPPER_STATUS_INVALID_ARGUMENT;
    }
    if (!absolute && (degrees == 0.0f)) {
        g_stepper_last_degrees = 0.0f;
        g_stepper_last_position_counts = 0U;
        g_stepper_last_status = STEPPER_STATUS_OK;
        return STEPPER_STATUS_OK;
    }

    magnitude = (degrees < 0.0f) ? -degrees : degrees;
    if (magnitude > STEPPER_MAX_DEGREES) {
        g_stepper_last_status = STEPPER_STATUS_INVALID_ARGUMENT;
        return STEPPER_STATUS_INVALID_ARGUMENT;
    }

    count_value = magnitude *
        ((float)STEPPER_COUNTS_PER_REVOLUTION / 360.0f);
    position_counts = (uint32_t)(count_value + 0.5f);
    if (!absolute && (position_counts == 0U)) {
        g_stepper_last_status = STEPPER_STATUS_INVALID_ARGUMENT;
        return STEPPER_STATUS_INVALID_ARGUMENT;
    }

    payload[0] = (degrees < 0.0f) ?
        STEPPER_DIRECTION_REVERSE : STEPPER_DIRECTION_FORWARD;
    payload[1] = acceleration;
    payload[2] = (uint8_t)(speed_rpm >> 8U);
    payload[3] = (uint8_t)speed_rpm;
    payload[4] = (uint8_t)(position_counts >> 24U);
    payload[5] = (uint8_t)(position_counts >> 16U);
    payload[6] = (uint8_t)(position_counts >> 8U);
    payload[7] = (uint8_t)position_counts;

    status = stepper_enqueue_command(
        absolute ? STEPPER_TRANSACTION_ABSOLUTE_MOVE :
            STEPPER_TRANSACTION_RELATIVE_MOVE,
        absolute ? STEPPER_COMMAND_ABSOLUTE_MOVE :
            STEPPER_COMMAND_RELATIVE_MOVE,
        payload, sizeof(payload), STEPPER_MOVE_RESPONSE_SIZE,
        STEPPER_RESPONSE_TIMEOUT_MS);
    if (status == STEPPER_STATUS_OK) {
        g_stepper_last_degrees = degrees;
        g_stepper_last_position_counts = position_counts;
    }
    return status;
}

StepperStatus Stepper_MoveToAbsoluteDegreesWithProfile(
    float degrees, uint16_t speed_rpm, uint8_t acceleration)
{
    return stepper_enqueue_move(degrees, speed_rpm, acceleration, 1U);
}

StepperStatus Stepper_ReadRealtimePosition(void)
{
    return stepper_enqueue_command(STEPPER_TRANSACTION_READ_POSITION,
        STEPPER_COMMAND_READ_POSITION, NULL, 0U,
        STEPPER_POSITION_RESPONSE_SIZE, STEPPER_POSITION_TIMEOUT_MS);
}

StepperStatus Stepper_ReadAtTarget(void)
{
    return stepper_enqueue_command(STEPPER_TRANSACTION_READ_AT_TARGET,
        STEPPER_COMMAND_READ_AT_TARGET, NULL, 0U,
        STEPPER_ENABLE_RESPONSE_SIZE, STEPPER_POSITION_TIMEOUT_MS);
}

void Stepper_Process(void)
{
    uint32_t now = millis();

    if (g_stepper_transaction_active) {
        if (g_stepper_response_complete) {
            stepper_finish_active(STEPPER_STATUS_OK);
        } else if ((uint32_t)(now - g_stepper_transaction_start_ms) >=
            g_stepper_active_transaction.timeout_ms) {
            stepper_finish_active(STEPPER_STATUS_TIMEOUT);
        }
    }

    if (!g_stepper_transaction_active &&
        (g_stepper_queue_count == 0U) &&
        (!g_stepper_poll_started ||
         ((uint32_t)(now - g_stepper_last_poll_ms) >=
            STEPPER_POSITION_POLL_INTERVAL_MS))) {
        g_stepper_last_poll_ms = now;
        g_stepper_poll_started = 1U;
        stepper_queue_poll_commands();
    }

    stepper_start_next(now);
}

StepperStatus Stepper_RotateDegrees(float degrees)
{
    return Stepper_RotateDegreesWithProfile(degrees,
        STEPPER_DEFAULT_SPEED_RPM, STEPPER_DEFAULT_ACCELERATION);
}

StepperStatus Stepper_RotateDegreesWithProfile(
    float degrees, uint16_t speed_rpm, uint8_t acceleration)
{
    return stepper_enqueue_move(degrees, speed_rpm, acceleration, 0U);
}

static void stepper_receive_bytes(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_STEPPER_INST)) {
        uint32_t rx_data = UART_STEPPER_INST->RXDATA;
        uint8_t byte = (uint8_t)(rx_data & UART_RXDATA_DATA_MASK);

        if ((rx_data & (DL_UART_ERROR_OVERRUN | DL_UART_ERROR_BREAK |
             DL_UART_ERROR_PARITY | DL_UART_ERROR_FRAMING)) != 0U) {
            g_stepper_uart_error_count++;
        }
        if (!g_stepper_transaction_active ||
            g_stepper_response_complete) {
            continue;
        }
        if ((g_stepper_rx_index == 0U) &&
            (byte != STEPPER_FRAME_HEADER)) {
            continue;
        }
        if (g_stepper_rx_index < STEPPER_MAX_RESPONSE_SIZE) {
            g_stepper_response[g_stepper_rx_index++] = byte;
        }
        if (g_stepper_rx_index >=
            g_stepper_active_transaction.response_size) {
            g_stepper_response_complete = 1U;
        }
    }
}

void UART_STEPPER_INST_IRQHandler(void)
{
    while (1) {
        switch (DL_UART_Main_getPendingInterrupt(UART_STEPPER_INST)) {
        case DL_UART_MAIN_IIDX_TX:
            stepper_fill_tx_fifo();
            DL_UART_Main_clearInterruptStatus(UART_STEPPER_INST,
                DL_UART_MAIN_INTERRUPT_TX);
            break;

        case DL_UART_MAIN_IIDX_RX:
        case DL_UART_MAIN_IIDX_RX_TIMEOUT_ERROR:
            stepper_receive_bytes();
            DL_UART_Main_clearInterruptStatus(UART_STEPPER_INST,
                DL_UART_MAIN_INTERRUPT_RX |
                DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR);
            break;

        case DL_UART_MAIN_IIDX_OVERRUN_ERROR:
        case DL_UART_MAIN_IIDX_BREAK_ERROR:
        case DL_UART_MAIN_IIDX_PARITY_ERROR:
        case DL_UART_MAIN_IIDX_FRAMING_ERROR:
            g_stepper_uart_error_count++;
            stepper_receive_bytes();
            DL_UART_Main_clearInterruptStatus(UART_STEPPER_INST,
                DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |
                DL_UART_MAIN_INTERRUPT_BREAK_ERROR |
                DL_UART_MAIN_INTERRUPT_PARITY_ERROR |
                DL_UART_MAIN_INTERRUPT_FRAMING_ERROR);
            break;

        default:
            return;
        }
    }
}
