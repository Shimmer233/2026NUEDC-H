#ifndef STEPPPER_H
#define STEPPPER_H

#include <stdint.h>

#define STEPPER_DEVICE_ADDRESS             0x01U
#define STEPPER_COUNTS_PER_REVOLUTION      51200U
#define STEPPER_DEFAULT_SPEED_RPM          60U
#define STEPPER_DEFAULT_ACCELERATION       20U
#define STEPPER_RESPONSE_TIMEOUT_MS        100U
#define STEPPER_POSITION_POLL_INTERVAL_MS   20U
#define STEPPER_POSITION_TIMEOUT_MS         10U
#define STEPPER_TRANSACTION_QUEUE_SIZE        8U
#define STEPPER_BUTTON_STEP_DEGREES          0.1f
#define STEPPER_BUTTON_SPEED_RPM              5U
#define STEPPER_BUTTON_ACCELERATION           5U

typedef enum {
    STEPPER_STATUS_OK = 0,
    STEPPER_STATUS_INVALID_ARGUMENT,
    STEPPER_STATUS_TIMEOUT,
    STEPPER_STATUS_BAD_RESPONSE,
    STEPPER_STATUS_DEVICE_ERROR,
    STEPPER_STATUS_BUSY
} StepperStatus;

extern volatile StepperStatus g_stepper_last_status;
extern volatile uint8_t g_stepper_last_device_code;
extern volatile uint32_t g_stepper_command_count;
extern volatile uint32_t g_stepper_timeout_count;
extern volatile uint32_t g_stepper_last_position_counts;
extern volatile float g_stepper_last_degrees;
extern volatile int32_t g_stepper_realtime_position_counts;
extern volatile float g_stepper_realtime_angle_degrees;
extern volatile uint8_t g_stepper_realtime_position_valid;
extern volatile uint32_t g_stepper_position_update_count;
extern volatile uint32_t g_stepper_position_last_ms;
extern volatile uint8_t g_stepper_at_target;
extern volatile uint8_t g_stepper_at_target_valid;
extern volatile uint32_t g_stepper_at_target_update_count;
extern volatile uint8_t g_stepper_transaction_active;
extern volatile uint8_t g_stepper_queue_depth;
extern volatile uint32_t g_stepper_queue_overflow_count;
extern volatile uint32_t g_stepper_uart_error_count;
extern volatile uint8_t g_stepper_zero_success;
extern volatile uint32_t g_stepper_zero_update_count;

/* Enables the interrupt-driven UART3 transaction engine. */
void Stepper_Init(void);

/* Positive degrees rotate forward; negative degrees rotate in reverse. */
StepperStatus Stepper_RotateDegrees(float degrees);

/* Speed range: 1..6000 RPM. Acceleration range: 0..200. */
StepperStatus Stepper_RotateDegreesWithProfile(
    float degrees, uint16_t speed_rpm, uint8_t acceleration);

/* Redefine the driver's current position as zero degrees. */
StepperStatus Stepper_SetCurrentPositionZero(void);

/* Move to a signed absolute angle relative to the driver's zero position. */
StepperStatus Stepper_MoveToAbsoluteDegreesWithProfile(
    float degrees, uint16_t speed_rpm, uint8_t acceleration);

/* Read the signed cumulative position reported by the driver. */
StepperStatus Stepper_ReadRealtimePosition(void);

/* Read the driver's motion-complete flag. */
StepperStatus Stepper_ReadAtTarget(void);

/* Call repeatedly; this function never waits for a UART response. */
void Stepper_Process(void);

#endif
