#include "encoder.h"

#include <stddef.h>
#include <string.h>

#include "ti_msp_dl_config.h"

#define ENCODER_LINK_UART_INT_MASK                                      \
    (DL_UART_MAIN_INTERRUPT_RX |                                        \
        DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR |                       \
        DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |                          \
        DL_UART_MAIN_INTERRUPT_BREAK_ERROR |                            \
        DL_UART_MAIN_INTERRUPT_PARITY_ERROR |                           \
        DL_UART_MAIN_INTERRUPT_FRAMING_ERROR)

volatile int32_t g_encoder_left_total;
volatile int32_t g_encoder_right_total;
volatile int32_t g_encoder_left_delta;
volatile int32_t g_encoder_right_delta;
volatile float g_left_motor_speed;
volatile float g_right_motor_speed;
volatile EncoderLink_Data_t g_encoder_link_latest;
volatile uint32_t g_encoder_link_valid_count;
volatile uint32_t g_encoder_link_invalid_count;
volatile uint32_t g_encoder_link_uart_error_count;
volatile uint8_t g_encoder_link_pb22_high;

static volatile int32_t g_left_interval;
static volatile int32_t g_right_interval;
static uint8_t g_encoder_link_frame[ENCODER_LINK_FRAME_SIZE];
static uint8_t g_encoder_link_frame_index;
static uint8_t g_encoder_link_parser_state;

static uint16_t encoder_link_read_u16_le(const uint8_t *data)
{
    return (uint16_t)data[0] | ((uint16_t)data[1] << 8U);
}

static uint32_t encoder_link_read_u32_le(const uint8_t *data)
{
    return (uint32_t)data[0] |
        ((uint32_t)data[1] << 8U) |
        ((uint32_t)data[2] << 16U) |
        ((uint32_t)data[3] << 24U);
}

static bool encoder_link_frame_is_valid(const uint8_t *frame)
{
    uint8_t checksum = 0U;

    if ((frame[0] != 0xAAU) || (frame[1] != 0x55U) ||
        (frame[2] != ENCODER_LINK_PROTOCOL_VERSION) ||
        (frame[3] < 1U) || (frame[3] > 4U) ||
        (frame[19] != 0x5AU)) {
        return false;
    }

    for (uint8_t i = 2U; i <= 17U; i++) {
        checksum = (uint8_t)(checksum + frame[i]);
    }
    return checksum == frame[18];
}

static void encoder_link_publish_frame(const uint8_t *frame)
{
    EncoderLink_Data_t parsed;

    parsed.protocol_version = frame[2];
    parsed.task_id = frame[3];
    parsed.frame_sequence = encoder_link_read_u16_le(&frame[4]);
    parsed.left_count = encoder_link_read_u32_le(&frame[6]);
    parsed.right_count = encoder_link_read_u32_le(&frame[10]);
    parsed.average_count = encoder_link_read_u32_le(&frame[14]);

    g_encoder_link_latest = parsed;
    g_encoder_link_valid_count++;

    if (parsed.average_count < ENCODER_LINK_VERIFY_THRESHOLD) {
        DL_GPIO_setPins(
            GPIO_ENCODER_VERIFY_PORT, GPIO_ENCODER_VERIFY_PIN_PB22_PIN);
        g_encoder_link_pb22_high = 1U;
    } else {
        DL_GPIO_clearPins(
            GPIO_ENCODER_VERIFY_PORT, GPIO_ENCODER_VERIFY_PIN_PB22_PIN);
        g_encoder_link_pb22_high = 0U;
    }
}

static void encoder_link_feed_byte(uint8_t byte)
{
    switch (g_encoder_link_parser_state) {
    case 0U:
        if (byte == 0xAAU) {
            g_encoder_link_frame[0] = byte;
            g_encoder_link_parser_state = 1U;
        }
        break;

    case 1U:
        if (byte == 0x55U) {
            g_encoder_link_frame[1] = byte;
            g_encoder_link_frame_index = 2U;
            g_encoder_link_parser_state = 2U;
        } else if (byte != 0xAAU) {
            g_encoder_link_parser_state = 0U;
        }
        break;

    case 2U:
        g_encoder_link_frame[g_encoder_link_frame_index++] = byte;
        if (g_encoder_link_frame_index >= ENCODER_LINK_FRAME_SIZE) {
            g_encoder_link_parser_state = 0U;
            if (encoder_link_frame_is_valid(g_encoder_link_frame)) {
                encoder_link_publish_frame(g_encoder_link_frame);
            } else {
                g_encoder_link_invalid_count++;
                if (byte == 0xAAU) {
                    g_encoder_link_frame[0] = byte;
                    g_encoder_link_parser_state = 1U;
                }
            }
        }
        break;

    default:
        g_encoder_link_parser_state = 0U;
        break;
    }
}

void EncoderLink_UART_Init(void)
{
    g_encoder_link_frame_index = 0U;
    g_encoder_link_parser_state = 0U;
    g_encoder_link_valid_count = 0U;
    g_encoder_link_invalid_count = 0U;
    g_encoder_link_uart_error_count = 0U;
    g_encoder_link_pb22_high = 0U;
    memset((void *)&g_encoder_link_latest, 0, sizeof(g_encoder_link_latest));

    DL_UART_Main_disableInterrupt(
        UART_ENCODER_LINK_INST, ENCODER_LINK_UART_INT_MASK);
    NVIC_DisableIRQ(UART_ENCODER_LINK_INST_INT_IRQN);
    DL_UART_Main_setRXFIFOThreshold(
        UART_ENCODER_LINK_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setRXInterruptTimeout(UART_ENCODER_LINK_INST, 1U);
    DL_UART_Main_clearInterruptStatus(
        UART_ENCODER_LINK_INST, ENCODER_LINK_UART_INT_MASK);
    DL_UART_Main_enableInterrupt(
        UART_ENCODER_LINK_INST, ENCODER_LINK_UART_INT_MASK);
    NVIC_ClearPendingIRQ(UART_ENCODER_LINK_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_ENCODER_LINK_INST_INT_IRQN);
}

bool EncoderLink_GetLatest(EncoderLink_Data_t *data, uint32_t *frame_count)
{
    uint32_t primask = __get_PRIMASK();
    uint32_t count;

    __disable_irq();
    count = g_encoder_link_valid_count;
    if ((count > 0U) && (data != NULL)) {
        *data = g_encoder_link_latest;
    }
    if (primask == 0U) {
        __enable_irq();
    }

    if (frame_count != NULL) {
        *frame_count = count;
    }
    return count > 0U;
}

static void update_left_encoder(void)
{
    /* 左轮编码器 A 相：PA26；B 相 PA27 当前不参与速度大小计数。 */
    g_encoder_left_total++;
    g_left_interval++;
}

static void update_right_encoder(void)
{
    /* 右轮编码器 A 相：PB10；B 相 PB11 当前不参与速度大小计数。 */
    g_encoder_right_total++;
    g_right_interval++;
}

void Encoder_Init(void)
{
    g_encoder_left_total = 0;
    g_encoder_right_total = 0;
    g_encoder_left_delta = 0;
    g_encoder_right_delta = 0;
    g_left_motor_speed = 0.0f;
    g_right_motor_speed = 0.0f;
    g_left_interval = 0;
    g_right_interval = 0;

    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_LEFT_A_PORT,
        GPIO_ENCODER_LEFT_A_PIN);
    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_RIGHT_A_PORT,
        GPIO_ENCODER_RIGHT_A_PIN);
    NVIC_EnableIRQ(GPIO_ENCODER_GPIOA_INT_IRQN);
    NVIC_EnableIRQ(GPIO_ENCODER_GPIOB_INT_IRQN);
}

void Encoder_GetAndResetDeltas(int32_t *left, int32_t *right)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    int32_t left_snapshot = g_left_interval;
    int32_t right_snapshot = g_right_interval;
    g_left_interval = 0;
    g_right_interval = 0;

    if (primask == 0U) {
        __enable_irq();
    }

    g_encoder_left_delta = left_snapshot;
    g_encoder_right_delta = right_snapshot;
    if (left != NULL) {
        *left = left_snapshot;
    }
    if (right != NULL) {
        *right = right_snapshot;
    }
}

void Encoder_SampleSpeeds(uint32_t elapsed_ms,
    int32_t *left_delta, int32_t *right_delta)
{
    int32_t left;
    int32_t right;
    Encoder_GetAndResetDeltas(&left, &right);

    if (elapsed_ms > 0U) {
        g_left_motor_speed =
            (float)left * 20.0f / (float)elapsed_ms;
        g_right_motor_speed =
            (float)right * 20.0f / (float)elapsed_ms;
    } else {
        g_left_motor_speed = 0.0f;
        g_right_motor_speed = 0.0f;
    }

    if (left_delta != NULL) {
        *left_delta = left;
    }
    if (right_delta != NULL) {
        *right_delta = right;
    }
}

void Encoder_GetTotals(int32_t *left, int32_t *right)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    int32_t left_snapshot = g_encoder_left_total;
    int32_t right_snapshot = g_encoder_right_total;

    if (primask == 0U) {
        __enable_irq();
    }

    if (left != NULL) {
        *left = left_snapshot;
    }
    if (right != NULL) {
        *right = right_snapshot;
    }
}

void GROUP1_IRQHandler(void)
{
    uint32_t left_status = DL_GPIO_getEnabledInterruptStatus(
        GPIO_ENCODER_LEFT_A_PORT, GPIO_ENCODER_LEFT_A_PIN);
    if (left_status != 0U) {
        DL_GPIO_clearInterruptStatus(GPIO_ENCODER_LEFT_A_PORT, left_status);
        /* PA26 -> 左轮计数。 */
        update_left_encoder();
    }

    uint32_t right_status = DL_GPIO_getEnabledInterruptStatus(
        GPIO_ENCODER_RIGHT_A_PORT, GPIO_ENCODER_RIGHT_A_PIN);
    if (right_status != 0U) {
        DL_GPIO_clearInterruptStatus(GPIO_ENCODER_RIGHT_A_PORT, right_status);
        /* PB10 -> 右轮计数。 */
        update_right_encoder();
    }
}

void UART_ENCODER_LINK_INST_IRQHandler(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_ENCODER_LINK_INST)) {
        uint32_t rx_data = UART_ENCODER_LINK_INST->RXDATA;

        if ((rx_data & (DL_UART_ERROR_OVERRUN | DL_UART_ERROR_BREAK |
             DL_UART_ERROR_PARITY | DL_UART_ERROR_FRAMING)) != 0U) {
            g_encoder_link_uart_error_count++;
        }
        encoder_link_feed_byte(
            (uint8_t)(rx_data & UART_RXDATA_DATA_MASK));
    }

    DL_UART_Main_clearInterruptStatus(
        UART_ENCODER_LINK_INST, ENCODER_LINK_UART_INT_MASK);
}
