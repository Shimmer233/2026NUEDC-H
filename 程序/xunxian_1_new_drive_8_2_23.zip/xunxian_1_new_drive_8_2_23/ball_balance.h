#ifndef BALL_BALANCE_H
#define BALL_BALANCE_H

#include <stdint.h>

#include "steppper.h"

#define BALL_BALANCE_MAX_OFFSET_CM       10.45f
#define BALL_BALANCE_MAX_ANGLE_DEGREES   20.0f
#define BALL_BALANCE_POSITION_MAX_ANGLE_DEGREES 10.0f
#define BALL_BALANCE_ANGLE_PER_CM        \
    (BALL_BALANCE_POSITION_MAX_ANGLE_DEGREES / \
        BALL_BALANCE_MAX_OFFSET_CM)
#define BALL_BALANCE_CONTROL_SPEED_RPM           260U
#define BALL_BALANCE_CONTROL_ACCELERATION        10U
#define BALL_BALANCE_COMMAND_DEADBAND_DEGREES     0.1f
#define BALL_BALANCE_VISION_TIMEOUT_MS           250U
#define BALL_BALANCE_CALIBRATION_ROTATION_DEGREES (-53.0f)
#define BALL_BALANCE_VISION_CONTROL_ENABLED          1U
#define BALL_BALANCE_CALIBRATION_TIMEOUT_MS     10000U
#define BALL_BALANCE_ZERO_RETRY_MS                500U

#define BALL_BALANCE_TASK_ONE                       1U
#define BALL_BALANCE_TASK_TWO                       2U
#define BALL_BALANCE_TASK_THREE                     3U
#define BALL_BALANCE_ACTIVE_TASK      BALL_BALANCE_TASK_THREE
#define BALL_BALANCE_TASK1_SPEED_RPM                400U
#define BALL_BALANCE_TASK1_KD_DEG_S_PER_CM            0.8f

/* Task three: filtered PID plus vehicle-acceleration feedforward. */
#define BALL_BALANCE_TASK3_SPEED_RPM               1000U
#define BALL_BALANCE_TASK3_CONTROL_PERIOD_MS          20U
#define BALL_BALANCE_TASK3_DEFAULT_SETPOINT_CM          0.1f
#define BALL_BALANCE_TASK3_MAX_OFFSET_CM             13.0f
#define BALL_BALANCE_TASK3_KP_DEG_PER_CM              2.25f
#define BALL_BALANCE_TASK3_KI_DEG_PER_CM_S            0.0095f
#define BALL_BALANCE_TASK3_KD_DEG_S_PER_CM            31.5f
#define BALL_BALANCE_TASK3_I_LIMIT_DEG                  8.0f
#define BALL_BALANCE_TASK3_POSITION_FILTER_ALPHA       0.45f
#define BALL_BALANCE_TASK3_VELOCITY_FILTER_ALPHA       0.30f
#define BALL_BALANCE_TASK3_VISION_VELOCITY_WEIGHT      0.70f
#define BALL_BALANCE_TASK3_MAX_VELOCITY_CM_S          80.0f
#define BALL_BALANCE_TASK3_ACCEL_AXIS_Y                   1U
/* Change to -1.0f if forward vehicle acceleration moves the ball worse. */
#define BALL_BALANCE_TASK3_ACCEL_AXIS_SIGN              1.0f
#define BALL_BALANCE_TASK3_ACCEL_BIAS_SAMPLES            30U
#define BALL_BALANCE_TASK3_ACCEL_DEADBAND_G              0.02f
#define BALL_BALANCE_TASK3_ACCEL_GAIN_DEFAULT             0.8f
#define BALL_BALANCE_TASK3_ACCEL_GAIN_BELOW_THRESHOLD      3.9f
#define BALL_BALANCE_TASK3_ACCEL_GAIN_MIDDLE_RANGE         2.6f
#define BALL_BALANCE_TASK3_ACCEL_GAIN_HIGH_RANGE           2.8f
#define BALL_BALANCE_TASK3_ENCODER_COUNT_THRESHOLD       2000U
#define BALL_BALANCE_TASK3_ENCODER_MIDDLE_RANGE_MIN       6000U
#define BALL_BALANCE_TASK3_ENCODER_MIDDLE_RANGE_MAX      13500U
#define BALL_BALANCE_TASK3_ENCODER_HIGH_RANGE_MIN        15500U
#define BALL_BALANCE_TASK3_ENCODER_HIGH_RANGE_MAX        16300U
#define BALL_BALANCE_TASK3_IMU_TIMEOUT_MS               120U
#define BALL_BALANCE_TASK3_MAX_COMMAND_RATE_DEG_S      90.0f
#define BALL_BALANCE_TASK3_TRACKING_WINDOW_DEG           3.0f
#define BALL_BALANCE_TASK3_POSITION_FEEDBACK_FRESH_MS   120U
#define BALL_BALANCE_TASK3_MAX_ANGLE_DEG                10.0f

/* Task four: drive +8/-6 cm, switching at +5/-4.8 cm, then hold -5 cm. */
#define BALL_BALANCE_TASK4_KP_DEG_PER_CM              2.27f
#define BALL_BALANCE_TASK4_KI_DEG_PER_CM_S            0.0095f
#define BALL_BALANCE_TASK4_KD_DEG_S_PER_CM            35.3f
#define BALL_BALANCE_TASK4_ZERO_OFFSET_DEG            (-3.0f)
#define BALL_BALANCE_TASK4_POSITIVE_SETPOINT_CM          8.0f
#define BALL_BALANCE_TASK4_POSITIVE_DETECTION_CM         5.0f
#define BALL_BALANCE_TASK4_RETURN_SETPOINT_CM           (-6.0f)
#define BALL_BALANCE_TASK4_NEGATIVE_DETECTION_CM        (-4.8f)
#define BALL_BALANCE_TASK4_FINAL_SETPOINT_CM            (-5.0f)
#define BALL_BALANCE_TASK4_REACHED_TOLERANCE_CM          0.5f
#define BALL_BALANCE_TASK4_POSITIVE_STABLE_SAMPLES         5U
#define BALL_BALANCE_TASK4_NEGATIVE_STABLE_SAMPLES         1U
#define BALL_BALANCE_TASK4_KEY_DEBOUNCE_MS                20U

/* Task two: 20 ms PID using the newest unfiltered vision frame. */
#define BALL_BALANCE_TASK2_CONTROL_PERIOD_MS          20U
#define BALL_BALANCE_TASK2_OUTPUT_GAIN_MIN             1.0f
#define BALL_BALANCE_TASK2_OUTPUT_GAIN_MAX             5.0f
#define BALL_BALANCE_TASK2_OUTPUT_GAIN_RANGE_CM        12.0f
#define BALL_BALANCE_TASK2_SPEED_LEVEL1_CM             2.0f
#define BALL_BALANCE_TASK2_SPEED_LEVEL2_CM             4.0f
#define BALL_BALANCE_TASK2_SPEED_LEVEL3_CM             6.0f
#define BALL_BALANCE_TASK2_SPEED_LEVEL4_CM             8.0f
#define BALL_BALANCE_TASK2_SPEED_LEVEL1_RPM           400U
#define BALL_BALANCE_TASK2_SPEED_LEVEL2_RPM           370U
#define BALL_BALANCE_TASK2_SPEED_LEVEL3_RPM           340U
#define BALL_BALANCE_TASK2_SPEED_LEVEL4_RPM           300U
#define BALL_BALANCE_TASK2_SPEED_FAR_RPM              260U
#define BALL_BALANCE_TASK2_POSITION_DEADBAND_CM      0.10f
#define BALL_BALANCE_TASK2_KP_DEG_PER_CM             0.40f
#define BALL_BALANCE_TASK2_KI_DEG_PER_CM_S           0.00f
#define BALL_BALANCE_TASK2_KD_DEG_S_PER_CM           0.00f
#define BALL_BALANCE_TASK2_P_LIMIT_DEG               20.0f
#define BALL_BALANCE_TASK2_D_LIMIT_DEG                4.0f
#define BALL_BALANCE_TASK2_OVERRANGE_THRESHOLD_CM     8.0f
#define BALL_BALANCE_TASK2_OVERRANGE_GAIN_DEG_S_CM    2.0f
#define BALL_BALANCE_TASK2_OVERRANGE_MAX_DEG_S        8.0f
#define BALL_BALANCE_TASK2_MAX_ANGLE_DEG             20.0f
#define BALL_BALANCE_TASK2_INTEGRAL_LIMIT_CM_S       20.0f
#define BALL_BALANCE_TASK2_INTEGRAL_ERROR_CM          3.0f
#define BALL_BALANCE_TASK2_INTEGRAL_VELOCITY_CM_S     5.0f

typedef enum {
    BALL_BALANCE_CALIBRATION_WAIT_VISION = 0,
    BALL_BALANCE_CALIBRATION_WAIT_ROTATION,
    BALL_BALANCE_CALIBRATION_ROTATION_COMPLETE,
    BALL_BALANCE_CALIBRATION_SET_ZERO,
    BALL_BALANCE_CALIBRATION_READY,
    BALL_BALANCE_CALIBRATION_FAULT
} BallBalanceCalibrationState;

typedef enum {
    BALL_BALANCE_TASK4_INACTIVE = 0,
    BALL_BALANCE_TASK4_MOVE_TO_POSITIVE,
    BALL_BALANCE_TASK4_MOVE_TO_NEGATIVE,
    BALL_BALANCE_TASK4_HOLD_NEGATIVE
} BallBalanceTaskFourPhase;

extern volatile float g_ball_balance_offset_cm;
extern volatile float g_ball_balance_desired_angle_degrees;
extern volatile float g_ball_balance_slewed_angle_degrees;
extern volatile float g_ball_balance_target_angle_degrees;
extern volatile uint8_t g_ball_balance_center_valid;
extern volatile StepperStatus g_ball_balance_last_status;
extern volatile uint32_t g_ball_balance_command_count;
extern volatile uint32_t g_ball_balance_error_count;
extern volatile BallBalanceCalibrationState g_ball_balance_calibration_state;
extern volatile uint8_t g_ball_balance_active_task;
extern volatile float g_t3_kp;
extern volatile float g_t3_ki;
extern volatile float g_t3_kd;
extern volatile float g_t3_e;
extern volatile float g_t3_p;
extern volatile float g_t3_i;
extern volatile float g_t3_d;
extern volatile float g_t3_pid;
extern volatile float g_t3_out;
extern volatile float g_ball_balance_task1_velocity_cm_s;
extern volatile float g_ball_balance_task1_position_angle_degrees;
extern volatile float g_ball_balance_task1_speed_compensation_degrees;

extern volatile float g_ball_balance_task3_velocity_cm_s;
extern volatile float g_ball_balance_task3_position_angle_degrees;
extern volatile float g_ball_balance_task3_speed_compensation_degrees;
extern volatile float g_ball_balance_task3_filtered_position_cm;
extern volatile float g_ball_balance_task3_filtered_velocity_cm_s;
extern volatile float g_ball_balance_task3_error_delta_cm;
extern volatile float g_ball_balance_task3_accel_bias_g;
extern volatile float g_ball_balance_task3_filtered_accel_g;
extern volatile float g_ball_balance_task3_accel_compensation_degrees;
extern volatile float g_ball_balance_task3_accel_feedforward_gain;
extern volatile float g_ball_balance_task3_angle_tracking_error_degrees;
extern volatile uint8_t g_ball_balance_task3_accel_calibrated;
extern volatile uint8_t g_ball_balance_task4_active;
extern volatile BallBalanceTaskFourPhase g_ball_balance_task4_phase;
extern volatile float g_ball_balance_task4_setpoint_cm;
extern volatile uint8_t g_ball_balance_task4_stable_samples;
extern volatile uint8_t g_ball_balance_task4_key_gpio_level;
extern volatile uint32_t g_ball_balance_task4_start_count;
extern volatile float g_t4_kp;
extern volatile float g_t4_ki;
extern volatile float g_t4_kd;

extern volatile float g_ball_balance_task2_average_position_cm;
extern volatile float g_ball_balance_task2_filtered_position_cm;
extern volatile float g_ball_balance_task2_estimated_velocity_cm_s;
extern volatile float g_ball_balance_task2_filtered_velocity_cm_s;
extern volatile float g_ball_balance_task2_error_cm;
extern volatile float g_ball_balance_task2_p_degrees;
extern volatile float g_ball_balance_task2_i_degrees;
extern volatile float g_ball_balance_task2_d_degrees;
extern volatile float g_ball_balance_task2_overrange_compensation_deg_s;
extern volatile float g_ball_balance_task2_integral_cm_s;
extern volatile float g_ball_balance_task2_output_degrees;
extern volatile float g_ball_balance_task2_adjustment_rate_deg_s;
extern volatile float g_ball_balance_task2_increment_degrees;
extern volatile float g_ball_balance_task2_accumulated_target_degrees;
extern volatile float g_ball_balance_task2_output_gain;
extern volatile uint16_t g_ball_balance_task2_command_speed_rpm;

/* Maps -10.45..+10.45 cm to +10..-10 degrees before velocity compensation. */
float BallBalance_OffsetToAngle(float offset_cm);

/* Queues a request to define the current position as the 0-degree point. */
StepperStatus BallBalance_SetCurrentPositionAsCenter(void);

/* Commands the absolute angle associated with offset_cm. */
StepperStatus BallBalance_MoveToOffset(float offset_cm,
    uint16_t speed_rpm, uint8_t acceleration);

/* Immediately start the one-time -55-degree rotation sequence. */
void BallBalance_Init(uint32_t now_ms);

/* Consume new signed vision offsets and command an absolute angle. */
void BallBalance_Process(uint32_t now_ms);

#endif
