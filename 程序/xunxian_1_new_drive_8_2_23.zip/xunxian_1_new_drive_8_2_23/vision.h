#ifndef VISION_H
#define VISION_H

#include <stdint.h>

#define VISION_SEND_PERIOD_MS    50U
#define VISION_ACCEL_FRAME_SIZE  18U
#define VISION_RX_LINE_SIZE      96U

/* Debug-watch variables updated after a valid PV line is received. */
extern volatile float g_vision_ball_position_cm;
extern volatile float g_vision_ball_velocity_cm_s;
extern volatile uint8_t g_vision_pv_valid;
extern volatile uint32_t g_vision_pv_update_count;
extern volatile uint32_t g_vision_pv_last_ms;

/* Legacy position aliases retained for the ball-balance controller. */
extern volatile float g_vision_ball_distance_cm;
extern volatile uint8_t g_vision_ball_distance_valid;
extern volatile uint32_t g_vision_ball_distance_update_count;
extern volatile uint32_t g_vision_ball_distance_last_ms;

/* Raw receive diagnostics for checking the visual module's actual format. */
extern volatile uint8_t g_vision_rx_last_byte;
extern volatile uint32_t g_vision_rx_byte_count;
extern volatile uint32_t g_vision_rx_overflow_count;
extern volatile uint32_t g_vision_uart_error_count;
extern volatile char g_vision_rx_last_line[VISION_RX_LINE_SIZE];

/*
 * Acceleration frame, 115200 baud, 8N1:
 * AA 56 01 0C Ax(float LE) Ay(float LE) Az(float LE) SUM 5A
 * Ax/Ay/Az are in g. SUM is the low byte of the sum over bytes 2..15.
 *
 * Preferred receive format is one ASCII PV frame per line:
 * PV,<position cm>,<velocity cm/s>\n, for example PV,-1.632,-0.293\n.
 * The original demo:<position>,<velocity>,... line is also accepted.
 */
void VISION_Init(void);
void VISION_Process(uint32_t now_ms);

#endif
