#include "headerfile.h"
#include "ball_balance.h"
#include "encoder.h"
#include "g356.h"
#include "motor_speed.h"
#include "oled.h"
#include "pid.h"
#include "steppper.h"
#include "vision.h"

volatile uint32_t completed_lap_count = 0U;
volatile uint8_t g_parking_line_detected = 0U;
volatile uint8_t g_lap_finish_armed = 0U;
volatile float g_task_one_speed_scale = 1.0f;
volatile float g_task_two_speed_scale = 1.0f;
volatile float g_task_one_left_smoothed_target = 0.0f;
volatile float g_task_one_right_smoothed_target = 0.0f;
volatile uint8_t g_task_one_stability_active = 0U;
volatile float g_task_four_line_position = 0.0f;
volatile float g_task_four_speed_command = 0.0f;
volatile float g_task_four_adjust_command = 0.0f;
volatile float g_task_four_left_target = 0.0f;
volatile float g_task_four_right_target = 0.0f;
volatile uint8_t g_task_four_phase = 0U;
volatile uint8_t g_task_four_fault = 0U;

typedef struct {
    uint8_t clear_count;
    uint8_t confirm_count;
    uint8_t decel_started;
    uint32_t decel_start_ms;
} LapFinishState;

typedef enum {
    DRIVE_TRACK = 0U,
    DRIVE_FINISHED
} DrivePhase;

typedef enum {
    TASK_ONE_LAP = 1U,
    TASK_TWO_TIMED = 2U,
    TASK_THREE_BASIC = 3U,
    TASK_FOUR_SMOOTH_LAP = 4U
} TaskMode;

typedef struct {
    float line_position;
    float speed;
    float adjust;
    float left_target;
    float right_target;
    float stop_start_speed;
    uint32_t stop_start_ms;
    uint32_t line_lost_elapsed_ms;
    uint8_t line_position_valid;
    uint8_t stopped_stable_samples;
    uint8_t stop_requested;
    uint8_t fault;
} TaskFourController;

static void stop_motors(void)
{
    left_speed = 0;
    right_speed = 0;
    set_Lspeed(0);
    set_Rspeed(0);
}

static void brake_motors(void)
{
    left_speed = 0;
    right_speed = 0;
    motor_active_brake();
}

static int32_t speed_pid_command(PID_Controller *pid, float target,
    float measured, int32_t base_pwm, float base_target,
    float dt_seconds)
{
    if (target == 0) {
        PID_Reset(pid);
        return 0;
    }

    int32_t direction = (target > 0) ? 1 : -1;
    float target_magnitude = (target > 0.0f) ? target : -target;
    float measured_magnitude = (measured >= 0.0f) ? measured : -measured;
    float adjustment = PID_Update(pid, target_magnitude,
        measured_magnitude, dt_seconds);
    float feedforward = (float)base_pwm * target_magnitude / base_target;
    float command = feedforward + adjustment;

    if (command < 0.0f) {
        command = 0.0f;
    } else if (command > (float)MOTOR_PWM_MAX) {
        command = (float)MOTOR_PWM_MAX;
    }

    return direction * (int32_t)(command + 0.5f);
}

static int32_t task_two_soft_start_limit(int32_t command,
    uint32_t elapsed_ms)
{
    if (elapsed_ms >= TASK_TWO_SOFT_START_DURATION_MS) {
        return command;
    }

    int32_t limit = (int32_t)(
        ((uint32_t)TASK_TWO_SOFT_START_MAX_PWM * elapsed_ms) /
        TASK_TWO_SOFT_START_DURATION_MS);
    if (command > limit) {
        return limit;
    }
    if (command < -limit) {
        return -limit;
    }
    return command;
}

static int16_t scale_speed_target(int16_t target, float scale,
    int16_t minimum_speed)
{
    float scaled = (float)target * scale;
    int16_t result = (scaled >= 0.0f) ?
        (int16_t)(scaled + 0.5f) : (int16_t)(scaled - 0.5f);

    if ((target > 0) && (result < minimum_speed)) {
        result = minimum_speed;
    } else if ((target < 0) && (result > -minimum_speed)) {
        result = -minimum_speed;
    }
    return result;
}

static float task_one_soft_start_scale(uint32_t elapsed_ms)
{
    if (elapsed_ms >= TASK_ONE_SOFT_START_DURATION_MS) {
        return 1.0f;
    }

    float progress = (float)elapsed_ms /
        (float)TASK_ONE_SOFT_START_DURATION_MS;
    return progress;
}

static float task_one_smooth_target(float current, float requested,
    float dt_seconds)
{
    float rate;
    if (g_task_one_stability_active) {
        rate = TASK_ONE_STABLE_TARGET_RATE;
    } else {
        rate = (requested > current) ?
            TASK_ONE_TARGET_ACCEL_RATE : TASK_ONE_TARGET_DECEL_RATE;
    }
    float maximum_step = rate * dt_seconds;

    if (requested > (current + maximum_step)) {
        return current + maximum_step;
    }
    if (requested < (current - maximum_step)) {
        return current - maximum_step;
    }
    return requested;
}

static void task_one_reduce_differential(int16_t *left_target,
    int16_t *right_target)
{
    float average = ((float)*left_target + (float)*right_target) * 0.5f;
    float steering_scale = g_task_one_stability_active ?
        TASK_ONE_STABLE_STEERING_SCALE : TASK_ONE_STEERING_SCALE;
    float half_difference =
        ((float)*left_target - (float)*right_target) * 0.5f *
        steering_scale;
    float left = average + half_difference;
    float right = average - half_difference;

    *left_target = (left >= 0.0f) ?
        (int16_t)(left + 0.5f) : (int16_t)(left - 0.5f);
    *right_target = (right >= 0.0f) ?
        (int16_t)(right + 0.5f) : (int16_t)(right - 0.5f);
}

static uint8_t apply_task_one_slowdown(LapFinishState *state,
    int16_t *left_target, int16_t *right_target, uint32_t elapsed_ms)
{
    if (!state->decel_started) {
        g_task_one_speed_scale = 1.0f;
        return 0U;
    }

    uint32_t decel_elapsed_ms = elapsed_ms - state->decel_start_ms;
    float progress = (float)decel_elapsed_ms /
        (float)TASK_ONE_DECEL_DURATION_MS;
    if (progress > 1.0f) {
        progress = 1.0f;
    }

    float scale = 1.0f - progress;
    g_task_one_speed_scale = scale;

    /* Ramp down forward speed while retaining live line-follow correction. */
    float average = ((float)*left_target + (float)*right_target) * 0.5f;
    float half_difference =
        ((float)*left_target - (float)*right_target) * 0.5f;
    float decel_average = average * scale;
    float maximum_half_difference =
        ((decel_average >= 0.0f) ? decel_average : -decel_average) *
        TASK_ONE_DECEL_STEERING_FRACTION;

    if (half_difference > maximum_half_difference) {
        half_difference = maximum_half_difference;
    } else if (half_difference < -maximum_half_difference) {
        half_difference = -maximum_half_difference;
    }

    float left = decel_average + half_difference;
    float right = decel_average - half_difference;
    *left_target = (left >= 0.0f) ?
        (int16_t)(left + 0.5f) : (int16_t)(left - 0.5f);
    *right_target = (right >= 0.0f) ?
        (int16_t)(right + 0.5f) : (int16_t)(right - 0.5f);
    left_speed = *left_target;
    right_speed = *right_target;
    return (progress >= 1.0f) ? 1U : 0U;
}

static void apply_task_two_slowdown(int16_t *left_target,
    int16_t *right_target, uint32_t elapsed_ms)
{
    float scale = 1.0f;
    uint32_t decel_start_ms =
        TASK_TWO_DURATION_MS - TASK_TWO_DECEL_DURATION_MS;

    if (elapsed_ms > decel_start_ms) {
        float progress = (float)(elapsed_ms - decel_start_ms) /
            (float)TASK_TWO_DECEL_DURATION_MS;
        float minimum_scale = TASK_TWO_CRAWL_SPEED /
            (float)TRACK_BASE_SPEED;

        if (progress > 1.0f) {
            progress = 1.0f;
        }
        scale = 1.0f - progress * (1.0f - minimum_scale);
    }

    g_task_two_speed_scale = scale;
    *left_target = scale_speed_target(*left_target, scale, 0);
    *right_target = scale_speed_target(*right_target, scale, 0);
    left_speed = *left_target;
    right_speed = *right_target;
}

static float task_four_abs(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float task_four_step_towards(float current, float target,
    float maximum_step)
{
    if (target > current + maximum_step) {
        return current + maximum_step;
    }
    if (target < current - maximum_step) {
        return current - maximum_step;
    }
    return target;
}

static uint8_t task_four_read_line(float *position)
{
    const uint8_t detected[6] = {
        sensor_d2 == SENSOR_LINE_LEVEL,
        sensor_d3 == SENSOR_LINE_LEVEL,
        sensor_d4 == SENSOR_LINE_LEVEL,
        sensor_d5 == SENSOR_LINE_LEVEL,
        sensor_d6 == SENSOR_LINE_LEVEL,
        sensor_d7 == SENSOR_LINE_LEVEL
    };
    const float weights[6] = {
        -2.5f, -1.5f, -0.5f, 0.5f, 1.5f, 2.5f
    };
    float weighted_sum = 0.0f;
    uint8_t active_count = 0U;

    for (uint8_t i = 0U; i < 6U; i++) {
        if (detected[i]) {
            weighted_sum += weights[i];
            active_count++;
        }
    }
    if (active_count > 0U) {
        *position = weighted_sum / (float)active_count;
    }
    return active_count;
}

static void task_four_init(TaskFourController *controller)
{
    *controller = (TaskFourController){0};
    g_task_four_line_position = 0.0f;
    g_task_four_speed_command = 0.0f;
    g_task_four_adjust_command = 0.0f;
    g_task_four_left_target = 0.0f;
    g_task_four_right_target = 0.0f;
    g_task_four_phase = 1U;
    g_task_four_fault = 0U;
}

static uint8_t task_four_update(TaskFourController *controller,
    uint32_t elapsed_ms, uint32_t task_elapsed_ms,
    uint8_t finish_detected, float measured_left, float measured_right,
    int16_t *target_left, int16_t *target_right)
{
    float detected_position = 0.0f;
    uint8_t active_count = task_four_read_line(&detected_position);

    if (active_count > 0U) {
        controller->line_position = detected_position;
        controller->line_position_valid = 1U;
        controller->line_lost_elapsed_ms = 0U;
    } else if (controller->line_lost_elapsed_ms < UINT32_MAX - elapsed_ms) {
        controller->line_lost_elapsed_ms += elapsed_ms;
    }

    if (!controller->stop_requested) {
        controller->speed = TASK_FOUR_CRUISE_SPEED *
            task_one_soft_start_scale(task_elapsed_ms);
    }

    if (!controller->stop_requested) {
        if (finish_detected) {
            controller->stop_requested = 1U;
        } else if (controller->line_lost_elapsed_ms >=
            TASK_FOUR_LINE_LOST_GRACE_MS) {
            controller->stop_requested = 1U;
            controller->fault = 1U;
        }

        if (controller->stop_requested) {
            controller->stop_start_speed = controller->speed;
            controller->stop_start_ms = task_elapsed_ms;
            g_task_four_phase = 3U;
            g_task_four_fault = controller->fault;
        }
    }

    if (controller->stop_requested) {
        uint32_t stop_elapsed_ms = task_elapsed_ms -
            controller->stop_start_ms;
        float stop_progress = (float)stop_elapsed_ms /
            (float)TASK_FOUR_STOP_DECEL_DURATION_MS;
        if (stop_progress > 1.0f) {
            stop_progress = 1.0f;
        }
        controller->speed = controller->stop_start_speed *
            (1.0f - stop_progress);
    }

    float raw_adjust = 0.0f;
    if (controller->line_position_valid) {
        float magnitude = task_four_abs(controller->line_position);
        if (magnitude > 2.5f) {
            magnitude = 2.5f;
        }
        float scheduled_kp = TASK_FOUR_CENTER_KP +
            (TASK_FOUR_EDGE_KP - TASK_FOUR_CENTER_KP) *
            magnitude / 2.5f;
        raw_adjust = scheduled_kp * controller->line_position;
        if (raw_adjust > TASK_FOUR_MAX_ADJUST) {
            raw_adjust = TASK_FOUR_MAX_ADJUST;
        } else if (raw_adjust < -TASK_FOUR_MAX_ADJUST) {
            raw_adjust = -TASK_FOUR_MAX_ADJUST;
        }
    }

    float elapsed_seconds = (float)elapsed_ms / 1000.0f;
    controller->adjust = task_four_step_towards(controller->adjust,
        raw_adjust, TASK_FOUR_ADJUST_SLEW_PER_SECOND * elapsed_seconds);

    float speed_limited_adjust = 0.65f * controller->speed;
    if (controller->adjust > speed_limited_adjust) {
        controller->adjust = speed_limited_adjust;
    } else if (controller->adjust < -speed_limited_adjust) {
        controller->adjust = -speed_limited_adjust;
    }

    float desired_left = controller->speed + controller->adjust;
    float desired_right = controller->speed - controller->adjust;
    float maximum_wheel_step = TASK_FOUR_WHEEL_SLEW_PER_SECOND *
        elapsed_seconds;
    controller->left_target = task_four_step_towards(
        controller->left_target, desired_left, maximum_wheel_step);
    controller->right_target = task_four_step_towards(
        controller->right_target, desired_right, maximum_wheel_step);

    *target_left = (int16_t)(controller->left_target + 0.5f);
    *target_right = (int16_t)(controller->right_target + 0.5f);
    left_speed = *target_left;
    right_speed = *target_right;

    g_task_four_line_position = controller->line_position;
    g_task_four_speed_command = controller->speed;
    g_task_four_adjust_command = controller->adjust;
    g_task_four_left_target = controller->left_target;
    g_task_four_right_target = controller->right_target;

    if (controller->stop_requested &&
        (controller->speed < 0.1f) &&
        (task_four_abs(controller->adjust) < 0.1f) &&
        (task_four_abs(controller->left_target) < 0.5f) &&
        (task_four_abs(controller->right_target) < 0.5f) &&
        (task_four_abs(measured_left) <= TASK_FOUR_STOPPED_SPEED) &&
        (task_four_abs(measured_right) <= TASK_FOUR_STOPPED_SPEED)) {
        if (controller->stopped_stable_samples <
            TASK_FOUR_STOPPED_STABLE_SAMPLES) {
            controller->stopped_stable_samples++;
        }
    } else {
        controller->stopped_stable_samples = 0U;
    }

    if (controller->stopped_stable_samples >=
        TASK_FOUR_STOPPED_STABLE_SAMPLES) {
        g_task_four_phase = 4U;
        return 1U;
    }
    return 0U;
}

static TaskMode wait_for_task_start(void)
{
    uint8_t start_requested = 0U;
    uint8_t task_four_requested = 0U;

    while (1) {
        update_sensors();
        if (task_four_key_scan()) {
            task_four_requested = 1U;
        }
        float unused_position;
        if (task_four_requested && (g_g356_valid_count > 0U) &&
            (task_four_read_line(&unused_position) > 0U)) {
            return TASK_FOUR_SMOOTH_LAP;
        }
        if (task_four_requested) {
            MotorSpeed_Process();
            VISION_Process(millis());
            BallBalance_Process(millis());
            Stepper_Process();
            OLED_Process();
            delay_ms(5U);
            continue;
        }
        if (task_three_key_scan()) {
            return TASK_THREE_BASIC;
        }
        if (lap_select_key_scan()) {
            return TASK_TWO_TIMED;
        }
        if (start_key_scan()) {
            start_requested = 1U;
        }
        if (start_requested) {
            return TASK_ONE_LAP;
        }

        MotorSpeed_Process();
        VISION_Process(millis());
        BallBalance_Process(millis());
        Stepper_Process();
        OLED_Process();
        delay_ms(5U);
    }
}

static void lap_finish_reset(LapFinishState *state)
{
    state->clear_count = 0U;
    state->confirm_count = 0U;
    state->decel_started = 0U;
    state->decel_start_ms = 0U;
    completed_lap_count = 0U;
    g_parking_line_detected = 0U;
    g_lap_finish_armed = 0U;
    g_task_one_speed_scale = 1.0f;
    g_task_two_speed_scale = 1.0f;
    g_task_one_left_smoothed_target = 0.0f;
    g_task_one_right_smoothed_target = 0.0f;
    g_task_one_stability_active = 0U;
}

static uint8_t lap_finish_detected(LapFinishState *state)
{
    g_parking_line_detected = check_parking_line();

    if (!g_lap_finish_armed) {
        if (g_parking_line_detected) {
            state->clear_count = 0U;
        } else if (state->clear_count < PARKING_LINE_CLEAR_CYCLES) {
            state->clear_count++;
        }

        if (state->clear_count >= PARKING_LINE_CLEAR_CYCLES) {
            g_lap_finish_armed = 1U;
        }
        return 0U;
    }

    if (!g_parking_line_detected) {
        state->confirm_count = 0U;
        return 0U;
    }

    if (state->confirm_count < PARKING_LINE_CONFIRM_CYCLES) {
        state->confirm_count++;
    }
    return state->confirm_count >= PARKING_LINE_CONFIRM_CYCLES;
}

int main(void)
{
    SYSCFG_DL_init();

    SysTick->LOAD = (CPUCLK_FREQ / 1000U) - 1U;
    SysTick->VAL = 0U;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk |
                    SysTick_CTRL_ENABLE_Msk;

    /* G356 RX: PA1. VISION: PB6/PB7. Encoder link RX: PA24. */
    G356_UART_Init();
    VISION_Init();
    EncoderLink_UART_Init();
    Stepper_Init();
    (void)OLED_Init();
    Encoder_Init();
    MotorSpeed_Init();

    DL_TimerA_startCounter(PWM_MOTOR_INST);
    stop_motors();

    /* Start the selected balance task automatically. */
    BallBalance_Init(millis());
    Stepper_Process();

    TaskMode task_mode = wait_for_task_start();

    MotorSpeed_Reset();
    G356_Yaw_StartRecording();
    OLED_ResetElapsedClock();
    track_reset();

    LapFinishState lap_finish;
    lap_finish_reset(&lap_finish);
    TaskFourController task_four = {0};
    if (task_mode == TASK_FOUR_SMOOTH_LAP) {
        task_four_init(&task_four);
    } else {
        g_task_four_phase = 0U;
    }

    PID_Controller left_pid;
    PID_Init(&left_pid, LEFT_PID_KP, LEFT_PID_KI, LEFT_PID_KD,
        -(float)MOTOR_SPEED_TEST_PWM_L,
        (float)(MOTOR_PWM_MAX - MOTOR_SPEED_TEST_PWM_L),
        PID_INTEGRAL_ERROR_LIMIT);

    PID_Controller right_pid;
    PID_Init(&right_pid, RIGHT_PID_KP, RIGHT_PID_KI, RIGHT_PID_KD,
        -(float)MOTOR_SPEED_TEST_PWM_R,
        (float)(MOTOR_PWM_MAX - MOTOR_SPEED_TEST_PWM_R),
        PID_INTEGRAL_ERROR_LIMIT);

    int32_t left_pwm = 0;
    int32_t right_pwm = 0;
    uint32_t last_pid_ms = millis();
    uint32_t task_start_ms = millis();
    uint8_t task_four_finish_detected = 0U;
    DrivePhase phase = DRIVE_TRACK;
    int16_t target_left = TRACK_BASE_SPEED;
    int16_t target_right = TRACK_BASE_SPEED;

    stop_motors();

    while (1) {
        update_sensors();
        uint32_t task_elapsed_ms = millis() - task_start_ms;
        float task_one_start_scale = 1.0f;

        if ((task_mode == TASK_TWO_TIMED) &&
            (phase != DRIVE_FINISHED) &&
            (task_elapsed_ms >= TASK_TWO_DURATION_MS)) {
            phase = DRIVE_FINISHED;
            brake_motors();
            OLED_FreezeElapsedClock();
        }

        if ((task_mode == TASK_TWO_TIMED) &&
            (phase != DRIVE_FINISHED)) {
            track();
            target_left = left_speed;
            target_right = right_speed;
            apply_task_two_slowdown(&target_left, &target_right,
                task_elapsed_ms);
        } else if (task_mode == TASK_ONE_LAP) {
        switch (phase) {
        case DRIVE_TRACK:
            g_task_one_stability_active =
                (g_g356_absolute_yaw_degrees >=
                    TASK_ONE_STABILITY_YAW_DEG) ? 1U : 0U;
            if (lap_finish_detected(&lap_finish) &&
                !lap_finish.decel_started) {
                lap_finish.decel_started = 1U;
                lap_finish.decel_start_ms = task_elapsed_ms;
            }

            track();
            target_left = left_speed;
            target_right = right_speed;
            task_one_reduce_differential(&target_left, &target_right);
            uint8_t decel_finished = apply_task_one_slowdown(
                &lap_finish, &target_left, &target_right,
                task_elapsed_ms);
            task_one_start_scale =
                task_one_soft_start_scale(task_elapsed_ms);
            if (decel_finished) {
                phase = DRIVE_FINISHED;
                completed_lap_count = 1U;
                brake_motors();
                OLED_FreezeElapsedClock();
            }
            break;

        case DRIVE_FINISHED:
        default:
            target_left = 0;
            target_right = 0;
            brake_motors();
            break;
        }
        } else if (task_mode == TASK_THREE_BASIC) {
            if (phase == DRIVE_FINISHED) {
                target_left = 0;
                target_right = 0;
                brake_motors();
            } else if (lap_finish_detected(&lap_finish)) {
                phase = DRIVE_FINISHED;
                completed_lap_count = 1U;
                target_left = 0;
                target_right = 0;
                brake_motors();
                OLED_FreezeElapsedClock();
            } else {
                track();
                target_left = left_speed;
                target_right = right_speed;
            }
        } else if (task_mode == TASK_FOUR_SMOOTH_LAP) {
            if (phase == DRIVE_FINISHED) {
                target_left = 0;
                target_right = 0;
                brake_motors();
            } else if (lap_finish_detected(&lap_finish)) {
                task_four_finish_detected = 1U;
            }
        }

        /* Keep the 20 ms speed sampling and PID ahead of slower UI work. */
        MotorSpeed_Process();
        uint32_t now = millis();
        uint32_t elapsed_pid_ms = now - last_pid_ms;
        if ((phase != DRIVE_FINISHED) &&
            MotorSpeed_Ready() &&
            (elapsed_pid_ms >= LEFT_PID_PERIOD_MS)) {
            last_pid_ms = now;
            float dt_seconds = (float)elapsed_pid_ms / 1000.0f;

            uint8_t task_four_finished_now = 0U;
            if (task_mode == TASK_FOUR_SMOOTH_LAP) {
                task_four_finished_now = task_four_update(&task_four,
                    elapsed_pid_ms, task_elapsed_ms,
                    task_four_finish_detected, g_motor_left_speed,
                    g_motor_right_speed, &target_left, &target_right);
                if (task_four_finished_now) {
                    phase = DRIVE_FINISHED;
                    completed_lap_count = task_four.fault ? 0U : 1U;
                    target_left = 0;
                    target_right = 0;
                    brake_motors();
                    OLED_FreezeElapsedClock();
                }
            }

            float left_pid_target = (float)target_left;
            float right_pid_target = (float)target_right;
            if (task_mode == TASK_ONE_LAP) {
                left_pid_target *= task_one_start_scale;
                right_pid_target *= task_one_start_scale;
                g_task_one_left_smoothed_target = task_one_smooth_target(
                    g_task_one_left_smoothed_target, left_pid_target,
                    dt_seconds);
                g_task_one_right_smoothed_target = task_one_smooth_target(
                    g_task_one_right_smoothed_target, right_pid_target,
                    dt_seconds);
                left_pid_target = g_task_one_left_smoothed_target;
                right_pid_target = g_task_one_right_smoothed_target;
            }

            if (!task_four_finished_now) {
                int32_t desired_left_pwm = speed_pid_command(&left_pid,
                    left_pid_target,
                    g_motor_left_speed, MOTOR_SPEED_TEST_PWM_L,
                    MOTOR_SPEED_TEST_TARGET_L, dt_seconds);
                int32_t desired_right_pwm = speed_pid_command(&right_pid,
                    right_pid_target,
                    g_motor_right_speed, MOTOR_SPEED_TEST_PWM_R,
                    MOTOR_SPEED_TEST_TARGET_R, dt_seconds);
                if (task_mode == TASK_TWO_TIMED) {
                    left_pwm = task_two_soft_start_limit(desired_left_pwm,
                        task_elapsed_ms);
                    right_pwm = task_two_soft_start_limit(desired_right_pwm,
                        task_elapsed_ms);
                } else {
                    left_pwm = desired_left_pwm;
                    right_pwm = desired_right_pwm;
                }
                set_Lspeed(left_pwm);
                set_Rspeed(right_pwm);
            }
        }

        VISION_Process(millis());
        BallBalance_Process(millis());
        Stepper_Process();
        OLED_Process();
        delay_ms(5U);
    }
}
