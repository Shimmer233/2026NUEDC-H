/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2000
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMA0
#define PWM_MOTOR_INST_IRQHandler                               TIMA0_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                         40000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C0_PIN                                      DL_GPIO_PIN_8
#define GPIO_PWM_MOTOR_C0_IOMUX                                  (IOMUX_PINCM25)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                 IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C1_PIN                                      DL_GPIO_PIN_9
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM26)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX
/* GPIO defines for channel 2 */
#define GPIO_PWM_MOTOR_C2_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C2_PIN                                     DL_GPIO_PIN_12
#define GPIO_PWM_MOTOR_C2_IOMUX                                  (IOMUX_PINCM29)
#define GPIO_PWM_MOTOR_C2_IOMUX_FUNC                 IOMUX_PINCM29_PF_TIMA0_CCP2
#define GPIO_PWM_MOTOR_C2_IDX                                DL_TIMER_CC_2_INDEX
/* GPIO defines for channel 3 */
#define GPIO_PWM_MOTOR_C3_PORT                                             GPIOB
#define GPIO_PWM_MOTOR_C3_PIN                                     DL_GPIO_PIN_13
#define GPIO_PWM_MOTOR_C3_IOMUX                                  (IOMUX_PINCM30)
#define GPIO_PWM_MOTOR_C3_IOMUX_FUNC                 IOMUX_PINCM30_PF_TIMA0_CCP3
#define GPIO_PWM_MOTOR_C3_IDX                                DL_TIMER_CC_3_INDEX



/* Defines for UART_VISION */
#define UART_VISION_INST                                                   UART1
#define UART_VISION_INST_FREQUENCY                                      40000000
#define UART_VISION_INST_IRQHandler                             UART1_IRQHandler
#define UART_VISION_INST_INT_IRQN                                 UART1_INT_IRQn
#define GPIO_UART_VISION_RX_PORT                                           GPIOB
#define GPIO_UART_VISION_TX_PORT                                           GPIOB
#define GPIO_UART_VISION_RX_PIN                                    DL_GPIO_PIN_7
#define GPIO_UART_VISION_TX_PIN                                    DL_GPIO_PIN_6
#define GPIO_UART_VISION_IOMUX_RX                                (IOMUX_PINCM24)
#define GPIO_UART_VISION_IOMUX_TX                                (IOMUX_PINCM23)
#define GPIO_UART_VISION_IOMUX_RX_FUNC                 IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_VISION_IOMUX_TX_FUNC                 IOMUX_PINCM23_PF_UART1_TX
#define UART_VISION_BAUD_RATE                                           (115200)
#define UART_VISION_IBRD_40_MHZ_115200_BAUD                                 (21)
#define UART_VISION_FBRD_40_MHZ_115200_BAUD                                 (45)
/* Defines for UART_G356 */
#define UART_G356_INST                                                     UART0
#define UART_G356_INST_FREQUENCY                                        40000000
#define UART_G356_INST_IRQHandler                               UART0_IRQHandler
#define UART_G356_INST_INT_IRQN                                   UART0_INT_IRQn
#define GPIO_UART_G356_RX_PORT                                             GPIOA
#define GPIO_UART_G356_TX_PORT                                             GPIOA
#define GPIO_UART_G356_RX_PIN                                      DL_GPIO_PIN_1
#define GPIO_UART_G356_TX_PIN                                      DL_GPIO_PIN_0
#define GPIO_UART_G356_IOMUX_RX                                   (IOMUX_PINCM2)
#define GPIO_UART_G356_IOMUX_TX                                   (IOMUX_PINCM1)
#define GPIO_UART_G356_IOMUX_RX_FUNC                    IOMUX_PINCM2_PF_UART0_RX
#define GPIO_UART_G356_IOMUX_TX_FUNC                    IOMUX_PINCM1_PF_UART0_TX
#define UART_G356_BAUD_RATE                                             (115200)
#define UART_G356_IBRD_40_MHZ_115200_BAUD                                   (21)
#define UART_G356_FBRD_40_MHZ_115200_BAUD                                   (45)
/* Defines for UART_STEPPER */
#define UART_STEPPER_INST                                                  UART3
#define UART_STEPPER_INST_FREQUENCY                                     80000000
#define UART_STEPPER_INST_IRQHandler                            UART3_IRQHandler
#define UART_STEPPER_INST_INT_IRQN                                UART3_INT_IRQn
#define GPIO_UART_STEPPER_RX_PORT                                          GPIOA
#define GPIO_UART_STEPPER_TX_PORT                                          GPIOA
#define GPIO_UART_STEPPER_RX_PIN                                  DL_GPIO_PIN_25
#define GPIO_UART_STEPPER_TX_PIN                                  DL_GPIO_PIN_26
#define GPIO_UART_STEPPER_IOMUX_RX                               (IOMUX_PINCM55)
#define GPIO_UART_STEPPER_IOMUX_TX                               (IOMUX_PINCM59)
#define GPIO_UART_STEPPER_IOMUX_RX_FUNC                IOMUX_PINCM55_PF_UART3_RX
#define GPIO_UART_STEPPER_IOMUX_TX_FUNC                IOMUX_PINCM59_PF_UART3_TX
#define UART_STEPPER_BAUD_RATE                                          (115200)
#define UART_STEPPER_IBRD_80_MHZ_115200_BAUD                                (43)
#define UART_STEPPER_FBRD_80_MHZ_115200_BAUD                                (26)
/* Defines for UART_ENCODER_LINK */
#define UART_ENCODER_LINK_INST                                             UART2
#define UART_ENCODER_LINK_INST_FREQUENCY                                40000000
#define UART_ENCODER_LINK_INST_IRQHandler                        UART2_IRQHandler
#define UART_ENCODER_LINK_INST_INT_IRQN                           UART2_INT_IRQn
#define GPIO_UART_ENCODER_LINK_RX_PORT                                     GPIOA
#define GPIO_UART_ENCODER_LINK_TX_PORT                                     GPIOA
#define GPIO_UART_ENCODER_LINK_RX_PIN                             DL_GPIO_PIN_24
#define GPIO_UART_ENCODER_LINK_TX_PIN                             DL_GPIO_PIN_23
#define GPIO_UART_ENCODER_LINK_IOMUX_RX                          (IOMUX_PINCM54)
#define GPIO_UART_ENCODER_LINK_IOMUX_TX                          (IOMUX_PINCM53)
#define GPIO_UART_ENCODER_LINK_IOMUX_RX_FUNC               IOMUX_PINCM54_PF_UART2_RX
#define GPIO_UART_ENCODER_LINK_IOMUX_TX_FUNC               IOMUX_PINCM53_PF_UART2_TX
#define UART_ENCODER_LINK_BAUD_RATE                                     (115200)
#define UART_ENCODER_LINK_IBRD_40_MHZ_115200_BAUD                           (21)
#define UART_ENCODER_LINK_FBRD_40_MHZ_115200_BAUD                           (45)





/* Port definition for Pin Group GPIO_BOARD */
#define GPIO_BOARD_PORT                                                  (GPIOA)

/* Defines for PIN_A14_LOW: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_BOARD_PIN_A14_LOW_PIN                              (DL_GPIO_PIN_14)
#define GPIO_BOARD_PIN_A14_LOW_IOMUX                             (IOMUX_PINCM36)
/* Port definition for Pin Group GPIO_BALL_TASK_FOUR_KEY */
#define GPIO_BALL_TASK_FOUR_KEY_PORT                                     (GPIOB)

/* Defines for PIN_BALL_TASK_FOUR_START: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_BALL_TASK_FOUR_KEY_PIN_BALL_TASK_FOUR_START_PIN    (DL_GPIO_PIN_21)
#define GPIO_BALL_TASK_FOUR_KEY_PIN_BALL_TASK_FOUR_START_IOMUX     (IOMUX_PINCM49)
/* Port definition for Pin Group GPIO_ENCODER_VERIFY */
#define GPIO_ENCODER_VERIFY_PORT                                         (GPIOB)

/* Defines for PIN_PB22: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_ENCODER_VERIFY_PIN_PB22_PIN                        (DL_GPIO_PIN_22)
#define GPIO_ENCODER_VERIFY_PIN_PB22_IOMUX                       (IOMUX_PINCM50)
/* Port definition for Pin Group GPIO_key */
#define GPIO_key_PORT                                                    (GPIOB)

/* Defines for PIN_LAP_SELECT: GPIOB.1 with pinCMx 13 on package pin 48 */
#define GPIO_key_PIN_LAP_SELECT_PIN                              (DL_GPIO_PIN_1)
#define GPIO_key_PIN_LAP_SELECT_IOMUX                            (IOMUX_PINCM13)
/* Defines for PIN_START: GPIOB.0 with pinCMx 12 on package pin 47 */
#define GPIO_key_PIN_START_PIN                                   (DL_GPIO_PIN_0)
#define GPIO_key_PIN_START_IOMUX                                 (IOMUX_PINCM12)
/* Defines for PIN_one: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_grey_tracking_PIN_one_PORT                                  (GPIOB)
#define GPIO_grey_tracking_PIN_one_PIN                          (DL_GPIO_PIN_17)
#define GPIO_grey_tracking_PIN_one_IOMUX                         (IOMUX_PINCM43)
/* Defines for PIN_two: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_grey_tracking_PIN_two_PORT                                  (GPIOB)
#define GPIO_grey_tracking_PIN_two_PIN                          (DL_GPIO_PIN_18)
#define GPIO_grey_tracking_PIN_two_IOMUX                         (IOMUX_PINCM44)
/* Defines for PIN_three: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_grey_tracking_PIN_three_PORT                                (GPIOA)
#define GPIO_grey_tracking_PIN_three_PIN                        (DL_GPIO_PIN_12)
#define GPIO_grey_tracking_PIN_three_IOMUX                       (IOMUX_PINCM34)
/* Defines for PIN_four: GPIOA.9 with pinCMx 20 on package pin 55 */
#define GPIO_grey_tracking_PIN_four_PORT                                 (GPIOA)
#define GPIO_grey_tracking_PIN_four_PIN                          (DL_GPIO_PIN_9)
#define GPIO_grey_tracking_PIN_four_IOMUX                        (IOMUX_PINCM20)
/* Defines for PIN_five: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_grey_tracking_PIN_five_PORT                                 (GPIOA)
#define GPIO_grey_tracking_PIN_five_PIN                          (DL_GPIO_PIN_7)
#define GPIO_grey_tracking_PIN_five_IOMUX                        (IOMUX_PINCM14)
/* Defines for PIN_six: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GPIO_grey_tracking_PIN_six_PORT                                  (GPIOA)
#define GPIO_grey_tracking_PIN_six_PIN                          (DL_GPIO_PIN_15)
#define GPIO_grey_tracking_PIN_six_IOMUX                         (IOMUX_PINCM37)
/* Defines for PIN_seven: GPIOA.8 with pinCMx 19 on package pin 54 */
#define GPIO_grey_tracking_PIN_seven_PORT                                (GPIOA)
#define GPIO_grey_tracking_PIN_seven_PIN                         (DL_GPIO_PIN_8)
#define GPIO_grey_tracking_PIN_seven_IOMUX                       (IOMUX_PINCM19)
/* Defines for PIN_eight: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_grey_tracking_PIN_eight_PORT                                (GPIOA)
#define GPIO_grey_tracking_PIN_eight_PIN                        (DL_GPIO_PIN_13)
#define GPIO_grey_tracking_PIN_eight_IOMUX                       (IOMUX_PINCM35)
/* Defines for LEFT_A: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_ENCODER_LEFT_A_PORT                                         (GPIOA)
// pins affected by this interrupt request:["LEFT_A"]
#define GPIO_ENCODER_GPIOA_INT_IRQN                             (GPIOA_INT_IRQn)
#define GPIO_ENCODER_GPIOA_INT_IIDX             (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_LEFT_A_IIDX                            (DL_GPIO_IIDX_DIO22)
#define GPIO_ENCODER_LEFT_A_PIN                                 (DL_GPIO_PIN_22)
#define GPIO_ENCODER_LEFT_A_IOMUX                                (IOMUX_PINCM47)
/* Defines for LEFT_B: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_ENCODER_LEFT_B_PORT                                         (GPIOA)
#define GPIO_ENCODER_LEFT_B_PIN                                 (DL_GPIO_PIN_27)
#define GPIO_ENCODER_LEFT_B_IOMUX                                (IOMUX_PINCM60)
/* Defines for RIGHT_A: GPIOB.10 with pinCMx 27 on package pin 62 */
#define GPIO_ENCODER_RIGHT_A_PORT                                        (GPIOB)
// pins affected by this interrupt request:["RIGHT_A"]
#define GPIO_ENCODER_GPIOB_INT_IRQN                             (GPIOB_INT_IRQn)
#define GPIO_ENCODER_GPIOB_INT_IIDX             (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_ENCODER_RIGHT_A_IIDX                           (DL_GPIO_IIDX_DIO10)
#define GPIO_ENCODER_RIGHT_A_PIN                                (DL_GPIO_PIN_10)
#define GPIO_ENCODER_RIGHT_A_IOMUX                               (IOMUX_PINCM27)
/* Defines for RIGHT_B: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_ENCODER_RIGHT_B_PORT                                        (GPIOB)
#define GPIO_ENCODER_RIGHT_B_PIN                                (DL_GPIO_PIN_11)
#define GPIO_ENCODER_RIGHT_B_IOMUX                               (IOMUX_PINCM28)
/* Port definition for Pin Group GPIO_TASK_THREE_KEY */
#define GPIO_TASK_THREE_KEY_PORT                                         (GPIOA)

/* Defines for PIN_TASK_THREE_START: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_TASK_THREE_KEY_PIN_TASK_THREE_START_PIN            (DL_GPIO_PIN_31)
#define GPIO_TASK_THREE_KEY_PIN_TASK_THREE_START_IOMUX            (IOMUX_PINCM6)
/* Defines for PIN_TASK_FOUR_START: GPIOA.30 with pinCMx 5 on package pin 37 */
#define GPIO_TASK_THREE_KEY_PIN_TASK_FOUR_START_PIN             (DL_GPIO_PIN_30)
#define GPIO_TASK_THREE_KEY_PIN_TASK_FOUR_START_IOMUX             (IOMUX_PINCM5)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_SYSCTL_CLK_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_UART_VISION_init(void);
void SYSCFG_DL_UART_G356_init(void);
void SYSCFG_DL_UART_STEPPER_init(void);
void SYSCFG_DL_UART_ENCODER_LINK_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
