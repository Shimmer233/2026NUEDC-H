#include "vision.h"

#include <string.h>

#include "g356.h"
#include "headerfile.h"
#include "ti_msp_dl_config.h"

#define VISION_RX_RING_SIZE       128U
#define VISION_RX_RING_MASK       (VISION_RX_RING_SIZE - 1U)
#define VISION_UART_INT_MASK                                           \
    (DL_UART_MAIN_INTERRUPT_RX | DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR | \
        DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |                         \
        DL_UART_MAIN_INTERRUPT_BREAK_ERROR |                           \
        DL_UART_MAIN_INTERRUPT_PARITY_ERROR |                          \
        DL_UART_MAIN_INTERRUPT_FRAMING_ERROR)

static uint32_t g_vision_last_send_ms;
static uint32_t g_vision_last_g356_frame_count;
static char g_vision_rx_line[VISION_RX_LINE_SIZE];
static uint8_t g_vision_rx_line_length;
static volatile uint8_t g_vision_rx_ring[VISION_RX_RING_SIZE];
static volatile uint16_t g_vision_rx_ring_head;
static volatile uint16_t g_vision_rx_ring_tail;
static uint8_t g_vision_tx_frame[VISION_ACCEL_FRAME_SIZE];
static uint8_t g_vision_tx_index;
static uint8_t g_vision_tx_active;

volatile float g_vision_ball_position_cm;
volatile float g_vision_ball_velocity_cm_s;
volatile uint8_t g_vision_pv_valid;
volatile uint32_t g_vision_pv_update_count;
volatile uint32_t g_vision_pv_last_ms;
volatile float g_vision_ball_distance_cm;
volatile uint8_t g_vision_ball_distance_valid;
volatile uint32_t g_vision_ball_distance_update_count;
volatile uint32_t g_vision_ball_distance_last_ms;
volatile uint8_t g_vision_rx_last_byte;
volatile uint32_t g_vision_rx_byte_count;
volatile uint32_t g_vision_rx_overflow_count;
volatile uint32_t g_vision_uart_error_count;
volatile char g_vision_rx_last_line[VISION_RX_LINE_SIZE];

static void vision_skip_spaces(const char **cursor)
{
    while ((**cursor == ' ') || (**cursor == '\t')) {
        (*cursor)++;
    }
}

static uint8_t vision_parse_float(const char **cursor, float *result)
{
    float integer_part = 0.0f;
    float fraction_part = 0.0f;
    float fraction_scale = 1.0f;
    uint8_t negative = 0U;
    uint8_t digit_count = 0U;

    vision_skip_spaces(cursor);
    if ((**cursor == '+') || (**cursor == '-')) {
        negative = (**cursor == '-') ? 1U : 0U;
        (*cursor)++;
    }
    while ((**cursor >= '0') && (**cursor <= '9')) {
        integer_part = integer_part * 10.0f +
            (float)(**cursor - '0');
        digit_count++;
        (*cursor)++;
    }
    if (**cursor == '.') {
        (*cursor)++;
        while ((**cursor >= '0') && (**cursor <= '9')) {
            fraction_part = fraction_part * 10.0f +
                (float)(**cursor - '0');
            fraction_scale *= 10.0f;
            digit_count++;
            (*cursor)++;
        }
    }
    if (digit_count == 0U) {
        return 0U;
    }

    *result = integer_part + fraction_part / fraction_scale;
    if (negative) {
        *result = -*result;
    }
    return 1U;
}

static uint8_t vision_parse_position_velocity(
    const char *line, float *position_cm, float *velocity_cm_s)
{
    const char *cursor = line;
    uint8_t demo_format = 0U;

    vision_skip_spaces(&cursor);
    if (strncmp(cursor, "PV,", 3U) == 0) {
        cursor += 3;
    } else if (strncmp(cursor, "demo:", 5U) == 0) {
        cursor += 5;
        demo_format = 1U;
    } else {
        return 0U;
    }

    if (!vision_parse_float(&cursor, position_cm)) {
        return 0U;
    }
    vision_skip_spaces(&cursor);
    if (*cursor != ',') {
        return 0U;
    }
    cursor++;

    if (!vision_parse_float(&cursor, velocity_cm_s)) {
        return 0U;
    }
    vision_skip_spaces(&cursor);
    if (demo_format && (*cursor == ',')) {
        return 1U;
    }
    return (*cursor == '\0') ? 1U : 0U;
}

static void vision_finish_rx_line(uint32_t now_ms)
{
    float position_cm;
    float velocity_cm_s;

    if (g_vision_rx_line_length == 0U) {
        return;
    }

    g_vision_rx_line[g_vision_rx_line_length] = '\0';
    for (uint8_t i = 0U; i <= g_vision_rx_line_length; i++) {
        g_vision_rx_last_line[i] = g_vision_rx_line[i];
    }

    if (vision_parse_position_velocity(
            g_vision_rx_line, &position_cm, &velocity_cm_s)) {
        g_vision_ball_position_cm = position_cm;
        g_vision_ball_velocity_cm_s = velocity_cm_s;
        g_vision_pv_valid = 1U;
        g_vision_pv_update_count++;
        g_vision_pv_last_ms = now_ms;

        g_vision_ball_distance_cm = position_cm;
        g_vision_ball_distance_valid = 1U;
        g_vision_ball_distance_update_count++;
        g_vision_ball_distance_last_ms = now_ms;
    } else {
        g_vision_pv_valid = 0U;
        g_vision_ball_distance_valid = 0U;
    }
    g_vision_rx_line_length = 0U;
}

static void vision_process_rx(uint32_t now_ms)
{
    while (g_vision_rx_ring_tail != g_vision_rx_ring_head) {
        uint8_t byte = g_vision_rx_ring[g_vision_rx_ring_tail];
        g_vision_rx_ring_tail =
            (uint16_t)((g_vision_rx_ring_tail + 1U) & VISION_RX_RING_MASK);
        g_vision_rx_last_byte = byte;
        g_vision_rx_byte_count++;

        if ((byte == '\r') || (byte == '\n')) {
            vision_finish_rx_line(now_ms);
        } else if ((byte >= 0x20U) && (byte <= 0x7EU)) {
            if (g_vision_rx_line_length < (VISION_RX_LINE_SIZE - 1U)) {
                g_vision_rx_line[g_vision_rx_line_length++] = (char)byte;
            } else {
                g_vision_rx_line_length = 0U;
                g_vision_pv_valid = 0U;
                g_vision_ball_distance_valid = 0U;
            }
        }
    }
}

void VISION_Init(void)
{
    g_vision_last_send_ms = 0U;
    g_vision_last_g356_frame_count = 0U;
    g_vision_rx_line_length = 0U;
    g_vision_rx_ring_head = 0U;
    g_vision_rx_ring_tail = 0U;
    g_vision_tx_index = 0U;
    g_vision_tx_active = 0U;
    g_vision_ball_position_cm = 0.0f;
    g_vision_ball_velocity_cm_s = 0.0f;
    g_vision_pv_valid = 0U;
    g_vision_pv_update_count = 0U;
    g_vision_pv_last_ms = 0U;
    g_vision_ball_distance_cm = 0.0f;
    g_vision_ball_distance_valid = 0U;
    g_vision_ball_distance_update_count = 0U;
    g_vision_ball_distance_last_ms = 0U;
    g_vision_rx_last_byte = 0U;
    g_vision_rx_byte_count = 0U;
    g_vision_rx_overflow_count = 0U;
    g_vision_uart_error_count = 0U;
    memset((void *)g_vision_rx_last_line, 0,
        sizeof(g_vision_rx_last_line));

    DL_UART_Main_disableInterrupt(UART_VISION_INST, VISION_UART_INT_MASK);
    NVIC_DisableIRQ(UART_VISION_INST_INT_IRQN);
    DL_UART_Main_setRXFIFOThreshold(
        UART_VISION_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setRXInterruptTimeout(UART_VISION_INST, 1U);
    DL_UART_Main_clearInterruptStatus(
        UART_VISION_INST, VISION_UART_INT_MASK);
    DL_UART_Main_enableInterrupt(UART_VISION_INST, VISION_UART_INT_MASK);
    NVIC_ClearPendingIRQ(UART_VISION_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_VISION_INST_INT_IRQN);
}

static void vision_pump_tx(void)
{
    while (g_vision_tx_active &&
        (g_vision_tx_index < VISION_ACCEL_FRAME_SIZE) &&
        DL_UART_Main_transmitDataCheck(UART_VISION_INST,
            g_vision_tx_frame[g_vision_tx_index])) {
        g_vision_tx_index++;
    }
    if (g_vision_tx_index >= VISION_ACCEL_FRAME_SIZE) {
        g_vision_tx_active = 0U;
    }
}

void UART_VISION_INST_IRQHandler(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_VISION_INST)) {
        uint32_t rx_data = UART_VISION_INST->RXDATA;
        uint16_t next_head = (uint16_t)(
            (g_vision_rx_ring_head + 1U) & VISION_RX_RING_MASK);

        if ((rx_data & (DL_UART_ERROR_OVERRUN | DL_UART_ERROR_BREAK |
             DL_UART_ERROR_PARITY | DL_UART_ERROR_FRAMING)) != 0U) {
            g_vision_uart_error_count++;
        }
        if (next_head == g_vision_rx_ring_tail) {
            g_vision_rx_overflow_count++;
            continue;
        }
        g_vision_rx_ring[g_vision_rx_ring_head] =
            (uint8_t)(rx_data & UART_RXDATA_DATA_MASK);
        g_vision_rx_ring_head = next_head;
    }

    DL_UART_Main_clearInterruptStatus(
        UART_VISION_INST, VISION_UART_INT_MASK);
}

void VISION_Process(uint32_t now_ms)
{
    G356_Data_t data;
    uint32_t frame_count;

    vision_process_rx(now_ms);
    vision_pump_tx();

    if (g_vision_tx_active) {
        return;
    }

    if ((now_ms - g_vision_last_send_ms) < VISION_SEND_PERIOD_MS) {
        return;
    }
    if (!G356_UART_GetLatest(&data, &frame_count) ||
        (frame_count == g_vision_last_g356_frame_count)) {
        return;
    }

    g_vision_tx_frame[0] = 0xAAU;
    g_vision_tx_frame[1] = 0x56U;
    g_vision_tx_frame[2] = 0x01U;
    g_vision_tx_frame[3] = 12U;
    memcpy(&g_vision_tx_frame[4], &data.accel_x, sizeof(data.accel_x));
    memcpy(&g_vision_tx_frame[8], &data.accel_y, sizeof(data.accel_y));
    memcpy(&g_vision_tx_frame[12], &data.accel_z, sizeof(data.accel_z));

    uint8_t checksum = 0U;
    for (uint8_t i = 2U; i <= 15U; i++) {
        checksum = (uint8_t)(checksum + g_vision_tx_frame[i]);
    }
    g_vision_tx_frame[16] = checksum;
    g_vision_tx_frame[17] = 0x5AU;
    g_vision_tx_index = 0U;
    g_vision_tx_active = 1U;
    g_vision_last_send_ms = now_ms;
    g_vision_last_g356_frame_count = frame_count;
    vision_pump_tx();
}
