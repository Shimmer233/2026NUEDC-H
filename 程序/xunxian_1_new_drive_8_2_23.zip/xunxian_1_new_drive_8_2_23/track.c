#include "headerfile.h"

volatile uint8_t sensor_d1 = 0;
volatile uint8_t sensor_d2 = 0;
volatile uint8_t sensor_d3 = 0;
volatile uint8_t sensor_d4 = 0;
volatile uint8_t sensor_d5 = 0;
volatile uint8_t sensor_d6 = 0;
volatile uint8_t sensor_d7 = 0;
volatile uint8_t sensor_d8 = 0;

static float filtered_error = 0.0f;
static float last_error = 0.0f;

static uint8_t read_sensor(uint8_t index)
{
    switch (index) {
    case 1: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_one_PORT,   GPIO_grey_tracking_PIN_one_PIN)   & GPIO_grey_tracking_PIN_one_PIN)   ? 1 : 0;
    case 2: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_two_PORT,   GPIO_grey_tracking_PIN_two_PIN)   & GPIO_grey_tracking_PIN_two_PIN)   ? 1 : 0;
    case 3: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_three_PORT, GPIO_grey_tracking_PIN_three_PIN) & GPIO_grey_tracking_PIN_three_PIN) ? 1 : 0;
    case 4: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_four_PORT,  GPIO_grey_tracking_PIN_four_PIN)  & GPIO_grey_tracking_PIN_four_PIN)  ? 1 : 0;
    case 5: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_five_PORT,  GPIO_grey_tracking_PIN_five_PIN)  & GPIO_grey_tracking_PIN_five_PIN)  ? 1 : 0;
    case 6: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_six_PORT,   GPIO_grey_tracking_PIN_six_PIN)   & GPIO_grey_tracking_PIN_six_PIN)   ? 1 : 0;
    case 7: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_seven_PORT, GPIO_grey_tracking_PIN_seven_PIN) & GPIO_grey_tracking_PIN_seven_PIN) ? 1 : 0;
    case 8: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_eight_PORT, GPIO_grey_tracking_PIN_eight_PIN) & GPIO_grey_tracking_PIN_eight_PIN) ? 1 : 0;
    default: return 0;
    }
}

void update_sensors(void)
{
    sensor_d1 = read_sensor(1);
    sensor_d2 = read_sensor(2);
    sensor_d3 = read_sensor(3);
    sensor_d4 = read_sensor(4);
    sensor_d5 = read_sensor(5);
    sensor_d6 = read_sensor(6);
    sensor_d7 = read_sensor(7);
    sensor_d8 = read_sensor(8);
}

/* 八路灰度加权巡线。
 * D1 到 D8 从车头左侧向右侧排列，对应权重：
 * [-5, -3.5, -1.5, -0.5, +0.5, +1.5, +3.5, +5]。
 * 多路同时有效时取平均位置，再通过比例控制生成左右轮差速。 */
void track(void)
{
    float error = 0.0f;
    int active = 0;

    uint8_t center_detected =
        (sensor_d4 == SENSOR_LINE_LEVEL) ||
        (sensor_d5 == SENSOR_LINE_LEVEL);
    uint8_t outer_detected =
        (sensor_d1 == SENSOR_LINE_LEVEL) ||
        (sensor_d2 == SENSOR_LINE_LEVEL) ||
        (sensor_d3 == SENSOR_LINE_LEVEL) ||
        (sensor_d6 == SENSOR_LINE_LEVEL) ||
        (sensor_d7 == SENSOR_LINE_LEVEL) ||
        (sensor_d8 == SENSOR_LINE_LEVEL);

    /* D4/D5 center combinations use one straight-ahead speed setting. */
    if (center_detected && !outer_detected) {
        filtered_error = 0.0f;
        last_error = 0.0f;
        left_speed = TRACK_BASE_SPEED;
        right_speed = TRACK_BASE_SPEED;
        return;
    }

    if (sensor_d1 == SENSOR_LINE_LEVEL) { error += -5.0f; active++; }
    if (sensor_d2 == SENSOR_LINE_LEVEL) { error += -3.5f; active++; }
    if (sensor_d3 == SENSOR_LINE_LEVEL) { error += -1.5f; active++; }
    if (sensor_d4 == SENSOR_LINE_LEVEL) { error += -0.5f; active++; }
    if (sensor_d5 == SENSOR_LINE_LEVEL) { error +=  0.5f; active++; }
    if (sensor_d6 == SENSOR_LINE_LEVEL) { error +=  1.5f; active++; }
    if (sensor_d7 == SENSOR_LINE_LEVEL) { error +=  3.5f; active++; }
    if (sensor_d8 == SENSOR_LINE_LEVEL) { error +=  5.0f; active++; }

    if (active > 0) {
        error /= (float) active;
        filtered_error = 0.30f * filtered_error + 0.70f * error;
        last_error = filtered_error;
        /* 提高比例增益以增大差速，同时用限幅避免修正过猛。 */
        float adj = filtered_error * TRACK_KP;
        if (adj >  TRACK_MAX_ADJUST) adj =  TRACK_MAX_ADJUST;
        if (adj < -TRACK_MAX_ADJUST) adj = -TRACK_MAX_ADJUST;
        left_speed  = (int16_t)(TRACK_BASE_SPEED + adj);
        right_speed = (int16_t)(TRACK_BASE_SPEED - adj);
    } else if (last_error > 0.1f) {
        /* 丢线后按上一次偏差方向向右搜索。 */
        left_speed  = TRACK_SEARCH_SPEED + TRACK_SEARCH_ADJUST;
        right_speed = TRACK_SEARCH_SPEED - TRACK_SEARCH_ADJUST;
    } else if (last_error < -0.1f) {
        /* 丢线后按上一次偏差方向向左搜索。 */
        left_speed  = TRACK_SEARCH_SPEED - TRACK_SEARCH_ADJUST;
        right_speed = TRACK_SEARCH_SPEED + TRACK_SEARCH_ADJUST;
    } else {
        /* 上电后尚无偏差记录时低速直行搜索。 */
        left_speed  = TRACK_SEARCH_SPEED;
        right_speed = TRACK_SEARCH_SPEED;
    }
}

void track_reset(void)
{
    filtered_error = 0.0f;
    last_error = 0.0f;
}

uint8_t check_cross_left(void)
{
    return (sensor_d1 == SENSOR_LINE_LEVEL &&
            sensor_d2 == SENSOR_LINE_LEVEL &&
            sensor_d3 == SENSOR_LINE_LEVEL);
}

uint8_t check_cross_right(void)
{
    return (sensor_d6 == SENSOR_LINE_LEVEL &&
            sensor_d7 == SENSOR_LINE_LEVEL &&
            sensor_d8 == SENSOR_LINE_LEVEL);
}

uint8_t check_parking_line(void)
{
    uint8_t left_parking_line =
        (sensor_d2 == SENSOR_LINE_LEVEL &&
         sensor_d3 == SENSOR_LINE_LEVEL &&
         sensor_d4 == SENSOR_LINE_LEVEL);
    uint8_t right_parking_line =
        (sensor_d4 == SENSOR_LINE_LEVEL &&
         sensor_d5 == SENSOR_LINE_LEVEL &&
         sensor_d6 == SENSOR_LINE_LEVEL);

    return left_parking_line || right_parking_line;
}
