#ifndef ENCODER_H
#define ENCODER_H

#include <stdbool.h>
#include <stdint.h>

#define ENCODER_LINK_FRAME_SIZE       20U
#define ENCODER_LINK_PROTOCOL_VERSION 0x01U
#define ENCODER_LINK_VERIFY_THRESHOLD 3000U

typedef struct {
    uint8_t protocol_version;
    uint8_t task_id;
    uint16_t frame_sequence;
    uint32_t left_count;
    uint32_t right_count;
    uint32_t average_count;
} EncoderLink_Data_t;

extern volatile int32_t g_encoder_left_total;
extern volatile int32_t g_encoder_right_total;
extern volatile int32_t g_encoder_left_delta;
extern volatile int32_t g_encoder_right_delta;
extern volatile float g_left_motor_speed;
extern volatile float g_right_motor_speed;
extern volatile EncoderLink_Data_t g_encoder_link_latest;
extern volatile uint32_t g_encoder_link_valid_count;
extern volatile uint32_t g_encoder_link_invalid_count;
extern volatile uint32_t g_encoder_link_uart_error_count;
extern volatile uint8_t g_encoder_link_pb22_high;

void Encoder_Init(void);
/* UART2: PA23 TX, PA24 RX, 115200 baud, 8N1, no flow control. */
void EncoderLink_UART_Init(void);
bool EncoderLink_GetLatest(EncoderLink_Data_t *data, uint32_t *frame_count);
void Encoder_GetAndResetDeltas(int32_t *left, int32_t *right);
void Encoder_SampleSpeeds(uint32_t elapsed_ms,
    int32_t *left_delta, int32_t *right_delta);
void Encoder_GetTotals(int32_t *left, int32_t *right);

#endif
