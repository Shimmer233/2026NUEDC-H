#include "pid.h"

void PID_Init(PID_Controller *pid, float kp, float ki, float kd,
    float output_min, float output_max, float integral_error_limit)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->output_min = output_min;
    pid->output_max = output_max;
    pid->integral_error_limit = integral_error_limit;
    PID_Reset(pid);
}

void PID_Reset(PID_Controller *pid)
{
    pid->integral = 0.0f;
    pid->previous_error = 0.0f;
    pid->initialized = 0U;
}

float PID_Update(PID_Controller *pid, float target, float measured,
    float dt_seconds)
{
    float error = target - measured;
    float derivative = 0.0f;

    if ((pid->initialized != 0U) && (dt_seconds > 0.0f)) {
        derivative = (error - pid->previous_error) / dt_seconds;
    }

    float candidate_integral = pid->integral;
    float absolute_error = (error >= 0.0f) ? error : -error;
    if ((dt_seconds > 0.0f) &&
        ((pid->integral_error_limit <= 0.0f) ||
         (absolute_error <= pid->integral_error_limit))) {
        candidate_integral += error * dt_seconds;
    }

    float output = pid->kp * error +
                   pid->ki * candidate_integral +
                   pid->kd * derivative;

    if (output > pid->output_max) {
        output = pid->output_max;
        if (error < 0.0f) {
            pid->integral = candidate_integral;
        }
    } else if (output < pid->output_min) {
        output = pid->output_min;
        if (error > 0.0f) {
            pid->integral = candidate_integral;
        }
    } else {
        pid->integral = candidate_integral;
    }

    pid->previous_error = error;
    pid->initialized = 1U;
    return output;
}
