#include "encoder.h"

#include <stddef.h>

#include "ti_msp_dl_config.h"

#include "headerfile.h"

#define ENCODER_TELEMETRY_PERIOD_MS  50U
#define ENCODER_TELEMETRY_FRAME_SIZE 20U

volatile int32_t g_encoder_left_total;
volatile int32_t g_encoder_right_total;
volatile int32_t g_encoder_left_delta;
volatile int32_t g_encoder_right_delta;
volatile float g_left_motor_speed;
volatile float g_right_motor_speed;

static volatile int32_t g_left_interval;
static volatile int32_t g_right_interval;
static uint32_t g_telemetry_last_tx_ms;
static uint16_t g_telemetry_sequence;
static uint8_t g_telemetry_frame[ENCODER_TELEMETRY_FRAME_SIZE];
static uint8_t g_telemetry_tx_index;
static uint8_t g_telemetry_tx_pending;

static void telemetry_put_u32_le(uint8_t *destination, uint32_t value)
{
    destination[0] = (uint8_t)value;
    destination[1] = (uint8_t)(value >> 8U);
    destination[2] = (uint8_t)(value >> 16U);
    destination[3] = (uint8_t)(value >> 24U);
}

void Encoder_TelemetryReset(void)
{
    g_telemetry_last_tx_ms = millis();
    g_telemetry_sequence = 0U;
    g_telemetry_tx_index = 0U;
    g_telemetry_tx_pending = 0U;
}

void Encoder_TelemetryProcess(uint8_t task_id, uint32_t left_counts,
    uint32_t right_counts, uint32_t average_counts)
{
    while (g_telemetry_tx_pending &&
        DL_UART_Main_transmitDataCheck(UART_ENCODER_INST,
            g_telemetry_frame[g_telemetry_tx_index])) {
        g_telemetry_tx_index++;
        if (g_telemetry_tx_index >= ENCODER_TELEMETRY_FRAME_SIZE) {
            g_telemetry_tx_index = 0U;
            g_telemetry_tx_pending = 0U;
        }
    }

    if (g_telemetry_tx_pending) {
        return;
    }

    uint32_t now = millis();
    if ((now - g_telemetry_last_tx_ms) < ENCODER_TELEMETRY_PERIOD_MS) {
        return;
    }
    g_telemetry_last_tx_ms = now;

    g_telemetry_frame[0] = 0xAAU;
    g_telemetry_frame[1] = 0x55U;
    g_telemetry_frame[2] = 0x01U;
    g_telemetry_frame[3] = task_id;
    g_telemetry_frame[4] = (uint8_t)g_telemetry_sequence;
    g_telemetry_frame[5] = (uint8_t)(g_telemetry_sequence >> 8U);
    telemetry_put_u32_le(&g_telemetry_frame[6], left_counts);
    telemetry_put_u32_le(&g_telemetry_frame[10], right_counts);
    telemetry_put_u32_le(&g_telemetry_frame[14], average_counts);

    uint8_t checksum = 0U;
    for (uint8_t i = 2U; i <= 17U; i++) {
        checksum = (uint8_t)(checksum + g_telemetry_frame[i]);
    }
    g_telemetry_frame[18] = checksum;
    g_telemetry_frame[19] = 0x5AU;
    g_telemetry_sequence++;
    g_telemetry_tx_index = 0U;
    g_telemetry_tx_pending = 1U;
}

static void update_left_encoder(void)
{
    /* 左轮编码器 A 相：PA26；B 相 PA27 当前不参与速度大小计数。 */
    g_encoder_left_total++;
    g_left_interval++;
}

static void update_right_encoder(void)
{
    /* 右轮编码器 A 相：PB10；B 相 PB11 当前不参与速度大小计数。 */
    g_encoder_right_total++;
    g_right_interval++;
}

void Encoder_Init(void)
{
    g_encoder_left_total = 0;
    g_encoder_right_total = 0;
    g_encoder_left_delta = 0;
    g_encoder_right_delta = 0;
    g_left_motor_speed = 0.0f;
    g_right_motor_speed = 0.0f;
    g_left_interval = 0;
    g_right_interval = 0;

    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_LEFT_A_PORT,
        GPIO_ENCODER_LEFT_A_PIN);
    DL_GPIO_clearInterruptStatus(GPIO_ENCODER_RIGHT_A_PORT,
        GPIO_ENCODER_RIGHT_A_PIN);
    NVIC_EnableIRQ(GPIO_ENCODER_GPIOA_INT_IRQN);
    NVIC_EnableIRQ(GPIO_ENCODER_GPIOB_INT_IRQN);
}

void Encoder_GetAndResetDeltas(int32_t *left, int32_t *right)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    int32_t left_snapshot = g_left_interval;
    int32_t right_snapshot = g_right_interval;
    g_left_interval = 0;
    g_right_interval = 0;

    if (primask == 0U) {
        __enable_irq();
    }

    g_encoder_left_delta = left_snapshot;
    g_encoder_right_delta = right_snapshot;
    if (left != NULL) {
        *left = left_snapshot;
    }
    if (right != NULL) {
        *right = right_snapshot;
    }
}

void Encoder_SampleSpeeds(uint32_t elapsed_ms,
    int32_t *left_delta, int32_t *right_delta)
{
    int32_t left;
    int32_t right;
    Encoder_GetAndResetDeltas(&left, &right);

    if (elapsed_ms > 0U) {
        g_left_motor_speed =
            (float)left * 20.0f / (float)elapsed_ms;
        g_right_motor_speed =
            (float)right * 20.0f / (float)elapsed_ms;
    } else {
        g_left_motor_speed = 0.0f;
        g_right_motor_speed = 0.0f;
    }

    if (left_delta != NULL) {
        *left_delta = left;
    }
    if (right_delta != NULL) {
        *right_delta = right;
    }
}

void Encoder_GetTotals(int32_t *left, int32_t *right)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    int32_t left_snapshot = g_encoder_left_total;
    int32_t right_snapshot = g_encoder_right_total;

    if (primask == 0U) {
        __enable_irq();
    }

    if (left != NULL) {
        *left = left_snapshot;
    }
    if (right != NULL) {
        *right = right_snapshot;
    }
}

void GROUP1_IRQHandler(void)
{
    uint32_t left_status = DL_GPIO_getEnabledInterruptStatus(
        GPIO_ENCODER_LEFT_A_PORT, GPIO_ENCODER_LEFT_A_PIN);
    if (left_status != 0U) {
        DL_GPIO_clearInterruptStatus(GPIO_ENCODER_LEFT_A_PORT, left_status);
        /* PA26 -> 左轮计数。 */
        update_left_encoder();
    }

    uint32_t right_status = DL_GPIO_getEnabledInterruptStatus(
        GPIO_ENCODER_RIGHT_A_PORT, GPIO_ENCODER_RIGHT_A_PIN);
    if (right_status != 0U) {
        DL_GPIO_clearInterruptStatus(GPIO_ENCODER_RIGHT_A_PORT, right_status);
        /* PB10 -> 右轮计数。 */
        update_right_encoder();
    }
}
