#ifndef ENCODER_H
#define ENCODER_H

#include <stdint.h>

extern volatile int32_t g_encoder_left_total;
extern volatile int32_t g_encoder_right_total;
extern volatile int32_t g_encoder_left_delta;
extern volatile int32_t g_encoder_right_delta;
extern volatile float g_left_motor_speed;
extern volatile float g_right_motor_speed;

void Encoder_Init(void);
void Encoder_GetAndResetDeltas(int32_t *left, int32_t *right);
void Encoder_SampleSpeeds(uint32_t elapsed_ms,
    int32_t *left_delta, int32_t *right_delta);
void Encoder_GetTotals(int32_t *left, int32_t *right);

/* UART1/PB6 telemetry: 20-byte binary frame every 50 ms. */
void Encoder_TelemetryReset(void);
void Encoder_TelemetryProcess(uint8_t task_id, uint32_t left_counts,
    uint32_t right_counts, uint32_t average_counts);

#endif
