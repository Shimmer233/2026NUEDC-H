#ifndef MOTOR_SPEED_H
#define MOTOR_SPEED_H

#include <stdint.h>

#define MOTOR_SPEED_SAMPLE_PERIOD_MS    20U
#define MOTOR_SPEED_WINDOW_SIZE          5U

extern volatile float g_motor_left_speed;
extern volatile float g_motor_right_speed;

void MotorSpeed_Init(void);
void MotorSpeed_Reset(void);
void MotorSpeed_Process(void);
uint8_t MotorSpeed_Ready(void);

#endif
