#include "motor_speed.h"

#include "encoder.h"
#include "headerfile.h"

volatile float g_motor_left_speed;
volatile float g_motor_right_speed;

static uint32_t g_last_sample_ms;
static int32_t g_left_delta_window[MOTOR_SPEED_WINDOW_SIZE];
static int32_t g_right_delta_window[MOTOR_SPEED_WINDOW_SIZE];
static uint32_t g_elapsed_window[MOTOR_SPEED_WINDOW_SIZE];
static int32_t g_left_delta_sum;
static int32_t g_right_delta_sum;
static uint32_t g_elapsed_sum;
static uint8_t g_window_index;
static uint8_t g_window_count;

static void add_speed_sample(int32_t left_delta, int32_t right_delta,
    uint32_t elapsed_ms)
{
    if (g_window_count == MOTOR_SPEED_WINDOW_SIZE) {
        g_left_delta_sum -= g_left_delta_window[g_window_index];
        g_right_delta_sum -= g_right_delta_window[g_window_index];
        g_elapsed_sum -= g_elapsed_window[g_window_index];
    } else {
        g_window_count++;
    }

    g_left_delta_window[g_window_index] = left_delta;
    g_right_delta_window[g_window_index] = right_delta;
    g_elapsed_window[g_window_index] = elapsed_ms;
    g_left_delta_sum += left_delta;
    g_right_delta_sum += right_delta;
    g_elapsed_sum += elapsed_ms;

    g_window_index++;
    if (g_window_index >= MOTOR_SPEED_WINDOW_SIZE) {
        g_window_index = 0U;
    }
}

void MotorSpeed_Reset(void)
{
    int32_t unused_left;
    int32_t unused_right;
    Encoder_SampleSpeeds(0U, &unused_left, &unused_right);

    for (uint8_t i = 0U; i < MOTOR_SPEED_WINDOW_SIZE; i++) {
        g_left_delta_window[i] = 0;
        g_right_delta_window[i] = 0;
        g_elapsed_window[i] = 0U;
    }
    g_left_delta_sum = 0;
    g_right_delta_sum = 0;
    g_elapsed_sum = 0U;
    g_window_index = 0U;
    g_window_count = 0U;
    g_motor_left_speed = 0.0f;
    g_motor_right_speed = 0.0f;
    g_last_sample_ms = millis();
}

void MotorSpeed_Init(void)
{
    MotorSpeed_Reset();
}

void MotorSpeed_Process(void)
{
    uint32_t now = millis();
    uint32_t elapsed_ms = now - g_last_sample_ms;
    if (elapsed_ms < MOTOR_SPEED_SAMPLE_PERIOD_MS) {
        return;
    }
    g_last_sample_ms = now;

    int32_t left_delta;
    int32_t right_delta;
    Encoder_SampleSpeeds(elapsed_ms, &left_delta, &right_delta);
    add_speed_sample(left_delta, right_delta, elapsed_ms);

    g_motor_left_speed = (float)(g_left_delta_sum * ENCODER_DIRECTION_L) *
        (float)MOTOR_SPEED_SAMPLE_PERIOD_MS / (float)g_elapsed_sum;
    g_motor_right_speed = (float)(g_right_delta_sum * ENCODER_DIRECTION_R) *
        (float)MOTOR_SPEED_SAMPLE_PERIOD_MS / (float)g_elapsed_sum;
}

uint8_t MotorSpeed_Ready(void)
{
    return (g_window_count >= MOTOR_SPEED_WINDOW_SIZE) ? 1U : 0U;
}
