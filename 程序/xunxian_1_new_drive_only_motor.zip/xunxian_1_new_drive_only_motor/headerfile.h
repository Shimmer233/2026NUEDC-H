#ifndef HEADERFILE_H
#define HEADERFILE_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

extern volatile int16_t right_speed;
extern volatile int16_t left_speed;
extern volatile uint8_t sensor_d1;
extern volatile uint8_t sensor_d2;
extern volatile uint8_t sensor_d3;
extern volatile uint8_t sensor_d4;
extern volatile uint8_t sensor_d5;
extern volatile uint8_t sensor_d6;
extern volatile uint8_t sensor_d7;
extern volatile uint8_t sensor_d8;
extern volatile uint32_t completed_lap_count;
extern volatile uint32_t g_b0_press_count;
extern volatile uint32_t g_b1_press_count;
extern volatile uint8_t g_b0_gpio_level;
extern volatile uint8_t g_b1_gpio_level;
extern volatile uint32_t g_task_three_press_count;
extern volatile uint8_t g_task_three_gpio_level;
extern volatile uint32_t g_task_four_press_count;
extern volatile uint8_t g_task_four_gpio_level;
extern volatile float g_g356_absolute_yaw_degrees;
extern volatile uint8_t g_parking_line_detected;
extern volatile uint8_t g_lap_finish_armed;
extern volatile float g_task_one_speed_scale;
extern volatile float g_task_two_speed_scale;
extern volatile uint32_t g_task_two_left_distance_counts;
extern volatile uint32_t g_task_two_right_distance_counts;
extern volatile uint32_t g_task_two_distance_counts;
extern volatile uint32_t g_task_three_left_distance_counts;
extern volatile uint32_t g_task_three_right_distance_counts;
extern volatile uint32_t g_task_three_distance_counts;
extern volatile uint32_t g_task_four_left_distance_counts;
extern volatile uint32_t g_task_four_right_distance_counts;
extern volatile uint32_t g_task_four_distance_counts;
extern volatile float g_task_one_left_smoothed_target;
extern volatile float g_task_one_right_smoothed_target;
extern volatile uint8_t g_task_one_stability_active;
extern volatile uint32_t g_task_one_left_distance_counts;
extern volatile uint32_t g_task_one_right_distance_counts;
extern volatile uint32_t g_task_one_distance_counts;
extern volatile uint8_t g_track_gyro_mode;
extern volatile float g_track_filtered_error;
extern volatile float g_track_target_yaw_rate;
extern volatile float g_track_curve_yaw_rate;
extern volatile float g_track_target_heading;
extern volatile float g_track_heading_error;
extern volatile float g_track_measured_gyro_z;
extern volatile float g_track_final_adjust;
extern volatile float g_track_left_target_float;
extern volatile float g_track_right_target_float;
extern volatile uint32_t g_track_gyro_data_age_ms;

#define SENSOR_LINE_LEVEL 1

/* ---- line following params ---- */
#define TRACK_BASE_SPEED       20
#define TASK_TWO_BASE_SPEED    30
#define TRACK_SEARCH_SPEED     14
#define TRACK_SEARCH_ADJUST     3
#define TRACK_KP                3.5f
#define TRACK_MAX_ADJUST       15.0f
#define TRACK_ERROR_FILTER_TAU_MS       100.0f
#define TRACK_CURVE_FILTER_TAU_MS        50.0f
#define TRACK_YAW_RATE_PER_ERROR         22.0f
#define TRACK_CURVE_YAW_RATE_KP          12.0f
#define TRACK_CURVE_YAW_RATE_KI          55.0f
#define TRACK_CURVE_YAW_RATE_MAX         90.0f
#define TRACK_CURVE_GYRO_LEARN_TAU_MS   250.0f
#define TRACK_CURVE_LEARN_MIN_ERROR       0.20f
#define TRACK_CURVE_LEARN_MIN_RATE        5.0f
#define TRACK_MAX_YAW_RATE              110.0f
#define TRACK_SEARCH_YAW_RATE            35.0f
#define TRACK_MAX_HEADING_ERROR          25.0f
#define TRACK_HEADING_KP                  0.35f
#define TRACK_YAW_RATE_KD                 0.04f
#define TRACK_CURVE_HEADING_KP            0.28f
#define TRACK_CURVE_YAW_RATE_KD           0.08f
#define TRACK_HEADING_MAX_ADJUST         10.0f
#define TRACK_ADJUST_SLEW_PER_SECOND     30.0f
#define TRACK_CURVE_ADJUST_SLEW_PER_SECOND 20.0f
#define TRACK_ADJUST_SPEED_FRACTION       0.65f
#define TRACK_GYRO_STALE_TIMEOUT_MS      150U
#define TRACK_GYRO_VALID_FRAMES            3U
#define TRACK_GYRO_FALLBACK_SPEED         22.0f
#define TRACK_GYRO_Z_DIRECTION             1.0f
#define TRACK_FORWARD_ACCEL_PER_SECOND     20.0f
#define TRACK_FORWARD_DECEL_PER_SECOND     40.0f

/* ---- encoder speed measurement ---- */
/* 左轮：电机 PB8/PB9，编码器 PA26/PA27。 */
/* 右轮：电机 PB12/PB13，编码器 PB10/PB11。 */
#define ENCODER_DIRECTION_L           1
#define ENCODER_DIRECTION_R           1
#define MOTOR_SPEED_TEST_TARGET_L  20.0f  /* counts per 20 ms */
#define MOTOR_SPEED_TEST_TARGET_R  20.0f  /* counts per 20 ms */
#define MOTOR_SPEED_TEST_PWM_L        400
#define MOTOR_SPEED_TEST_PWM_R        400

/* ---- left wheel speed PID: PA26/PA27 feedback -> PB8/PB9 motor ---- */
#define LEFT_PID_KP                 15.0f
#define LEFT_PID_KI                 10.0f
#define LEFT_PID_KD                  0.0f
#define LEFT_PID_PERIOD_MS           20U
#define PID_INTEGRAL_ERROR_LIMIT     5.0f

/* ---- right wheel speed PID: PB10/PB11 feedback -> PB12/PB13 motor ---- */
#define RIGHT_PID_KP                15.0f
#define RIGHT_PID_KI                10.0f
#define RIGHT_PID_KD                 0.0f
#define RIGHT_PID_PERIOD_MS          20U

/* ---- lap control ---- */
#define PARKING_LINE_CLEAR_CYCLES  3U
#define PARKING_LINE_CONFIRM_CYCLES 1U
#define TASK_FOUR_SOFT_START_DURATION_MS 5000U
#define TASK_ONE_STEERING_SCALE          0.75f
#define TASK_ONE_TARGET_ACCEL_RATE      20.0f
#define TASK_ONE_TARGET_DECEL_RATE      30.0f
#define TASK_ONE_STABILITY_YAW_DEG      190.0f
#define TASK_ONE_STABLE_STEERING_SCALE   0.65f
#define TASK_ONE_STABLE_TARGET_RATE       8.0f
#define TASK_ONE_DECEL_STEERING_FRACTION  0.60f
#define TASK_ONE_DECEL_DURATION_MS 4000U

/* ---- motor ---- */
#define MOTOR_PWM_MAX        2000
#define MOTOR_DEAD_ZONE_L       0
#define MOTOR_DEAD_ZONE_R       0
#define MOTOR_DIRECTION_L      (-1)  /* 左轮正速度对应当前车体的前进方向 */
#define MOTOR_DIRECTION_R      (-1)  /* 右轮正速度对应当前车体的前进方向 */
#define TASK_TWO_START_MIN_SPEED             6
#define TASK_TWO_MID_SPEED                18.0f
#define TASK_TWO_FIRST_ACCEL_DURATION_MS  4000U
#define TASK_TWO_SECOND_ACCEL_DURATION_MS 3000U
#define TASK_TWO_CURVE_SPEED             24.0f
#define TASK_TWO_DECEL_DURATION_MS      8000U
#define TASK_TWO_OLED_FREEZE_COUNTS     6000U
#define TASK_TWO_STEERING_SCALE            0.60f

/* ---- task three: task-four profile with stop-line braking ---- */
#define TASK_THREE_CRUISE_SPEED             30.0f
#define TASK_THREE_START_SPEED               6.0f
#define TASK_THREE_CURVE_SPEED              24.0f
#define TASK_THREE_CURVE_FULL_ERROR           1.0f
#define TASK_THREE_CURVE_FULL_YAW_RATE       45.0f
#define TASK_THREE_SPEED_ACCEL_PER_SECOND     8.0f
#define TASK_THREE_SPEED_DECEL_PER_SECOND     4.0f
#define TASK_THREE_SOFT_START_DURATION_MS  5000U
#define TASK_THREE_DECEL_START_COUNTS      18500U
#define TASK_THREE_STOP_LINE_ARM_COUNTS    20000U
#define TASK_THREE_APPROACH_SPEED             15.0f
#define TASK_THREE_GYRO_FALLBACK_SPEED       28.0f
#define TASK_THREE_STEERING_SCALE             0.85f
#define TASK_THREE_MAX_ADJUST                 8.0f

/* ---- task four: 24Y-Hti-style one-lap line following ---- */
#define TASK_FOUR_CRUISE_SPEED             30.0f
#define TASK_FOUR_START_SPEED               6.0f
#define TASK_FOUR_CURVE_SPEED              24.0f
#define TASK_FOUR_CURVE_FULL_ERROR           1.0f
#define TASK_FOUR_CURVE_FULL_YAW_RATE       45.0f
#define TASK_FOUR_SPEED_ACCEL_PER_SECOND     8.0f
#define TASK_FOUR_SPEED_DECEL_PER_SECOND     4.0f
#define TASK_FOUR_OLED_FREEZE_COUNTS    20800U
#define TASK_FOUR_DISTANCE_COUNTS        21500U
#define TASK_FOUR_STOP_DECEL_DURATION_MS 5000U
#define TASK_FOUR_STEERING_SCALE            0.85f
#define TASK_FOUR_MAX_ADJUST                8.0f
#define TASK_FOUR_STOPPED_SPEED             1.5f
#define TASK_FOUR_STOPPED_STABLE_SAMPLES    5U

/* ---- function declarations ---- */
void  delay_ms(uint32_t ms);
void  delay_cycles(uint32_t cycles);
uint32_t millis(void);

uint8_t lap_select_key_scan(void);
uint8_t start_key_scan(void);
uint8_t task_three_key_scan(void);
uint8_t task_four_key_scan(void);

void  set_Lspeed(int32_t speed);
void  set_Rspeed(int32_t speed);
void  motor_active_brake(void);

void    update_sensors(void);
void    track(void);
void    track_reset(void);
void    track_heading_update(uint8_t inner_sensors_only,
            uint8_t search_when_lost, uint8_t retain_curve_rate,
            float forward_speed,
            float steering_scale, float maximum_adjust,
            uint32_t elapsed_ms, int16_t *left_target,
            int16_t *right_target);
void    track_heading_update_with_fallback(uint8_t inner_sensors_only,
            uint8_t search_when_lost, uint8_t retain_curve_rate,
            float forward_speed, float fallback_speed,
            float steering_scale, float maximum_adjust,
            uint32_t elapsed_ms, int16_t *left_target,
            int16_t *right_target);
uint8_t check_cross_right(void);
uint8_t check_cross_left(void);
uint8_t check_parking_line(void);

#endif
