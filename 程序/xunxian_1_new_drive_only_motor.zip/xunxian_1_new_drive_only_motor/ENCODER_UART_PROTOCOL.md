# Encoder UART telemetry protocol

## Electrical connection

| MSPM0G3507 signal | MotherBoard pin | Receiving MCU |
| --- | --- | --- |
| PB6 / UART1 TX | P15-1 | UART RX |
| PB7 / UART1 RX | P15-3 | UART TX, optional |
| GND | Any board GND | GND |

Both sides must use 3.3 V logic and share GND. For receive-only operation on
the second MCU, PB6 and GND are sufficient. Do not drive either UART pin with
5 V logic.

## UART settings

- Baud rate: 115200
- Data bits: 8
- Parity: none
- Stop bits: 1
- Flow control: none
- Bit order: UART standard, least-significant bit first
- Transmission period: 50 ms (20 frames per second)

Telemetry is sent only while a driving task is active. All multi-byte values
use little-endian byte order. Encoder counts are relative to the start of the
current task and count both edges of each encoder A channel.

## Frame layout

Each frame is exactly 20 bytes.

| Offset | Size | Field | Value or meaning |
| ---: | ---: | --- | --- |
| 0 | 1 | Header 1 | `0xAA` |
| 1 | 1 | Header 2 | `0x55` |
| 2 | 1 | Protocol version | `0x01` |
| 3 | 1 | Task ID | `1`, `2`, `3`, or `4` |
| 4 | 2 | Sequence | Unsigned 16-bit, little-endian |
| 6 | 4 | Left count | Unsigned 32-bit, little-endian |
| 10 | 4 | Right count | Unsigned 32-bit, little-endian |
| 14 | 4 | Average count | `(left + right) / 2`, little-endian |
| 18 | 1 | Checksum | Sum of bytes 2 through 17, modulo 256 |
| 19 | 1 | Tail | `0x5A` |

The sequence starts at zero for each task and wraps naturally after 65535.

## Receiver validation

1. Search the byte stream for `0xAA 0x55`.
2. Buffer 20 bytes.
3. Require byte 2 to equal `0x01` and byte 19 to equal `0x5A`.
4. Add bytes 2 through 17 using an 8-bit accumulator and compare with byte
   18.
5. Decode the 16-bit and 32-bit fields as little-endian values.
6. If validation fails, discard one byte and resume searching for the header.

Example little-endian decoder:

```c
static uint32_t read_u32_le(const uint8_t *data)
{
    return (uint32_t)data[0] |
        ((uint32_t)data[1] << 8U) |
        ((uint32_t)data[2] << 16U) |
        ((uint32_t)data[3] << 24U);
}
```
