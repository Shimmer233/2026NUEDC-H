#include "g356.h"

#include <stddef.h>
#include <string.h>

#include "ti_msp_dl_config.h"

#define G356_UART_INT_MASK                                                   \
    (DL_UART_MAIN_INTERRUPT_RX | DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR |   \
        DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |                               \
        DL_UART_MAIN_INTERRUPT_BREAK_ERROR |                                 \
        DL_UART_MAIN_INTERRUPT_PARITY_ERROR |                                \
        DL_UART_MAIN_INTERRUPT_FRAMING_ERROR)

volatile G356_Data_t g_g356_latest_data;
volatile uint32_t g_g356_valid_count;
volatile uint32_t g_g356_invalid_count;
volatile uint32_t g_g356_uart_error_count;
volatile bool g_g356_new_frame;
volatile float g_g356_absolute_yaw_degrees;

static uint8_t g_g356_frame[G356_FRAME_SIZE];
static uint8_t g_g356_frame_index;
static uint8_t g_g356_parser_state;
static uint8_t g_g356_yaw_initialized;
static float g_g356_previous_yaw_degrees;
static float g_g356_recorded_yaw_degrees;

static int16_t g356_parse_int16(const uint8_t *buf)
{
    return (int16_t)((uint16_t)buf[0] | ((uint16_t)buf[1] << 8U));
}

static float g356_parse_float(const uint8_t *buf)
{
    float value;

    /* memcpy avoids unaligned float accesses on Cortex-M0+. */
    memcpy(&value, buf, sizeof(value));
    return value;
}

static bool g356_validate_frame(const uint8_t *frame)
{
    uint8_t checksum = 0U;

    if ((frame[0] != 0xAAU) || (frame[1] != 0x55U) ||
        (frame[2] != 0x02U) || (frame[3] != 0x36U) ||
        (frame[G356_FRAME_SIZE - 1U] != 0x5AU)) {
        return false;
    }

    for (uint32_t i = 2U; i <= (G356_FRAME_SIZE - 3U); i++) {
        checksum = (uint8_t)(checksum + frame[i]);
    }

    return checksum == frame[G356_FRAME_SIZE - 2U];
}

static void g356_parse_data(const uint8_t *buf, G356_Data_t *data)
{
    data->accel_x = (float)g356_parse_int16(&buf[4]) *
                    (1.0f / G356_ACCEL_LSB_PER_G);
    data->accel_y = (float)g356_parse_int16(&buf[6]) *
                    (1.0f / G356_ACCEL_LSB_PER_G);
    data->accel_z = (float)g356_parse_int16(&buf[8]) *
                    (1.0f / G356_ACCEL_LSB_PER_G);

    data->gyro_x = (float)g356_parse_int16(&buf[10]) *
                   (1.0f / G356_GYRO_LSB_PER_DPS);
    data->gyro_y = (float)g356_parse_int16(&buf[12]) *
                   (1.0f / G356_GYRO_LSB_PER_DPS);
    data->gyro_z = (float)g356_parse_int16(&buf[14]) *
                   (1.0f / G356_GYRO_LSB_PER_DPS);

    data->roll = g356_parse_float(&buf[16]);
    data->pitch = g356_parse_float(&buf[20]);
    data->yaw = g356_parse_float(&buf[24]);
    data->temp = (float)g356_parse_int16(&buf[28]) *
                 (1.0f / G356_TEMP_LSB_PER_DEGC);

    data->raw_accel_x = g356_parse_float(&buf[30]);
    data->raw_accel_y = g356_parse_float(&buf[34]);
    data->raw_accel_z = g356_parse_float(&buf[38]);
    data->raw_gyro_x = g356_parse_float(&buf[42]);
    data->raw_gyro_y = g356_parse_float(&buf[46]);
    data->raw_gyro_z = g356_parse_float(&buf[50]);
}

static void g356_publish_frame(void)
{
    G356_Data_t parsed;

    g356_parse_data(g_g356_frame, &parsed);
    if (parsed.yaw == parsed.yaw) {
        if (!g_g356_yaw_initialized) {
            g_g356_previous_yaw_degrees = parsed.yaw;
            g_g356_yaw_initialized = 1U;
        } else {
            float delta = parsed.yaw - g_g356_previous_yaw_degrees;
            while (delta > 180.0f) {
                delta -= 360.0f;
            }
            while (delta < -180.0f) {
                delta += 360.0f;
            }
            g_g356_previous_yaw_degrees = parsed.yaw;
            g_g356_recorded_yaw_degrees += delta;
            g_g356_absolute_yaw_degrees =
                (g_g356_recorded_yaw_degrees >= 0.0f) ?
                g_g356_recorded_yaw_degrees :
                -g_g356_recorded_yaw_degrees;
        }
    }
    g_g356_latest_data = parsed;
    g_g356_valid_count++;
    g_g356_new_frame = true;
}

static void g356_feed_byte(uint8_t byte)
{
    switch (g_g356_parser_state) {
    case 0U:
        if (byte == 0xAAU) {
            g_g356_frame[0] = byte;
            g_g356_parser_state = 1U;
        }
        break;

    case 1U:
        if (byte == 0x55U) {
            g_g356_frame[1] = byte;
            g_g356_frame_index = 2U;
            g_g356_parser_state = 2U;
        } else if (byte != 0xAAU) {
            g_g356_parser_state = 0U;
        }
        break;

    case 2U:
        g_g356_frame[g_g356_frame_index++] = byte;
        if (g_g356_frame_index >= G356_FRAME_SIZE) {
            g_g356_parser_state = 0U;
            if (g356_validate_frame(g_g356_frame)) {
                g356_publish_frame();
            } else {
                g_g356_invalid_count++;
            }
        }
        break;

    default:
        g_g356_parser_state = 0U;
        break;
    }
}

static void g356_drain_rx_fifo(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(UART_G356_INST)) {
        uint32_t rx_data = UART_G356_INST->RXDATA;
        uint32_t errors = rx_data &
            (DL_UART_ERROR_OVERRUN | DL_UART_ERROR_BREAK |
                DL_UART_ERROR_PARITY | DL_UART_ERROR_FRAMING);

        if (errors != 0U) {
            g_g356_uart_error_count++;
        }
        g356_feed_byte((uint8_t)(rx_data & UART_RXDATA_DATA_MASK));
    }
}

void G356_UART_Init(void)
{
    g_g356_frame_index = 0U;
    g_g356_parser_state = 0U;
    g_g356_valid_count = 0U;
    g_g356_invalid_count = 0U;
    g_g356_uart_error_count = 0U;
    g_g356_new_frame = false;
    g_g356_yaw_initialized = 0U;
    g_g356_previous_yaw_degrees = 0.0f;
    g_g356_recorded_yaw_degrees = 0.0f;
    g_g356_absolute_yaw_degrees = 0.0f;
    memset((void *)&g_g356_latest_data, 0, sizeof(g_g356_latest_data));

    DL_UART_Main_disableInterrupt(UART_G356_INST, G356_UART_INT_MASK);
    NVIC_DisableIRQ(UART_G356_INST_INT_IRQN);
    DL_UART_Main_setRXFIFOThreshold(
        UART_G356_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setRXInterruptTimeout(UART_G356_INST, 1U);
    DL_UART_Main_clearInterruptStatus(UART_G356_INST, G356_UART_INT_MASK);
    g356_drain_rx_fifo();
    DL_UART_Main_enableInterrupt(UART_G356_INST, G356_UART_INT_MASK);
    NVIC_ClearPendingIRQ(UART_G356_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_G356_INST_INT_IRQN);
}

bool G356_UART_GetLatest(G356_Data_t *data, uint32_t *frame_count)
{
    uint32_t primask;

    if (data == NULL) {
        return false;
    }

    primask = __get_PRIMASK();
    __disable_irq();
    if (g_g356_valid_count == 0U) {
        if (primask == 0U) {
            __enable_irq();
        }
        return false;
    }

    *data = g_g356_latest_data;
    if (frame_count != NULL) {
        *frame_count = g_g356_valid_count;
    }
    g_g356_new_frame = false;
    if (primask == 0U) {
        __enable_irq();
    }
    return true;
}

void G356_Yaw_StartRecording(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    g_g356_recorded_yaw_degrees = 0.0f;
    g_g356_absolute_yaw_degrees = 0.0f;

    if (primask == 0U) {
        __enable_irq();
    }
}

float G356_Yaw_GetRecorded(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    float recorded = g_g356_recorded_yaw_degrees;
    if (primask == 0U) {
        __enable_irq();
    }
    return recorded;
}

void G356_UART_SendByte(uint8_t byte)
{
    DL_UART_Main_transmitDataBlocking(UART_G356_INST, byte);
}

void G356_UART_Send(const uint8_t *data, uint16_t length)
{
    if ((data == NULL) && (length != 0U)) {
        return;
    }

    for (uint16_t i = 0U; i < length; i++) {
        G356_UART_SendByte(data[i]);
    }
}

uint8_t G356_UART_ReadByteBlocking(void)
{
    return DL_UART_Main_receiveDataBlocking(UART_G356_INST);
}

bool G356_UART_TryReadByte(uint8_t *byte)
{
    if (byte == NULL) {
        return false;
    }
    return DL_UART_Main_receiveDataCheck(UART_G356_INST, byte);
}

void UART_G356_INST_IRQHandler(void)
{
    while (1) {
        switch (DL_UART_Main_getPendingInterrupt(UART_G356_INST)) {
        case DL_UART_MAIN_IIDX_RX:
        case DL_UART_MAIN_IIDX_RX_TIMEOUT_ERROR:
            g356_drain_rx_fifo();
            DL_UART_Main_clearInterruptStatus(UART_G356_INST,
                DL_UART_MAIN_INTERRUPT_RX |
                    DL_UART_MAIN_INTERRUPT_RX_TIMEOUT_ERROR);
            break;

        case DL_UART_MAIN_IIDX_OVERRUN_ERROR:
        case DL_UART_MAIN_IIDX_BREAK_ERROR:
        case DL_UART_MAIN_IIDX_PARITY_ERROR:
        case DL_UART_MAIN_IIDX_FRAMING_ERROR:
            g356_drain_rx_fifo();
            DL_UART_Main_clearInterruptStatus(UART_G356_INST,
                DL_UART_MAIN_INTERRUPT_OVERRUN_ERROR |
                    DL_UART_MAIN_INTERRUPT_BREAK_ERROR |
                    DL_UART_MAIN_INTERRUPT_PARITY_ERROR |
                    DL_UART_MAIN_INTERRUPT_FRAMING_ERROR);
            break;

        default:
            return;
        }
    }
}
