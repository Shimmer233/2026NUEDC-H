#ifndef G356_H
#define G356_H

#include <stdbool.h>
#include <stdint.h>

#define G356_FRAME_SIZE              56U
#define G356_ACCEL_LSB_PER_G         2048.0f
#define G356_GYRO_LSB_PER_DPS        8.2f
#define G356_TEMP_LSB_PER_DEGC       100.0f

typedef struct {
    float accel_x;
    float accel_y;
    float accel_z;
    float gyro_x;
    float gyro_y;
    float gyro_z;
    float roll;
    float pitch;
    float yaw;
    float temp;
    float raw_accel_x;
    float raw_accel_y;
    float raw_accel_z;
    float raw_gyro_x;
    float raw_gyro_y;
    float raw_gyro_z;
} G356_Data_t;

/* These variables are intentionally visible for inspection in the CCS debugger. */
extern volatile G356_Data_t g_g356_latest_data;
extern volatile uint32_t g_g356_valid_count;
extern volatile uint32_t g_g356_invalid_count;
extern volatile uint32_t g_g356_uart_error_count;
extern volatile bool g_g356_new_frame;
extern volatile float g_g356_absolute_yaw_degrees;

/* Starts interrupt-driven G356 reception on UART_G356 (115200, 8N1). */
void G356_UART_Init(void);

/* Copies one coherent sample. Returns false until the first valid frame arrives. */
bool G356_UART_GetLatest(G356_Data_t *data, uint32_t *frame_count);

/* Starts unlimited yaw recording from zero when a driving task starts. */
void G356_Yaw_StartRecording(void);
float G356_Yaw_GetRecorded(void);

void G356_UART_SendByte(uint8_t byte);
void G356_UART_Send(const uint8_t *data, uint16_t length);
uint8_t G356_UART_ReadByteBlocking(void);
bool G356_UART_TryReadByte(uint8_t *byte);

#endif
