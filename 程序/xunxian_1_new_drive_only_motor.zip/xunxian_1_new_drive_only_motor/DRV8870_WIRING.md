# Car 2 motor, encoder, and VOFA wiring

Only channels A and B of the four-channel board are used.

## SeekFree MSPM0G3507 MotherBoard V1.0

The current firmware is configured for the MotherBoard pushbuttons and avoids
the board's fixed PA22 battery-voltage divider.

### G356-assisted line following

All four tasks use the G356 yaw and Z-axis angular rate in a cascaded line and
heading controller. If G356 data is unavailable or stale for more than 150 ms,
the firmware limits forward speed to 22 and continues with smoothed line-sensor
control. It returns to heading control after three consecutive fresh frames.

### On-board buttons

| MotherBoard button | MCU pin | Firmware action |
| --- | --- | --- |
| S5 / B1 | PB1 | Start when at least one lap is selected |
| S4 / B0 | PB0 | Add one lap per press |

The current multi-task firmware assigns the start inputs as follows:

| Input | MCU pin | Task |
| --- | --- | --- |
| S5 / B1 | PB1 | Task 1, continuous basic line following; OLED shows average encoder counts |
| S4 / B0 | PB0 | Task 2, accelerates from 6 to 18 in 4 s and then to 30 in 3 s, with dynamic curve speed 24; at 6000 counts freeze OLED and decelerate for 8 s |
| External active-low key | PA31 | Task 3, task-4-style soft-start and dynamic-speed line following; starts checking for the stop line at 20000 average encoder counts and brakes immediately when detected |
| External active-low key | PA30 | Task 4, 5 s soft start from 6; dynamic speed 30 on straights and 24 in curves; freezes OLED at 20800 counts and decelerates for 5 s at 21500 counts |

Connect each external key between its MCU pin and GND. PA30 and PA31 use
internal pull-ups and 20 ms software debounce. Tasks 2 and 4 require at least
one of D2-D7 to see the line before they start; G356 data may become valid
after a task starts.

Both buttons are active low and already have pull-ups and hardware debounce
capacitors on the MotherBoard. No external button wiring is required.

### Motor and encoder headers

| MotherBoard header | MCU pin | External connection |
| --- | --- | --- |
| P16-2 | PB8 | Driver AIN1 |
| P16-6 | PB9 | Driver AIN2 |
| P16-1 | PB12 | Driver BIN1 |
| P16-5 | PB13 | Driver BIN2 |
| P16-3 or P16-4 | GND | Driver logic GND |
| P17-5 | PA26 | Left encoder A |
| P17-6 | PA27 | Left encoder B |
| P17-1 | PB10 | Right encoder A |
| P17-2 | PB11 | Right encoder B |
| P17-3 or P17-4 | GND | Encoder GND |

P17 does not provide encoder power. Supply the encoders from a separate 3.3 V
pin and keep every external digital output 3.3 V compatible.

### Eight digital line sensors

With the car facing forward, connect the sensors from left to right as D1
through D8. The firmware treats a high input as active.

| Sensor | MCU pin | MotherBoard access point |
| --- | --- | --- |
| D1, far left | PB17 | P19-6 |
| D2 | PB18 | P20-6 |
| D3 | PA12 | P9-2 |
| D4 | PA9 | P9-4 |
| D5 | PA7 | P9-6 |
| D6 | PA15 | P9-8 |
| D7 | PA8 | P9-10 |
| D8, far right | PA13 | P9-12 |

P6/P8/P10/P12 pins 1 or 2 provide the board's regulated 3.3 V camera rail,
and pins 5 or 6 are GND. Do not drive a GPIO with a 5 V sensor output.

PA8 and PA9 are now line-sensor inputs. Encoder telemetry uses UART1 on the
MotherBoard P15 connector: PB6/P15-1 is MCU TX and PB7/P15-3 is MCU RX.
For one-way telemetry, connect PB6 to the receiving MCU RX and share GND;
PB7 may remain disconnected.

### G356 UART wiring

| G356 | MotherBoard connection |
| --- | --- |
| VCC | 3.3 V |
| GND | GND |
| TX | PA1 / MCU UART0 RX |
| RX | PA0 / MCU UART0 TX |

UART0 is configured for 115200 baud, 8 data bits, no parity, and one stop bit.
The installed sensor orientation must report decreasing yaw and gyro Z while
the vehicle turns left. If gyro Z has the opposite sign, change only
`TRACK_GYRO_Z_DIRECTION`.

## MSPM0 to driver board

| MSPM0G3507 | DRV8870 board | Purpose |
| --- | --- | --- |
| PB8 (TIMA0 CCP0) | AIN1 | Left motor input 1 PWM |
| PB9 (TIMA0 CCP1) | AIN2 | Left motor input 2 PWM |
| PB12 (TIMA0 CCP2) | BIN1 | Right motor input 1 PWM |
| PB13 (TIMA0 CCP3) | BIN2 | Right motor input 2 PWM |
| GND | GND | Required common ground |

Connect the board's motor A output to the left motor and motor B output to the
right motor. Channels C and D are unused and their control pins may remain
unconnected.

The current chassis has both motors mounted with reversed electrical polarity,
so `MOTOR_DIRECTION_L` and `MOTOR_DIRECTION_R` are both set to `-1`. Positive
logical speed still means vehicle forward.

## Power

- Supply the driver board through its motor-power input with 7-35 V, selected
  for the connected motors.
- Do not connect the motor-power input to an MSPM0 GPIO or 3.3 V rail.
- The MSPM0 and driver board must share GND.
- Do not tie the board's 3.3 V or 5 V output to the LaunchPad supply unless the
entire power arrangement has been checked separately.

## Encoders

| MSPM0G3507 | External signal | Purpose |
| --- | --- | --- |
| PA26 | Left encoder A | GPIO interrupt input, internal pull-up enabled |
| PA27 | Left encoder B | GPIO input; currently unused by the firmware |
| PB10 | Right encoder A | GPIO interrupt input, internal pull-up enabled |
| PB11 | Right encoder B | GPIO input; currently unused by the firmware |
| GND | Encoder GND | Required common ground |

The encoder output voltage must be 3.3 V compatible. The current firmware
counts both edges of each A channel and does not infer direction from B.

## Control behavior

The board exposes the DRV8870 IN1/IN2 pins directly; there is no separate DIR
input on the board. This project follows the vendor's two-PWM control method so
the PWM off-time uses active braking in both directions:

| Command | IN1 | IN2 | DRV8870 state |
| --- | --- | --- | --- |
| Positive speed | 1 | Inverted duty PWM | Forward / brake PWM |
| Negative speed | Inverted duty PWM | 1 | Reverse / brake PWM |
| Zero speed | 0 | 0 | Coast, then sleep |
| Active brake | 1 | 1 | Low-side brake |

During either direction's drive pulse the inputs are `10` or `01`. During every
PWM off-time both inputs are `11`, so both directions use active braking rather
than coasting. PWM frequency is 20 kHz. If a positive command turns a wheel
backward, swap that motor's two output wires.
