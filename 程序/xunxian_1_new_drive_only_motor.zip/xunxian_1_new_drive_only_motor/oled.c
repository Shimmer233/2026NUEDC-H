#include "oled.h"

#include <stdbool.h>

#include "headerfile.h"

#define SSD1315_I2C_ADDRESS          0x3CU
#define SSD1315_WIDTH                128U
#define SSD1315_PAGE_COUNT             8U
#define SSD1315_PACKET_SIZE             8U
#define SSD1315_DATA_BYTES_PER_TX       7U
#define SSD1315_TIME_X                 32U
#define SSD1315_TIME_PAGE               3U
#define SSD1315_COUNT_X                24U
#define SSD1315_COUNT_PAGE              3U
#define SSD1315_COUNT_DIGITS           10U
#define SSD1315_COUNT_REFRESH_MS        50U
#define SSD1315_TIME_REFRESH_MS         50U
#define OLED_I2C_DELAY_CYCLES          40U
#define OLED_SDA_PORT                GPIOB
#define OLED_SDA_PIN        DL_GPIO_PIN_15
#define OLED_SDA_IOMUX       IOMUX_PINCM32
#define OLED_SCL_PORT                GPIOB
#define OLED_SCL_PIN        DL_GPIO_PIN_16
#define OLED_SCL_IOMUX       IOMUX_PINCM33

volatile uint8_t g_oled_ready;
volatile uint32_t g_oled_elapsed_seconds;
volatile uint32_t g_oled_i2c_error_count;

static uint32_t g_ssd1315_clock_start_ms;
static uint32_t g_ssd1315_frozen_elapsed_ms;
static uint32_t g_ssd1315_last_displayed_hundredths;
static uint32_t g_ssd1315_last_time_refresh_ms;
static uint32_t g_ssd1315_encoder_count;
static uint32_t g_ssd1315_last_displayed_encoder_count;
static uint32_t g_ssd1315_last_count_refresh_ms;
static uint8_t g_ssd1315_clock_running;
static uint8_t g_ssd1315_show_encoder_count;

/* 8x16 glyphs for 0-9, ':' and '.'. */
static const uint8_t g_time_glyphs[12][16] = {
    {0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,
     0x00,0x0F,0x10,0x20,0x20,0x10,0x0F,0x00},
    {0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,
     0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00},
    {0x00,0x70,0x08,0x08,0x08,0x88,0x70,0x00,
     0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00},
    {0x00,0x30,0x08,0x88,0x88,0x48,0x30,0x00,
     0x00,0x18,0x20,0x20,0x20,0x11,0x0E,0x00},
    {0x00,0x00,0xC0,0x20,0x10,0xF8,0x00,0x00,
     0x00,0x07,0x04,0x24,0x24,0x3F,0x24,0x00},
    {0x00,0xF8,0x08,0x88,0x88,0x08,0x08,0x00,
     0x00,0x19,0x21,0x20,0x20,0x11,0x0E,0x00},
    {0x00,0xE0,0x10,0x88,0x88,0x18,0x00,0x00,
     0x00,0x0F,0x11,0x20,0x20,0x11,0x0E,0x00},
    {0x00,0x38,0x08,0x08,0xC8,0x38,0x08,0x00,
     0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00},
    {0x00,0x70,0x88,0x08,0x08,0x88,0x70,0x00,
     0x00,0x1C,0x22,0x21,0x21,0x22,0x1C,0x00},
    {0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,
     0x00,0x00,0x31,0x22,0x22,0x11,0x0F,0x00},
    {0x00,0x00,0x00,0xC0,0xC0,0x00,0x00,0x00,
     0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00},
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
     0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00}
};

static void oled_i2c_delay(void)
{
    delay_cycles(OLED_I2C_DELAY_CYCLES);
}

static void oled_sda_release(void)
{
    DL_GPIO_disableOutput(OLED_SDA_PORT, OLED_SDA_PIN);
}

static void oled_sda_low(void)
{
    DL_GPIO_enableOutput(OLED_SDA_PORT, OLED_SDA_PIN);
}

static void oled_scl_release(void)
{
    DL_GPIO_disableOutput(OLED_SCL_PORT, OLED_SCL_PIN);
}

static void oled_scl_low(void)
{
    DL_GPIO_enableOutput(OLED_SCL_PORT, OLED_SCL_PIN);
}

static void oled_i2c_start(void)
{
    oled_sda_release();
    oled_scl_release();
    oled_i2c_delay();
    oled_sda_low();
    oled_i2c_delay();
    oled_scl_low();
}

static void oled_i2c_stop(void)
{
    oled_sda_low();
    oled_i2c_delay();
    oled_scl_release();
    oled_i2c_delay();
    oled_sda_release();
    oled_i2c_delay();
}

static bool oled_i2c_write_byte(uint8_t byte)
{
    for (uint8_t mask = 0x80U; mask != 0U; mask >>= 1U) {
        if ((byte & mask) != 0U) {
            oled_sda_release();
        } else {
            oled_sda_low();
        }
        oled_i2c_delay();
        oled_scl_release();
        oled_i2c_delay();
        oled_scl_low();
    }

    oled_sda_release();
    oled_i2c_delay();
    oled_scl_release();
    oled_i2c_delay();
    bool acknowledged =
        (DL_GPIO_readPins(OLED_SDA_PORT, OLED_SDA_PIN) == 0U);
    oled_scl_low();
    return acknowledged;
}

static bool ssd1315_write_packet(const uint8_t *data, uint8_t length)
{
    bool acknowledged;

    if ((data == NULL) || (length == 0U)) {
        return false;
    }

    oled_i2c_start();
    acknowledged = oled_i2c_write_byte(
        (uint8_t)(SSD1315_I2C_ADDRESS << 1U));
    for (uint8_t i = 0U; acknowledged && (i < length); i++) {
        acknowledged = oled_i2c_write_byte(data[i]);
    }
    oled_i2c_stop();

    if (!acknowledged) {
        g_oled_i2c_error_count++;
    }
    return acknowledged;
}

static bool ssd1315_write_command(uint8_t command)
{
    uint8_t packet[2] = {0x00U, command};
    return ssd1315_write_packet(packet, sizeof(packet));
}

static bool ssd1315_write_command_with_arg(uint8_t command, uint8_t argument)
{
    uint8_t packet[3] = {0x00U, command, argument};
    return ssd1315_write_packet(packet, sizeof(packet));
}

static bool ssd1315_write_commands(const uint8_t *commands, uint8_t count)
{
    uint8_t packet[SSD1315_PACKET_SIZE];
    uint8_t offset = 0U;

    while (offset < count) {
        uint8_t chunk = (uint8_t)(count - offset);
        if (chunk > SSD1315_DATA_BYTES_PER_TX) {
            chunk = SSD1315_DATA_BYTES_PER_TX;
        }
        packet[0] = 0x00U;
        for (uint8_t i = 0U; i < chunk; i++) {
            packet[1U + i] = commands[offset + i];
        }
        if (!ssd1315_write_packet(packet, (uint8_t)(chunk + 1U))) {
            return false;
        }
        offset = (uint8_t)(offset + chunk);
    }
    return true;
}

static bool ssd1315_write_data(const uint8_t *data, uint16_t count)
{
    uint8_t packet[SSD1315_PACKET_SIZE];
    uint16_t offset = 0U;

    while (offset < count) {
        uint8_t chunk = (uint8_t)(count - offset);
        if (chunk > SSD1315_DATA_BYTES_PER_TX) {
            chunk = SSD1315_DATA_BYTES_PER_TX;
        }
        packet[0] = 0x40U;
        for (uint8_t i = 0U; i < chunk; i++) {
            packet[1U + i] = data[offset + i];
        }
        if (!ssd1315_write_packet(packet, (uint8_t)(chunk + 1U))) {
            return false;
        }
        offset = (uint16_t)(offset + chunk);
    }
    return true;
}

static bool ssd1315_set_position(uint8_t x, uint8_t page)
{
    uint8_t commands[3] = {
        (uint8_t)(0xB0U + page),
        (uint8_t)(x & 0x0FU),
        (uint8_t)(0x10U | ((x >> 4U) & 0x0FU))
    };
    return ssd1315_write_commands(commands, sizeof(commands));
}

static bool ssd1315_clear(void)
{
    static const uint8_t blank[SSD1315_WIDTH] = {0U};

    for (uint8_t page = 0U; page < SSD1315_PAGE_COUNT; page++) {
        if (!ssd1315_set_position(0U, page) ||
            !ssd1315_write_data(blank, sizeof(blank))) {
            return false;
        }
    }
    return true;
}

static bool ssd1315_show_character(uint8_t x, uint8_t page, char character)
{
    uint8_t glyph_index;

    if ((character >= '0') && (character <= '9')) {
        glyph_index = (uint8_t)(character - '0');
    } else if (character == ':') {
        glyph_index = 10U;
    } else if (character == '.') {
        glyph_index = 11U;
    } else {
        return false;
    }

    return ssd1315_set_position(x, page) &&
        ssd1315_write_data(&g_time_glyphs[glyph_index][0], 8U) &&
        ssd1315_set_position(x, (uint8_t)(page + 1U)) &&
        ssd1315_write_data(&g_time_glyphs[glyph_index][8], 8U);
}

static bool ssd1315_show_time(uint32_t elapsed_hundredths)
{
    char text[8];
    uint32_t elapsed_seconds = elapsed_hundredths / 100U;
    uint32_t minutes = elapsed_seconds / 60U;
    uint32_t seconds = elapsed_seconds % 60U;
    uint32_t hundredths = elapsed_hundredths % 100U;

    if (minutes > 99U) {
        minutes = 99U;
        seconds = 59U;
        hundredths = 99U;
    }

    text[0] = (char)('0' + (minutes / 10U));
    text[1] = (char)('0' + (minutes % 10U));
    text[2] = ':';
    text[3] = (char)('0' + (seconds / 10U));
    text[4] = (char)('0' + (seconds % 10U));
    text[5] = '.';
    text[6] = (char)('0' + (hundredths / 10U));
    text[7] = (char)('0' + (hundredths % 10U));

    for (uint8_t i = 0U; i < sizeof(text); i++) {
        if (!ssd1315_show_character(
                (uint8_t)(SSD1315_TIME_X + i * 8U),
                SSD1315_TIME_PAGE, text[i])) {
            return false;
        }
    }
    return true;
}

static bool ssd1315_show_encoder_count(uint32_t count)
{
    char text[SSD1315_COUNT_DIGITS];

    for (uint8_t i = SSD1315_COUNT_DIGITS; i > 0U; i--) {
        text[i - 1U] = (char)('0' + (count % 10U));
        count /= 10U;
    }

    for (uint8_t i = 0U; i < sizeof(text); i++) {
        if (!ssd1315_show_character(
                (uint8_t)(SSD1315_COUNT_X + i * 8U),
                SSD1315_COUNT_PAGE, text[i])) {
            return false;
        }
    }
    return true;
}

uint8_t OLED_Init(void)
{
    g_oled_ready = 0U;
    g_oled_elapsed_seconds = 0U;
    g_oled_i2c_error_count = 0U;
    g_ssd1315_frozen_elapsed_ms = 0U;
    g_ssd1315_last_displayed_hundredths = UINT32_MAX;
    g_ssd1315_last_time_refresh_ms = 0U;
    g_ssd1315_encoder_count = 0U;
    g_ssd1315_last_displayed_encoder_count = UINT32_MAX;
    g_ssd1315_last_count_refresh_ms = 0U;
    g_ssd1315_clock_running = 1U;
    g_ssd1315_show_encoder_count = 0U;

    DL_GPIO_initDigitalInput(OLED_SDA_IOMUX);
    DL_GPIO_initDigitalInput(OLED_SCL_IOMUX);
    DL_GPIO_clearPins(OLED_SDA_PORT, OLED_SDA_PIN | OLED_SCL_PIN);
    oled_sda_release();
    oled_scl_release();

    delay_ms(200U);
    if (!ssd1315_write_command(0xAEU) ||
        !ssd1315_write_command(0x00U) ||
        !ssd1315_write_command(0x10U) ||
        !ssd1315_write_command(0x40U) ||
        !ssd1315_write_command(0xB0U) ||
        !ssd1315_write_command_with_arg(0x81U, 0xFFU) ||
        !ssd1315_write_command(0xA1U) ||
        !ssd1315_write_command(0xA6U) ||
        !ssd1315_write_command_with_arg(0xA8U, 0x3FU) ||
        !ssd1315_write_command(0xC8U) ||
        !ssd1315_write_command_with_arg(0xD3U, 0x00U) ||
        !ssd1315_write_command_with_arg(0xD5U, 0x80U) ||
        !ssd1315_write_command_with_arg(0xD8U, 0x05U) ||
        !ssd1315_write_command_with_arg(0xD9U, 0xF1U) ||
        !ssd1315_write_command_with_arg(0xDAU, 0x12U) ||
        !ssd1315_write_command_with_arg(0xDBU, 0x30U) ||
        !ssd1315_write_command_with_arg(0x8DU, 0x14U) ||
        !ssd1315_write_command(0xAFU) ||
        !ssd1315_clear()) {
        return 0U;
    }

    g_ssd1315_clock_start_ms = millis();
    if (!ssd1315_show_time(0U)) {
        return 0U;
    }
    g_ssd1315_last_displayed_hundredths = 0U;
    g_oled_ready = 1U;
    return 1U;
}

void OLED_ResetElapsedClock(void)
{
    g_ssd1315_clock_start_ms = millis();
    g_ssd1315_frozen_elapsed_ms = 0U;
    g_oled_elapsed_seconds = 0U;
    g_ssd1315_last_displayed_hundredths = UINT32_MAX;
    g_ssd1315_last_time_refresh_ms = 0U;
    g_ssd1315_clock_running = 1U;
    g_ssd1315_show_encoder_count = 0U;
}

void OLED_FreezeElapsedClock(void)
{
    if (g_ssd1315_clock_running) {
        g_ssd1315_frozen_elapsed_ms =
            millis() - g_ssd1315_clock_start_ms;
        g_oled_elapsed_seconds = g_ssd1315_frozen_elapsed_ms / 1000U;
        g_ssd1315_clock_running = 0U;
        g_ssd1315_last_displayed_hundredths = UINT32_MAX;
    }
}

void OLED_ShowEncoderCount(uint32_t count)
{
    g_ssd1315_encoder_count = count;
    g_ssd1315_show_encoder_count = 1U;
}

void OLED_Process(void)
{
    if (g_ssd1315_show_encoder_count) {
        uint32_t now = millis();
        if (!g_oled_ready ||
            (g_ssd1315_encoder_count ==
                g_ssd1315_last_displayed_encoder_count) ||
            ((now - g_ssd1315_last_count_refresh_ms) <
                SSD1315_COUNT_REFRESH_MS)) {
            return;
        }

        if (ssd1315_show_encoder_count(g_ssd1315_encoder_count)) {
            g_ssd1315_last_displayed_encoder_count =
                g_ssd1315_encoder_count;
            g_ssd1315_last_count_refresh_ms = now;
        } else {
            g_oled_ready = 0U;
        }
        return;
    }

    uint32_t elapsed_ms = g_ssd1315_frozen_elapsed_ms;
    if (g_ssd1315_clock_running) {
        elapsed_ms = millis() - g_ssd1315_clock_start_ms;
        g_oled_elapsed_seconds = elapsed_ms / 1000U;
    }
    uint32_t elapsed_hundredths = elapsed_ms / 10U;

    if (!g_oled_ready ||
        (elapsed_hundredths == g_ssd1315_last_displayed_hundredths)) {
        return;
    }
    if (g_ssd1315_clock_running &&
        ((elapsed_ms - g_ssd1315_last_time_refresh_ms) <
            SSD1315_TIME_REFRESH_MS)) {
        return;
    }

    if (ssd1315_show_time(elapsed_hundredths)) {
        g_ssd1315_last_displayed_hundredths = elapsed_hundredths;
        g_ssd1315_last_time_refresh_ms = elapsed_ms;
    } else {
        g_oled_ready = 0U;
    }
}
