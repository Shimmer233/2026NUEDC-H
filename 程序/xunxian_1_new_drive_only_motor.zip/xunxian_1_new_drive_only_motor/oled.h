#ifndef OLED_H
#define OLED_H

#include <stdint.h>

extern volatile uint8_t g_oled_ready;
extern volatile uint32_t g_oled_elapsed_seconds;
extern volatile uint32_t g_oled_i2c_error_count;

uint8_t OLED_Init(void);
void OLED_Process(void);
void OLED_ResetElapsedClock(void);
void OLED_FreezeElapsedClock(void);
void OLED_ShowEncoderCount(uint32_t count);

#endif
