#ifndef PID_H
#define PID_H

#include <stdint.h>

typedef struct {
    float kp;
    float ki;
    float kd;
    float integral;
    float previous_error;
    float output_min;
    float output_max;
    float integral_error_limit;
    uint8_t initialized;
} PID_Controller;

void PID_Init(PID_Controller *pid, float kp, float ki, float kd,
    float output_min, float output_max, float integral_error_limit);
void PID_Reset(PID_Controller *pid);
float PID_Update(PID_Controller *pid, float target, float measured,
    float dt_seconds);

#endif
