#include "headerfile.h"
#include "encoder.h"
#include "g356.h"
#include "motor_speed.h"
#include "oled.h"
#include "pid.h"

volatile uint32_t completed_lap_count = 0U;
volatile uint8_t g_parking_line_detected = 0U;
volatile uint8_t g_lap_finish_armed = 0U;
volatile float g_task_one_speed_scale = 1.0f;
volatile float g_task_two_speed_scale = 1.0f;
volatile uint32_t g_task_two_left_distance_counts = 0U;
volatile uint32_t g_task_two_right_distance_counts = 0U;
volatile uint32_t g_task_two_distance_counts = 0U;
volatile uint32_t g_task_three_left_distance_counts = 0U;
volatile uint32_t g_task_three_right_distance_counts = 0U;
volatile uint32_t g_task_three_distance_counts = 0U;
volatile uint32_t g_task_four_left_distance_counts = 0U;
volatile uint32_t g_task_four_right_distance_counts = 0U;
volatile uint32_t g_task_four_distance_counts = 0U;
volatile float g_task_one_left_smoothed_target = 0.0f;
volatile float g_task_one_right_smoothed_target = 0.0f;
volatile uint8_t g_task_one_stability_active = 0U;
volatile uint32_t g_task_one_left_distance_counts = 0U;
volatile uint32_t g_task_one_right_distance_counts = 0U;
volatile uint32_t g_task_one_distance_counts = 0U;
volatile float g_task_three_line_position = 0.0f;
volatile float g_task_three_speed_command = 0.0f;
volatile float g_task_three_adjust_command = 0.0f;
volatile float g_task_three_left_target = 0.0f;
volatile float g_task_three_right_target = 0.0f;
volatile uint8_t g_task_three_phase = 0U;
volatile uint8_t g_task_three_fault = 0U;
volatile float g_task_four_line_position = 0.0f;
volatile float g_task_four_speed_command = 0.0f;
volatile float g_task_four_adjust_command = 0.0f;
volatile float g_task_four_left_target = 0.0f;
volatile float g_task_four_right_target = 0.0f;
volatile uint8_t g_task_four_phase = 0U;
volatile uint8_t g_task_four_fault = 0U;

typedef struct {
    uint8_t clear_count;
    uint8_t confirm_count;
    uint8_t decel_started;
    uint32_t decel_start_ms;
} LapFinishState;

typedef enum {
    DRIVE_TRACK = 0U,
    DRIVE_FINISHED
} DrivePhase;

typedef enum {
    TASK_ONE_LAP = 1U,
    TASK_TWO_TIMED = 2U,
    TASK_THREE_SMOOTH_LAP = 3U,
    TASK_FOUR_SMOOTH_LAP = 4U
} TaskMode;

typedef struct {
    float line_position;
    float speed;
    float adjust;
    float left_target;
    float right_target;
    float stop_start_speed;
    uint32_t stop_start_ms;
    uint8_t line_position_valid;
    uint8_t stopped_stable_samples;
    uint8_t stop_requested;
    uint8_t fault;
} TaskFourController;

typedef TaskFourController TaskThreeController;

static void stop_motors(void)
{
    left_speed = 0;
    right_speed = 0;
    set_Lspeed(0);
    set_Rspeed(0);
}

static void brake_motors(void)
{
    left_speed = 0;
    right_speed = 0;
    motor_active_brake();
}

static int32_t speed_pid_command(PID_Controller *pid, float target,
    float measured, int32_t base_pwm, float base_target,
    float dt_seconds)
{
    if (target == 0) {
        PID_Reset(pid);
        return 0;
    }

    int32_t direction = (target > 0) ? 1 : -1;
    float target_magnitude = (target > 0.0f) ? target : -target;
    float measured_magnitude = (measured >= 0.0f) ? measured : -measured;
    float adjustment = PID_Update(pid, target_magnitude,
        measured_magnitude, dt_seconds);
    float feedforward = (float)base_pwm * target_magnitude / base_target;
    float command = feedforward + adjustment;

    if (command < 0.0f) {
        command = 0.0f;
    } else if (command > (float)MOTOR_PWM_MAX) {
        command = (float)MOTOR_PWM_MAX;
    }

    return direction * (int32_t)(command + 0.5f);
}

static float task_two_ease_in(float progress)
{
    return progress * (0.5f + 0.5f * progress);
}

static float task_two_startup_scale(uint32_t elapsed_ms)
{
    const float start_scale = (float)TASK_TWO_START_MIN_SPEED /
        (float)TASK_TWO_BASE_SPEED;
    const float middle_scale = TASK_TWO_MID_SPEED /
        (float)TASK_TWO_BASE_SPEED;

    if (elapsed_ms < TASK_TWO_FIRST_ACCEL_DURATION_MS) {
        float progress = (float)elapsed_ms /
            (float)TASK_TWO_FIRST_ACCEL_DURATION_MS;
        return start_scale + (middle_scale - start_scale) *
            task_two_ease_in(progress);
    }

    uint32_t second_elapsed_ms = elapsed_ms -
        TASK_TWO_FIRST_ACCEL_DURATION_MS;
    if (second_elapsed_ms < TASK_TWO_SECOND_ACCEL_DURATION_MS) {
        float progress = (float)second_elapsed_ms /
            (float)TASK_TWO_SECOND_ACCEL_DURATION_MS;
        return middle_scale + (1.0f - middle_scale) *
            task_two_ease_in(progress);
    }
    return 1.0f;
}

static float task_two_decel_scale(uint32_t decel_elapsed_ms)
{
    if (decel_elapsed_ms >= TASK_TWO_DECEL_DURATION_MS) {
        return 0.0f;
    }

    float remaining = 1.0f - (float)decel_elapsed_ms /
        (float)TASK_TWO_DECEL_DURATION_MS;
    return task_two_ease_in(remaining);
}

static int16_t scale_speed_target(int16_t target, float scale,
    int16_t minimum_speed)
{
    float scaled = (float)target * scale;
    int16_t result = (scaled >= 0.0f) ?
        (int16_t)(scaled + 0.5f) : (int16_t)(scaled - 0.5f);

    if ((target > 0) && (result < minimum_speed)) {
        result = minimum_speed;
    } else if ((target < 0) && (result > -minimum_speed)) {
        result = -minimum_speed;
    }
    return result;
}

static float task_four_soft_start_scale(uint32_t elapsed_ms)
{
    if (elapsed_ms >= TASK_FOUR_SOFT_START_DURATION_MS) {
        return 1.0f;
    }

    float progress = (float)elapsed_ms /
        (float)TASK_FOUR_SOFT_START_DURATION_MS;
    return task_two_ease_in(progress);
}

static float task_one_smooth_target(float current, float requested,
    float dt_seconds)
{
    float rate;
    if (g_task_one_stability_active) {
        rate = TASK_ONE_STABLE_TARGET_RATE;
    } else {
        rate = (requested > current) ?
            TASK_ONE_TARGET_ACCEL_RATE : TASK_ONE_TARGET_DECEL_RATE;
    }
    float maximum_step = rate * dt_seconds;

    if (requested > (current + maximum_step)) {
        return current + maximum_step;
    }
    if (requested < (current - maximum_step)) {
        return current - maximum_step;
    }
    return requested;
}

static void task_one_reduce_differential(int16_t *left_target,
    int16_t *right_target)
{
    float average = ((float)*left_target + (float)*right_target) * 0.5f;
    float steering_scale = g_task_one_stability_active ?
        TASK_ONE_STABLE_STEERING_SCALE : TASK_ONE_STEERING_SCALE;
    float half_difference =
        ((float)*left_target - (float)*right_target) * 0.5f *
        steering_scale;
    float left = average + half_difference;
    float right = average - half_difference;

    *left_target = (left >= 0.0f) ?
        (int16_t)(left + 0.5f) : (int16_t)(left - 0.5f);
    *right_target = (right >= 0.0f) ?
        (int16_t)(right + 0.5f) : (int16_t)(right - 0.5f);
}

static uint8_t apply_task_one_slowdown(LapFinishState *state,
    int16_t *left_target, int16_t *right_target, uint32_t elapsed_ms)
{
    if (!state->decel_started) {
        g_task_one_speed_scale = 1.0f;
        return 0U;
    }

    uint32_t decel_elapsed_ms = elapsed_ms - state->decel_start_ms;
    float progress = (float)decel_elapsed_ms /
        (float)TASK_ONE_DECEL_DURATION_MS;
    if (progress > 1.0f) {
        progress = 1.0f;
    }

    float scale = 1.0f - progress;
    g_task_one_speed_scale = scale;

    /* Ramp down forward speed while retaining live line-follow correction. */
    float average = ((float)*left_target + (float)*right_target) * 0.5f;
    float half_difference =
        ((float)*left_target - (float)*right_target) * 0.5f;
    float decel_average = average * scale;
    float maximum_half_difference =
        ((decel_average >= 0.0f) ? decel_average : -decel_average) *
        TASK_ONE_DECEL_STEERING_FRACTION;

    if (half_difference > maximum_half_difference) {
        half_difference = maximum_half_difference;
    } else if (half_difference < -maximum_half_difference) {
        half_difference = -maximum_half_difference;
    }

    float left = decel_average + half_difference;
    float right = decel_average - half_difference;
    *left_target = (left >= 0.0f) ?
        (int16_t)(left + 0.5f) : (int16_t)(left - 0.5f);
    *right_target = (right >= 0.0f) ?
        (int16_t)(right + 0.5f) : (int16_t)(right - 0.5f);
    left_speed = *left_target;
    right_speed = *right_target;
    return (progress >= 1.0f) ? 1U : 0U;
}

static void apply_task_two_speed_profile(int16_t *left_target,
    int16_t *right_target, float scale, int16_t minimum_speed)
{
    g_task_two_speed_scale = scale;
    *left_target = scale_speed_target(*left_target, scale, minimum_speed);
    *right_target = scale_speed_target(*right_target, scale, minimum_speed);
    left_speed = *left_target;
    right_speed = *right_target;
}

static float task_three_soft_start_scale(uint32_t elapsed_ms)
{
    if (elapsed_ms >= TASK_THREE_SOFT_START_DURATION_MS) {
        return 1.0f;
    }

    float progress = (float)elapsed_ms /
        (float)TASK_THREE_SOFT_START_DURATION_MS;
    return task_two_ease_in(progress);
}

static float task_three_abs(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float task_three_step_towards(float current, float target,
    float maximum_step)
{
    if (target > current + maximum_step) {
        return current + maximum_step;
    }
    if (target < current - maximum_step) {
        return current - maximum_step;
    }
    return target;
}

static uint8_t task_three_read_line(float *position)
{
    const uint8_t detected[6] = {
        sensor_d2 == SENSOR_LINE_LEVEL,
        sensor_d3 == SENSOR_LINE_LEVEL,
        sensor_d4 == SENSOR_LINE_LEVEL,
        sensor_d5 == SENSOR_LINE_LEVEL,
        sensor_d6 == SENSOR_LINE_LEVEL,
        sensor_d7 == SENSOR_LINE_LEVEL
    };
    const float weights[6] = {
        -2.5f, -1.5f, -0.5f, 0.5f, 1.5f, 2.5f
    };
    float weighted_sum = 0.0f;
    uint8_t active_count = 0U;

    for (uint8_t i = 0U; i < 6U; i++) {
        if (detected[i]) {
            weighted_sum += weights[i];
            active_count++;
        }
    }
    if (active_count > 0U) {
        *position = weighted_sum / (float)active_count;
    }
    return active_count;
}

static void task_three_init(TaskThreeController *controller)
{
    *controller = (TaskThreeController){0};
    controller->speed = TASK_THREE_START_SPEED;
    g_task_three_line_position = 0.0f;
    g_task_three_speed_command = 0.0f;
    g_task_three_adjust_command = 0.0f;
    g_task_three_left_target = 0.0f;
    g_task_three_right_target = 0.0f;
    g_task_three_phase = 1U;
    g_task_three_fault = 0U;
}

static uint8_t task_three_update(TaskThreeController *controller,
    uint32_t elapsed_ms, uint32_t task_elapsed_ms,
    float measured_left, float measured_right,
    int16_t *target_left, int16_t *target_right)
{
    float detected_position = 0.0f;
    uint8_t active_count = task_three_read_line(&detected_position);

    if (active_count > 0U) {
        controller->line_position = detected_position;
        controller->line_position_valid = 1U;
    }

    if (!controller->stop_requested) {
        float startup_scale = task_three_soft_start_scale(task_elapsed_ms);
        float startup_speed = TASK_THREE_START_SPEED +
            (TASK_THREE_CRUISE_SPEED - TASK_THREE_START_SPEED) *
                startup_scale;
        float curve_amount_from_error =
            task_three_abs(g_track_filtered_error) /
                TASK_THREE_CURVE_FULL_ERROR;
        float curve_amount_from_yaw_rate =
            task_three_abs(g_track_target_yaw_rate) /
                TASK_THREE_CURVE_FULL_YAW_RATE;
        float curve_amount = (curve_amount_from_error >
            curve_amount_from_yaw_rate) ? curve_amount_from_error :
            curve_amount_from_yaw_rate;
        if (curve_amount > 1.0f) {
            curve_amount = 1.0f;
        }
        float curve_speed_limit = TASK_THREE_CRUISE_SPEED -
            (TASK_THREE_CRUISE_SPEED - TASK_THREE_CURVE_SPEED) *
                curve_amount;
        float requested_speed = (startup_speed < curve_speed_limit) ?
            startup_speed : curve_speed_limit;
        if ((g_task_three_distance_counts >=
                TASK_THREE_DECEL_START_COUNTS) &&
            (requested_speed > TASK_THREE_APPROACH_SPEED)) {
            requested_speed = TASK_THREE_APPROACH_SPEED;
        }
        float speed_rate = (requested_speed > controller->speed) ?
            TASK_THREE_SPEED_ACCEL_PER_SECOND :
            TASK_THREE_SPEED_DECEL_PER_SECOND;
        controller->speed = task_three_step_towards(controller->speed,
            requested_speed,
            speed_rate * (float)elapsed_ms / 1000.0f);
    }

    controller->adjust = 0.0f;
    controller->left_target = controller->speed;
    controller->right_target = controller->speed;
    *target_left = (int16_t)(controller->left_target + 0.5f);
    *target_right = (int16_t)(controller->right_target + 0.5f);
    left_speed = *target_left;
    right_speed = *target_right;

    g_task_three_line_position = controller->line_position;
    g_task_three_speed_command = controller->speed;
    g_task_three_adjust_command = controller->adjust;
    g_task_three_left_target = controller->left_target;
    g_task_three_right_target = controller->right_target;

    (void)measured_left;
    (void)measured_right;
    return 0U;
}

static float task_four_abs(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float task_four_step_towards(float current, float target,
    float maximum_step)
{
    if (target > current + maximum_step) {
        return current + maximum_step;
    }
    if (target < current - maximum_step) {
        return current - maximum_step;
    }
    return target;
}

static uint8_t task_four_read_line(float *position)
{
    const uint8_t detected[6] = {
        sensor_d2 == SENSOR_LINE_LEVEL,
        sensor_d3 == SENSOR_LINE_LEVEL,
        sensor_d4 == SENSOR_LINE_LEVEL,
        sensor_d5 == SENSOR_LINE_LEVEL,
        sensor_d6 == SENSOR_LINE_LEVEL,
        sensor_d7 == SENSOR_LINE_LEVEL
    };
    const float weights[6] = {
        -2.5f, -1.5f, -0.5f, 0.5f, 1.5f, 2.5f
    };
    float weighted_sum = 0.0f;
    uint8_t active_count = 0U;

    for (uint8_t i = 0U; i < 6U; i++) {
        if (detected[i]) {
            weighted_sum += weights[i];
            active_count++;
        }
    }
    if (active_count > 0U) {
        *position = weighted_sum / (float)active_count;
    }
    return active_count;
}

static void task_four_init(TaskFourController *controller)
{
    *controller = (TaskFourController){0};
    controller->speed = TASK_FOUR_START_SPEED;
    g_task_four_line_position = 0.0f;
    g_task_four_speed_command = 0.0f;
    g_task_four_adjust_command = 0.0f;
    g_task_four_left_target = 0.0f;
    g_task_four_right_target = 0.0f;
    g_task_four_phase = 1U;
    g_task_four_fault = 0U;
}

static uint8_t task_four_update(TaskFourController *controller,
    uint32_t elapsed_ms, uint32_t task_elapsed_ms,
    uint8_t finish_detected, float measured_left, float measured_right,
    int16_t *target_left, int16_t *target_right)
{
    float detected_position = 0.0f;
    uint8_t active_count = task_four_read_line(&detected_position);

    if (active_count > 0U) {
        controller->line_position = detected_position;
        controller->line_position_valid = 1U;
    }

    if (!controller->stop_requested) {
        float startup_scale = task_four_soft_start_scale(task_elapsed_ms);
        float startup_speed = TASK_FOUR_START_SPEED +
            (TASK_FOUR_CRUISE_SPEED - TASK_FOUR_START_SPEED) *
                startup_scale;
        float curve_amount_from_error =
            task_four_abs(g_track_filtered_error) /
                TASK_FOUR_CURVE_FULL_ERROR;
        float curve_amount_from_yaw_rate =
            task_four_abs(g_track_target_yaw_rate) /
                TASK_FOUR_CURVE_FULL_YAW_RATE;
        float curve_amount = (curve_amount_from_error >
            curve_amount_from_yaw_rate) ? curve_amount_from_error :
            curve_amount_from_yaw_rate;
        if (curve_amount > 1.0f) {
            curve_amount = 1.0f;
        }
        float curve_speed_limit = TASK_FOUR_CRUISE_SPEED -
            (TASK_FOUR_CRUISE_SPEED - TASK_FOUR_CURVE_SPEED) *
                curve_amount;
        float requested_speed = (startup_speed < curve_speed_limit) ?
            startup_speed : curve_speed_limit;
        float speed_rate = (requested_speed > controller->speed) ?
            TASK_FOUR_SPEED_ACCEL_PER_SECOND :
            TASK_FOUR_SPEED_DECEL_PER_SECOND;
        controller->speed = task_four_step_towards(controller->speed,
            requested_speed,
            speed_rate * (float)elapsed_ms / 1000.0f);
    }

    if (!controller->stop_requested) {
        if (finish_detected) {
            controller->stop_requested = 1U;
        }

        if (controller->stop_requested) {
            controller->stop_start_speed = controller->speed;
            controller->stop_start_ms = task_elapsed_ms;
            g_task_four_phase = 3U;
            g_task_four_fault = controller->fault;
        }
    }

    if (controller->stop_requested) {
        uint32_t stop_elapsed_ms = task_elapsed_ms -
            controller->stop_start_ms;
        float stop_progress = (float)stop_elapsed_ms /
            (float)TASK_FOUR_STOP_DECEL_DURATION_MS;
        if (stop_progress > 1.0f) {
            stop_progress = 1.0f;
        }
        controller->speed = controller->stop_start_speed *
            (1.0f - stop_progress);
    }

    controller->adjust = 0.0f;
    controller->left_target = controller->speed;
    controller->right_target = controller->speed;

    *target_left = (int16_t)(controller->left_target + 0.5f);
    *target_right = (int16_t)(controller->right_target + 0.5f);
    left_speed = *target_left;
    right_speed = *target_right;

    g_task_four_line_position = controller->line_position;
    g_task_four_speed_command = controller->speed;
    g_task_four_adjust_command = controller->adjust;
    g_task_four_left_target = controller->left_target;
    g_task_four_right_target = controller->right_target;

    if (controller->stop_requested &&
        (controller->speed < 0.1f) &&
        (task_four_abs(controller->left_target) < 0.5f) &&
        (task_four_abs(controller->right_target) < 0.5f) &&
        (task_four_abs(measured_left) <= TASK_FOUR_STOPPED_SPEED) &&
        (task_four_abs(measured_right) <= TASK_FOUR_STOPPED_SPEED)) {
        if (controller->stopped_stable_samples <
            TASK_FOUR_STOPPED_STABLE_SAMPLES) {
            controller->stopped_stable_samples++;
        }
    } else {
        controller->stopped_stable_samples = 0U;
    }

    if (controller->stopped_stable_samples >=
        TASK_FOUR_STOPPED_STABLE_SAMPLES) {
        g_task_four_phase = 4U;
        return 1U;
    }
    return 0U;
}

static TaskMode wait_for_task_start(void)
{
    while (1) {
        update_sensors();
        float unused_position;
        uint8_t line_detected =
            (task_four_read_line(&unused_position) > 0U) ? 1U : 0U;

        uint8_t task_four_pressed = task_four_key_scan();
        uint8_t task_two_pressed = lap_select_key_scan();
        uint8_t task_three_pressed = task_three_key_scan();
        uint8_t task_one_pressed = start_key_scan();

        if (task_four_pressed && line_detected) {
            return TASK_FOUR_SMOOTH_LAP;
        }
        if (task_two_pressed && line_detected) {
            return TASK_TWO_TIMED;
        }
        if (task_three_pressed && line_detected) {
            return TASK_THREE_SMOOTH_LAP;
        }
        if (task_one_pressed) {
            return TASK_ONE_LAP;
        }

        MotorSpeed_Process();
        OLED_Process();
        delay_ms(1U);
    }
}

static void lap_finish_reset(LapFinishState *state)
{
    state->clear_count = 0U;
    state->confirm_count = 0U;
    state->decel_started = 0U;
    state->decel_start_ms = 0U;
    completed_lap_count = 0U;
    g_parking_line_detected = 0U;
    g_lap_finish_armed = 0U;
    g_task_one_speed_scale = 1.0f;
    g_task_two_speed_scale = 1.0f;
    g_task_one_left_smoothed_target = 0.0f;
    g_task_one_right_smoothed_target = 0.0f;
    g_task_one_stability_active = 0U;
}

static uint8_t lap_finish_detected(LapFinishState *state,
    uint8_t include_outer_sensor_groups)
{
    g_parking_line_detected = check_parking_line();
    if (include_outer_sensor_groups) {
        g_parking_line_detected |= check_cross_left() || check_cross_right();
    }

    if (!g_lap_finish_armed) {
        if (g_parking_line_detected) {
            state->clear_count = 0U;
        } else if (state->clear_count < PARKING_LINE_CLEAR_CYCLES) {
            state->clear_count++;
        }

        if (state->clear_count >= PARKING_LINE_CLEAR_CYCLES) {
            g_lap_finish_armed = 1U;
        }
        return 0U;
    }

    if (!g_parking_line_detected) {
        state->confirm_count = 0U;
        return 0U;
    }

    if (state->confirm_count < PARKING_LINE_CONFIRM_CYCLES) {
        state->confirm_count++;
    }
    return state->confirm_count >= PARKING_LINE_CONFIRM_CYCLES;
}

int main(void)
{
    SYSCFG_DL_init();

    SysTick->LOAD = (CPUCLK_FREQ / 1000U) - 1U;
    SysTick->VAL = 0U;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk |
                    SysTick_CTRL_ENABLE_Msk;

    /* OLED: PB15/PB16. */
    (void)OLED_Init();
    G356_UART_Init();
    Encoder_Init();
    MotorSpeed_Init();

    DL_TimerA_startCounter(PWM_MOTOR_INST);
    stop_motors();

    while (1) {
    TaskMode task_mode = wait_for_task_start();

    MotorSpeed_Reset();
    OLED_ResetElapsedClock();
    G356_Yaw_StartRecording();
    track_reset();

    LapFinishState lap_finish;
    lap_finish_reset(&lap_finish);
    TaskThreeController task_three = {0};
    if (task_mode == TASK_THREE_SMOOTH_LAP) {
        task_three_init(&task_three);
    } else {
        g_task_three_phase = 0U;
    }
    TaskFourController task_four = {0};
    if (task_mode == TASK_FOUR_SMOOTH_LAP) {
        task_four_init(&task_four);
    } else {
        g_task_four_phase = 0U;
    }

    PID_Controller left_pid;
    PID_Init(&left_pid, LEFT_PID_KP, LEFT_PID_KI, LEFT_PID_KD,
        -(float)MOTOR_SPEED_TEST_PWM_L,
        (float)(MOTOR_PWM_MAX - MOTOR_SPEED_TEST_PWM_L),
        PID_INTEGRAL_ERROR_LIMIT);

    PID_Controller right_pid;
    PID_Init(&right_pid, RIGHT_PID_KP, RIGHT_PID_KI, RIGHT_PID_KD,
        -(float)MOTOR_SPEED_TEST_PWM_R,
        (float)(MOTOR_PWM_MAX - MOTOR_SPEED_TEST_PWM_R),
        PID_INTEGRAL_ERROR_LIMIT);

    int32_t left_pwm = 0;
    int32_t right_pwm = 0;
    uint32_t last_pid_ms = millis();
    uint32_t task_start_ms = millis();
    int32_t task_start_left = 0;
    int32_t task_start_right = 0;
    Encoder_GetTotals(&task_start_left, &task_start_right);
    Encoder_TelemetryReset();
    g_task_one_left_distance_counts = 0U;
    g_task_one_right_distance_counts = 0U;
    g_task_one_distance_counts = 0U;
    g_task_two_left_distance_counts = 0U;
    g_task_two_right_distance_counts = 0U;
    g_task_two_distance_counts = 0U;
    g_task_three_left_distance_counts = 0U;
    g_task_three_right_distance_counts = 0U;
    g_task_three_distance_counts = 0U;
    g_task_four_left_distance_counts = 0U;
    g_task_four_right_distance_counts = 0U;
    g_task_four_distance_counts = 0U;
    uint8_t task_two_clock_frozen = 0U;
    uint8_t task_two_decel_started = 0U;
    uint32_t task_two_decel_start_ms = 0U;
    float task_two_decel_start_scale = 1.0f;
    uint8_t task_four_clock_frozen = 0U;
    uint8_t task_four_finish_detected = 0U;
    DrivePhase phase = DRIVE_TRACK;
    int16_t target_left = TRACK_BASE_SPEED;
    int16_t target_right = TRACK_BASE_SPEED;

    stop_motors();

    while (1) {
        update_sensors();
        uint32_t task_elapsed_ms = millis() - task_start_ms;
        int32_t current_left;
        int32_t current_right;
        Encoder_GetTotals(&current_left, &current_right);
        uint32_t task_left_counts =
            (uint32_t)(current_left - task_start_left);
        uint32_t task_right_counts =
            (uint32_t)(current_right - task_start_right);
        uint32_t task_average_counts =
            (task_left_counts + task_right_counts) / 2U;
        Encoder_TelemetryProcess((uint8_t)task_mode, task_left_counts,
            task_right_counts, task_average_counts);

        if (task_mode == TASK_ONE_LAP) {
            OLED_ShowEncoderCount(task_average_counts);
        }

        if (task_mode == TASK_TWO_TIMED) {
            g_task_two_left_distance_counts = task_left_counts;
            g_task_two_right_distance_counts = task_right_counts;
            g_task_two_distance_counts = task_average_counts;
        }

        if (task_mode == TASK_THREE_SMOOTH_LAP) {
            g_task_three_left_distance_counts = task_left_counts;
            g_task_three_right_distance_counts = task_right_counts;
            g_task_three_distance_counts = task_average_counts;
        }

        if (task_mode == TASK_FOUR_SMOOTH_LAP) {
            g_task_four_left_distance_counts = task_left_counts;
            g_task_four_right_distance_counts = task_right_counts;
            g_task_four_distance_counts = task_average_counts;
            if (!task_four_clock_frozen &&
                (g_task_four_distance_counts >=
                    TASK_FOUR_OLED_FREEZE_COUNTS)) {
                task_four_clock_frozen = 1U;
                OLED_FreezeElapsedClock();
            }
            if (g_task_four_distance_counts >=
                TASK_FOUR_DISTANCE_COUNTS) {
                task_four_finish_detected = 1U;
            }
        }

        if ((task_mode == TASK_TWO_TIMED) &&
            !task_two_clock_frozen &&
            (g_task_two_distance_counts >= TASK_TWO_OLED_FREEZE_COUNTS)) {
            task_two_clock_frozen = 1U;
            OLED_FreezeElapsedClock();
            task_two_decel_started = 1U;
            task_two_decel_start_ms = task_elapsed_ms;
            task_two_decel_start_scale =
                task_two_startup_scale(task_elapsed_ms);
        }

        if ((task_mode == TASK_TWO_TIMED) &&
            (phase != DRIVE_FINISHED) &&
            task_two_decel_started &&
            ((task_elapsed_ms - task_two_decel_start_ms) >=
                TASK_TWO_DECEL_DURATION_MS)) {
            phase = DRIVE_FINISHED;
            brake_motors();
        }

        if ((task_mode == TASK_TWO_TIMED) &&
            (phase != DRIVE_FINISHED)) {
            target_left = TASK_TWO_BASE_SPEED;
            target_right = TASK_TWO_BASE_SPEED;
            float task_two_scale = task_two_startup_scale(task_elapsed_ms);
            if (task_two_decel_started) {
                uint32_t decel_elapsed_ms = task_elapsed_ms -
                    task_two_decel_start_ms;
                task_two_scale = task_two_decel_start_scale *
                    task_two_decel_scale(decel_elapsed_ms);
            }
            apply_task_two_speed_profile(&target_left, &target_right,
                task_two_scale, task_two_decel_started ?
                    0 : TASK_TWO_START_MIN_SPEED);
            float curve_amount_from_error =
                task_four_abs(g_track_filtered_error) /
                    TASK_FOUR_CURVE_FULL_ERROR;
            float curve_amount_from_yaw_rate =
                task_four_abs(g_track_target_yaw_rate) /
                    TASK_FOUR_CURVE_FULL_YAW_RATE;
            float curve_amount = (curve_amount_from_error >
                curve_amount_from_yaw_rate) ?
                curve_amount_from_error : curve_amount_from_yaw_rate;
            if (curve_amount > 1.0f) {
                curve_amount = 1.0f;
            }
            float curve_speed_limit = (float)TASK_TWO_BASE_SPEED -
                ((float)TASK_TWO_BASE_SPEED - TASK_TWO_CURVE_SPEED) *
                    curve_amount;
            int16_t curve_speed_limit_int =
                (int16_t)(curve_speed_limit + 0.5f);
            if (target_left > curve_speed_limit_int) {
                target_left = curve_speed_limit_int;
                target_right = curve_speed_limit_int;
            }
        } else if (task_mode == TASK_ONE_LAP) {
            g_task_one_left_distance_counts = task_left_counts;
            g_task_one_right_distance_counts = task_right_counts;
            g_task_one_distance_counts = task_average_counts;
            target_left = TRACK_BASE_SPEED;
            target_right = TRACK_BASE_SPEED;
        } else if (task_mode == TASK_THREE_SMOOTH_LAP) {
            if (phase == DRIVE_FINISHED) {
                target_left = 0;
                target_right = 0;
                brake_motors();
            } else if ((g_task_three_distance_counts >=
                    TASK_THREE_STOP_LINE_ARM_COUNTS) &&
                check_parking_line()) {
                phase = DRIVE_FINISHED;
                completed_lap_count = 1U;
                g_parking_line_detected = 1U;
                g_task_three_phase = 4U;
                target_left = 0;
                target_right = 0;
                brake_motors();
                OLED_FreezeElapsedClock();
            }
        } else if (task_mode == TASK_FOUR_SMOOTH_LAP) {
            if (phase == DRIVE_FINISHED) {
                target_left = 0;
                target_right = 0;
                brake_motors();
            }
        }

        /* Keep the 20 ms speed sampling and PID ahead of slower UI work. */
        MotorSpeed_Process();
        uint32_t now = millis();
        uint32_t elapsed_pid_ms = now - last_pid_ms;
        if ((phase != DRIVE_FINISHED) &&
            MotorSpeed_Ready() &&
            (elapsed_pid_ms >= LEFT_PID_PERIOD_MS)) {
            last_pid_ms = now;
            float dt_seconds = (float)elapsed_pid_ms / 1000.0f;

            uint8_t task_four_finished_now = 0U;
            uint8_t task_three_finished_now = 0U;
            if (task_mode == TASK_THREE_SMOOTH_LAP) {
                task_three_finished_now = task_three_update(&task_three,
                    elapsed_pid_ms, task_elapsed_ms,
                    g_motor_left_speed, g_motor_right_speed,
                    &target_left, &target_right);
                if (task_three_finished_now) {
                    phase = DRIVE_FINISHED;
                    completed_lap_count = 0U;
                    target_left = 0;
                    target_right = 0;
                    brake_motors();
                    OLED_FreezeElapsedClock();
                }
            }
            if (task_mode == TASK_FOUR_SMOOTH_LAP) {
                task_four_finished_now = task_four_update(&task_four,
                    elapsed_pid_ms, task_elapsed_ms,
                    task_four_finish_detected, g_motor_left_speed,
                    g_motor_right_speed, &target_left, &target_right);
                if (task_four_finished_now) {
                    phase = DRIVE_FINISHED;
                    completed_lap_count = task_four.fault ? 0U : 1U;
                    target_left = 0;
                    target_right = 0;
                    brake_motors();
                    OLED_FreezeElapsedClock();
                }
            }

            if (!task_three_finished_now && !task_four_finished_now) {
                float forward_speed =
                    ((float)target_left + (float)target_right) * 0.5f;
                uint8_t smooth_lap_mode =
                    ((task_mode == TASK_THREE_SMOOTH_LAP) ||
                    (task_mode == TASK_FOUR_SMOOTH_LAP)) ? 1U : 0U;
                float steering_scale = 1.0f;
                float maximum_adjust = TRACK_HEADING_MAX_ADJUST;
                if (task_mode == TASK_ONE_LAP) {
                    steering_scale = TASK_ONE_STEERING_SCALE;
                } else if (task_mode == TASK_TWO_TIMED) {
                    steering_scale = TASK_TWO_STEERING_SCALE;
                } else if (task_mode == TASK_THREE_SMOOTH_LAP) {
                    steering_scale = TASK_THREE_STEERING_SCALE;
                    maximum_adjust = TASK_THREE_MAX_ADJUST;
                } else {
                    steering_scale = TASK_FOUR_STEERING_SCALE;
                    maximum_adjust = TASK_FOUR_MAX_ADJUST;
                }

                if (task_mode == TASK_THREE_SMOOTH_LAP) {
                    track_heading_update_with_fallback(smooth_lap_mode,
                        0U, 1U, forward_speed,
                        TASK_THREE_GYRO_FALLBACK_SPEED,
                        steering_scale, maximum_adjust, elapsed_pid_ms,
                        &target_left, &target_right);
                } else {
                    track_heading_update(smooth_lap_mode,
                        smooth_lap_mode ? 0U : 1U,
                        (task_mode == TASK_ONE_LAP) ? 0U : 1U,
                        forward_speed,
                        steering_scale, maximum_adjust, elapsed_pid_ms,
                        &target_left, &target_right);
                }
                if (task_mode == TASK_THREE_SMOOTH_LAP) {
                    task_three.adjust = g_track_final_adjust;
                    task_three.left_target = (float)target_left;
                    task_three.right_target = (float)target_right;
                    g_task_three_line_position = g_track_filtered_error;
                    g_task_three_adjust_command = g_track_final_adjust;
                    g_task_three_left_target = (float)target_left;
                    g_task_three_right_target = (float)target_right;
                } else if (task_mode == TASK_FOUR_SMOOTH_LAP) {
                    task_four.adjust = g_track_final_adjust;
                    task_four.left_target = (float)target_left;
                    task_four.right_target = (float)target_right;
                    g_task_four_line_position = g_track_filtered_error;
                    g_task_four_adjust_command = g_track_final_adjust;
                    g_task_four_left_target = (float)target_left;
                    g_task_four_right_target = (float)target_right;
                }

                float left_pid_target = g_track_left_target_float;
                float right_pid_target = g_track_right_target_float;
                int32_t desired_left_pwm = speed_pid_command(&left_pid,
                    left_pid_target,
                    g_motor_left_speed, MOTOR_SPEED_TEST_PWM_L,
                    MOTOR_SPEED_TEST_TARGET_L, dt_seconds);
                int32_t desired_right_pwm = speed_pid_command(&right_pid,
                    right_pid_target,
                    g_motor_right_speed, MOTOR_SPEED_TEST_PWM_R,
                    MOTOR_SPEED_TEST_TARGET_R, dt_seconds);
                left_pwm = desired_left_pwm;
                right_pwm = desired_right_pwm;
                set_Lspeed(left_pwm);
                set_Rspeed(right_pwm);
            }
        }

        OLED_Process();
        if (phase == DRIVE_FINISHED) {
            break;
        }
        delay_ms(((task_mode == TASK_TWO_TIMED) ||
            (task_mode == TASK_THREE_SMOOTH_LAP) ||
            (task_mode == TASK_FOUR_SMOOTH_LAP)) ? 5U : 1U);
    }
    }
}
