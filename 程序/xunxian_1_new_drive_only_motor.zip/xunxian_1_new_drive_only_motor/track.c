#include "headerfile.h"
#include "g356.h"

#include <limits.h>

volatile uint8_t sensor_d1 = 0;
volatile uint8_t sensor_d2 = 0;
volatile uint8_t sensor_d3 = 0;
volatile uint8_t sensor_d4 = 0;
volatile uint8_t sensor_d5 = 0;
volatile uint8_t sensor_d6 = 0;
volatile uint8_t sensor_d7 = 0;
volatile uint8_t sensor_d8 = 0;

static float filtered_error = 0.0f;
static float last_error = 0.0f;

volatile uint8_t g_track_gyro_mode;
volatile float g_track_filtered_error;
volatile float g_track_target_yaw_rate;
volatile float g_track_curve_yaw_rate;
volatile float g_track_target_heading;
volatile float g_track_heading_error;
volatile float g_track_measured_gyro_z;
volatile float g_track_final_adjust;
volatile float g_track_left_target_float;
volatile float g_track_right_target_float;
volatile uint32_t g_track_gyro_data_age_ms;

static float g_heading_last_error;
static float g_heading_adjust;
static float g_heading_latest_yaw;
static float g_heading_latest_gyro_z;
static uint32_t g_heading_last_frame_count;
static uint32_t g_heading_last_frame_ms;
static uint8_t g_heading_valid_frame_count;
static uint8_t g_heading_target_initialized;
static float g_heading_forward_command;
static uint8_t g_heading_forward_initialized;

static uint8_t read_sensor(uint8_t index)
{
    switch (index) {
    case 1: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_one_PORT,   GPIO_grey_tracking_PIN_one_PIN)   & GPIO_grey_tracking_PIN_one_PIN)   ? 1 : 0;
    case 2: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_two_PORT,   GPIO_grey_tracking_PIN_two_PIN)   & GPIO_grey_tracking_PIN_two_PIN)   ? 1 : 0;
    case 3: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_three_PORT, GPIO_grey_tracking_PIN_three_PIN) & GPIO_grey_tracking_PIN_three_PIN) ? 1 : 0;
    case 4: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_four_PORT,  GPIO_grey_tracking_PIN_four_PIN)  & GPIO_grey_tracking_PIN_four_PIN)  ? 1 : 0;
    case 5: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_five_PORT,  GPIO_grey_tracking_PIN_five_PIN)  & GPIO_grey_tracking_PIN_five_PIN)  ? 1 : 0;
    case 6: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_six_PORT,   GPIO_grey_tracking_PIN_six_PIN)   & GPIO_grey_tracking_PIN_six_PIN)   ? 1 : 0;
    case 7: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_seven_PORT, GPIO_grey_tracking_PIN_seven_PIN) & GPIO_grey_tracking_PIN_seven_PIN) ? 1 : 0;
    case 8: return (DL_GPIO_readPins(GPIO_grey_tracking_PIN_eight_PORT, GPIO_grey_tracking_PIN_eight_PIN) & GPIO_grey_tracking_PIN_eight_PIN) ? 1 : 0;
    default: return 0;
    }
}

void update_sensors(void)
{
    sensor_d1 = read_sensor(1);
    sensor_d2 = read_sensor(2);
    sensor_d3 = read_sensor(3);
    sensor_d4 = read_sensor(4);
    sensor_d5 = read_sensor(5);
    sensor_d6 = read_sensor(6);
    sensor_d7 = read_sensor(7);
    sensor_d8 = read_sensor(8);
}

/* 八路灰度加权巡线。
 * D1 到 D8 从车头左侧向右侧排列，对应权重：
 * [-5, -3.5, -1.5, -0.5, +0.5, +1.5, +3.5, +5]。
 * 多路同时有效时取平均位置，再通过比例控制生成左右轮差速。 */
void track(void)
{
    float error = 0.0f;
    int active = 0;

    if (sensor_d1 == SENSOR_LINE_LEVEL) { error += -5.0f; active++; }
    if (sensor_d2 == SENSOR_LINE_LEVEL) { error += -3.5f; active++; }
    if (sensor_d3 == SENSOR_LINE_LEVEL) { error += -1.5f; active++; }
    if (sensor_d4 == SENSOR_LINE_LEVEL) { error += -0.5f; active++; }
    if (sensor_d5 == SENSOR_LINE_LEVEL) { error +=  0.5f; active++; }
    if (sensor_d6 == SENSOR_LINE_LEVEL) { error +=  1.5f; active++; }
    if (sensor_d7 == SENSOR_LINE_LEVEL) { error +=  3.5f; active++; }
    if (sensor_d8 == SENSOR_LINE_LEVEL) { error +=  5.0f; active++; }

    if (active > 0) {
        error /= (float) active;
        filtered_error = 0.30f * filtered_error + 0.70f * error;
        last_error = filtered_error;
        /* 提高比例增益以增大差速，同时用限幅避免修正过猛。 */
        float adj = filtered_error * TRACK_KP;
        if (adj >  TRACK_MAX_ADJUST) adj =  TRACK_MAX_ADJUST;
        if (adj < -TRACK_MAX_ADJUST) adj = -TRACK_MAX_ADJUST;
        left_speed  = (int16_t)(TRACK_BASE_SPEED + adj);
        right_speed = (int16_t)(TRACK_BASE_SPEED - adj);
    } else if (last_error > 0.1f) {
        /* 丢线后按上一次偏差方向向右搜索。 */
        left_speed  = TRACK_SEARCH_SPEED + TRACK_SEARCH_ADJUST;
        right_speed = TRACK_SEARCH_SPEED - TRACK_SEARCH_ADJUST;
    } else if (last_error < -0.1f) {
        /* 丢线后按上一次偏差方向向左搜索。 */
        left_speed  = TRACK_SEARCH_SPEED - TRACK_SEARCH_ADJUST;
        right_speed = TRACK_SEARCH_SPEED + TRACK_SEARCH_ADJUST;
    } else {
        /* 上电后尚无偏差记录时低速直行搜索。 */
        left_speed  = TRACK_SEARCH_SPEED;
        right_speed = TRACK_SEARCH_SPEED;
    }
}

void track_reset(void)
{
    filtered_error = 0.0f;
    last_error = 0.0f;
    g_track_gyro_mode = 0U;
    g_track_filtered_error = 0.0f;
    g_track_target_yaw_rate = 0.0f;
    g_track_curve_yaw_rate = 0.0f;
    g_track_target_heading = 0.0f;
    g_track_heading_error = 0.0f;
    g_track_measured_gyro_z = 0.0f;
    g_track_final_adjust = 0.0f;
    g_track_left_target_float = 0.0f;
    g_track_right_target_float = 0.0f;
    g_track_gyro_data_age_ms = UINT32_MAX;
    g_heading_last_error = 0.0f;
    g_heading_adjust = 0.0f;
    g_heading_latest_yaw = 0.0f;
    g_heading_latest_gyro_z = 0.0f;
    g_heading_last_frame_count = 0U;
    g_heading_last_frame_ms = millis();
    g_heading_valid_frame_count = 0U;
    g_heading_target_initialized = 0U;
    g_heading_forward_command = 0.0f;
    g_heading_forward_initialized = 0U;
}

static float track_abs(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float track_clamp(float value, float minimum, float maximum)
{
    if (value < minimum) {
        return minimum;
    }
    if (value > maximum) {
        return maximum;
    }
    return value;
}

static float track_step_towards(float current, float target,
    float maximum_step)
{
    if (target > current + maximum_step) {
        return current + maximum_step;
    }
    if (target < current - maximum_step) {
        return current - maximum_step;
    }
    return target;
}

static uint8_t track_read_position(uint8_t inner_sensors_only,
    float *position)
{
    static const float all_weights[8] = {
        -5.0f, -3.5f, -1.5f, -0.5f, 0.5f, 1.5f, 3.5f, 5.0f
    };
    static const float inner_weights[6] = {
        -2.5f, -1.5f, -0.5f, 0.5f, 1.5f, 2.5f
    };
    const uint8_t detected[8] = {
        sensor_d1 == SENSOR_LINE_LEVEL,
        sensor_d2 == SENSOR_LINE_LEVEL,
        sensor_d3 == SENSOR_LINE_LEVEL,
        sensor_d4 == SENSOR_LINE_LEVEL,
        sensor_d5 == SENSOR_LINE_LEVEL,
        sensor_d6 == SENSOR_LINE_LEVEL,
        sensor_d7 == SENSOR_LINE_LEVEL,
        sensor_d8 == SENSOR_LINE_LEVEL
    };
    float sum = 0.0f;
    uint8_t active = 0U;

    if (inner_sensors_only) {
        for (uint8_t i = 0U; i < 6U; i++) {
            if (detected[i + 1U]) {
                sum += inner_weights[i];
                active++;
            }
        }
    } else {
        for (uint8_t i = 0U; i < 8U; i++) {
            if (detected[i]) {
                sum += all_weights[i];
                active++;
            }
        }
    }

    if (active > 0U) {
        *position = sum / (float)active;
    }
    return active;
}

static void track_update_gyro_state(uint32_t now)
{
    G356_Data_t data;
    uint32_t frame_count;

    if (G356_UART_GetLatest(&data, &frame_count) &&
        (frame_count != g_heading_last_frame_count)) {
        g_heading_last_frame_count = frame_count;
        g_heading_last_frame_ms = now;
        g_heading_latest_yaw = G356_Yaw_GetRecorded();
        g_heading_latest_gyro_z = data.gyro_z * TRACK_GYRO_Z_DIRECTION;
        if (g_heading_valid_frame_count < TRACK_GYRO_VALID_FRAMES) {
            g_heading_valid_frame_count++;
        }
    }

    if (g_heading_last_frame_count == 0U) {
        g_track_gyro_data_age_ms = UINT32_MAX;
    } else {
        g_track_gyro_data_age_ms = now - g_heading_last_frame_ms;
    }

    if (g_track_gyro_data_age_ms > TRACK_GYRO_STALE_TIMEOUT_MS) {
        g_track_gyro_mode = 0U;
        g_heading_target_initialized = 0U;
        g_heading_valid_frame_count = 0U;
    } else if ((g_heading_valid_frame_count >=
            TRACK_GYRO_VALID_FRAMES) && !g_track_gyro_mode) {
        g_track_target_heading = g_heading_latest_yaw;
        g_heading_target_initialized = 1U;
        g_track_gyro_mode = 1U;
    }
    g_track_measured_gyro_z = g_heading_latest_gyro_z;
}

void track_heading_update_with_fallback(uint8_t inner_sensors_only,
    uint8_t search_when_lost, uint8_t retain_curve_rate,
    float forward_speed, float fallback_speed,
    float steering_scale, float maximum_adjust,
    uint32_t elapsed_ms, int16_t *left_target,
    int16_t *right_target)
{
    uint32_t now = millis();
    float measured_position = 0.0f;
    uint8_t active = track_read_position(inner_sensors_only,
        &measured_position);
    float dt_seconds = (float)elapsed_ms / 1000.0f;

    if (active > 0U) {
        float filter_tau_ms = retain_curve_rate ?
            TRACK_CURVE_FILTER_TAU_MS : TRACK_ERROR_FILTER_TAU_MS;
        float alpha = (float)elapsed_ms /
            (filter_tau_ms + (float)elapsed_ms);
        g_track_filtered_error += alpha *
            (measured_position - g_track_filtered_error);
        if (track_abs(g_track_filtered_error) > 0.05f) {
            g_heading_last_error = g_track_filtered_error;
        }
    }

    track_update_gyro_state(now);

    uint8_t searching = (active == 0U) && search_when_lost;
    float desired_yaw_rate;
    if (searching) {
        desired_yaw_rate = (g_heading_last_error >= 0.0f) ?
            TRACK_SEARCH_YAW_RATE : -TRACK_SEARCH_YAW_RATE;
        if (forward_speed > TRACK_SEARCH_SPEED) {
            forward_speed = TRACK_SEARCH_SPEED;
        }
    } else if (active > 0U) {
        if (retain_curve_rate && g_track_gyro_mode) {
            float speed_scale = track_clamp(
                track_abs(forward_speed) / (float)TRACK_BASE_SPEED,
                0.5f, 1.5f);
            if ((track_abs(g_track_filtered_error) >=
                    TRACK_CURVE_LEARN_MIN_ERROR) &&
                (track_abs(g_heading_latest_gyro_z) >=
                    TRACK_CURVE_LEARN_MIN_RATE) &&
                ((g_track_filtered_error *
                    g_heading_latest_gyro_z) > 0.0f)) {
                float learn_alpha = (float)elapsed_ms /
                    (TRACK_CURVE_GYRO_LEARN_TAU_MS +
                        (float)elapsed_ms);
                g_track_curve_yaw_rate += learn_alpha *
                    (g_heading_latest_gyro_z -
                        g_track_curve_yaw_rate);
            }
            g_track_curve_yaw_rate += TRACK_CURVE_YAW_RATE_KI *
                g_track_filtered_error * dt_seconds * speed_scale;
            g_track_curve_yaw_rate = track_clamp(
                g_track_curve_yaw_rate,
                -TRACK_CURVE_YAW_RATE_MAX,
                TRACK_CURVE_YAW_RATE_MAX);
            desired_yaw_rate = g_track_curve_yaw_rate +
                TRACK_CURVE_YAW_RATE_KP * g_track_filtered_error;
        } else {
            g_track_curve_yaw_rate = 0.0f;
            desired_yaw_rate =
                g_track_filtered_error * TRACK_YAW_RATE_PER_ERROR;
        }
        desired_yaw_rate = track_clamp(desired_yaw_rate,
            -TRACK_MAX_YAW_RATE, TRACK_MAX_YAW_RATE);
    } else {
        desired_yaw_rate = 0.0f;
    }
    g_track_target_yaw_rate = desired_yaw_rate;

    float desired_adjust;
    if (g_track_gyro_mode && g_heading_target_initialized) {
        g_track_target_heading += desired_yaw_rate * dt_seconds;
        float heading_error = g_track_target_heading -
            g_heading_latest_yaw;
        heading_error = track_clamp(heading_error,
            -TRACK_MAX_HEADING_ERROR, TRACK_MAX_HEADING_ERROR);
        g_track_target_heading = g_heading_latest_yaw + heading_error;
        g_track_heading_error = heading_error;
        float heading_kp = retain_curve_rate ?
            TRACK_CURVE_HEADING_KP : TRACK_HEADING_KP;
        float yaw_rate_kd = retain_curve_rate ?
            TRACK_CURVE_YAW_RATE_KD : TRACK_YAW_RATE_KD;
        desired_adjust = heading_kp * heading_error +
            yaw_rate_kd *
                (desired_yaw_rate - g_heading_latest_gyro_z);
    } else {
        g_track_heading_error = 0.0f;
        desired_adjust = searching ?
            ((g_heading_last_error >= 0.0f) ?
                TRACK_SEARCH_ADJUST : -TRACK_SEARCH_ADJUST) :
            g_track_filtered_error * TRACK_KP;
        if (forward_speed > fallback_speed) {
            forward_speed = fallback_speed;
        }
    }

    if (!g_heading_forward_initialized) {
        g_heading_forward_command = forward_speed;
        g_heading_forward_initialized = 1U;
    } else {
        float forward_rate =
            (forward_speed > g_heading_forward_command) ?
                TRACK_FORWARD_ACCEL_PER_SECOND :
                TRACK_FORWARD_DECEL_PER_SECOND;
        g_heading_forward_command = track_step_towards(
            g_heading_forward_command, forward_speed,
            forward_rate * dt_seconds);
    }
    forward_speed = g_heading_forward_command;

    float adjust_limit = maximum_adjust;
    if (adjust_limit > TRACK_HEADING_MAX_ADJUST) {
        adjust_limit = TRACK_HEADING_MAX_ADJUST;
    }
    float speed_adjust_limit = track_abs(forward_speed) *
        TRACK_ADJUST_SPEED_FRACTION;
    if (adjust_limit > speed_adjust_limit) {
        adjust_limit = speed_adjust_limit;
    }
    desired_adjust = track_clamp(desired_adjust * steering_scale,
        -adjust_limit, adjust_limit);
    float adjust_slew = retain_curve_rate ?
        TRACK_CURVE_ADJUST_SLEW_PER_SECOND :
        TRACK_ADJUST_SLEW_PER_SECOND;
    g_heading_adjust = track_step_towards(g_heading_adjust,
        desired_adjust, adjust_slew * dt_seconds);
    g_heading_adjust = track_clamp(g_heading_adjust,
        -adjust_limit, adjust_limit);
    g_track_final_adjust = g_heading_adjust;

    float left = forward_speed + g_heading_adjust;
    float right = forward_speed - g_heading_adjust;
    g_track_left_target_float = left;
    g_track_right_target_float = right;
    *left_target = (left >= 0.0f) ?
        (int16_t)(left + 0.5f) : (int16_t)(left - 0.5f);
    *right_target = (right >= 0.0f) ?
        (int16_t)(right + 0.5f) : (int16_t)(right - 0.5f);
    left_speed = *left_target;
    right_speed = *right_target;
}

void track_heading_update(uint8_t inner_sensors_only,
    uint8_t search_when_lost, uint8_t retain_curve_rate,
    float forward_speed,
    float steering_scale, float maximum_adjust,
    uint32_t elapsed_ms, int16_t *left_target,
    int16_t *right_target)
{
    track_heading_update_with_fallback(inner_sensors_only,
        search_when_lost, retain_curve_rate, forward_speed,
        TRACK_GYRO_FALLBACK_SPEED, steering_scale, maximum_adjust,
        elapsed_ms, left_target, right_target);
}

uint8_t check_cross_left(void)
{
    return (sensor_d1 == SENSOR_LINE_LEVEL &&
            sensor_d2 == SENSOR_LINE_LEVEL &&
            sensor_d3 == SENSOR_LINE_LEVEL);
}

uint8_t check_cross_right(void)
{
    return (sensor_d6 == SENSOR_LINE_LEVEL &&
            sensor_d7 == SENSOR_LINE_LEVEL &&
            sensor_d8 == SENSOR_LINE_LEVEL);
}

uint8_t check_parking_line(void)
{
    uint8_t left_parking_line =
        (sensor_d2 == SENSOR_LINE_LEVEL &&
         sensor_d3 == SENSOR_LINE_LEVEL &&
         sensor_d4 == SENSOR_LINE_LEVEL);
    uint8_t right_parking_line =
        (sensor_d4 == SENSOR_LINE_LEVEL &&
         sensor_d5 == SENSOR_LINE_LEVEL &&
         sensor_d6 == SENSOR_LINE_LEVEL);

    return left_parking_line || right_parking_line;
}
