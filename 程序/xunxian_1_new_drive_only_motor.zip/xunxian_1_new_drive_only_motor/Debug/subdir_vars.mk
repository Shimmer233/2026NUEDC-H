################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../xunxian.syscfg 

C_SRCS += \
../driver.c \
../encoder.c \
../g356.c \
../main.c \
../motor_speed.c \
../oled.c \
../pid.c \
../track.c \
./ti_msp_dl_config.c \
D:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./driver.d \
./encoder.d \
./g356.d \
./main.d \
./motor_speed.d \
./oled.d \
./pid.d \
./track.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./driver.o \
./encoder.o \
./g356.o \
./main.o \
./motor_speed.o \
./oled.o \
./pid.o \
./track.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"driver.o" \
"encoder.o" \
"g356.o" \
"main.o" \
"motor_speed.o" \
"oled.o" \
"pid.o" \
"track.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"driver.d" \
"encoder.d" \
"g356.d" \
"main.d" \
"motor_speed.d" \
"oled.d" \
"pid.d" \
"track.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../driver.c" \
"../encoder.c" \
"../g356.c" \
"../main.c" \
"../motor_speed.c" \
"../oled.c" \
"../pid.c" \
"../track.c" \
"./ti_msp_dl_config.c" \
"D:/TI/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" 

SYSCFG_SRCS__QUOTED += \
"../xunxian.syscfg" 


